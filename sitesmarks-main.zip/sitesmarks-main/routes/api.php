<?php

use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\TagManagerController;
use App\Http\Controllers\Api\PromotionController;

use App\Http\Controllers\Api\BlogController;
use App\Http\Controllers\Api\BookmarkController;
use App\Http\Controllers\Api\HandleDeleteApiController;
use App\Http\Controllers\HomeController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::middleware('api_status')->group(function () {
    // Site Theme Settings add  and update
    Route::post('/store/setting', [TagManagerController::class, 'save_setting']);
    // Add Sponsored Domain
    Route::post('add/sponsored', [PromotionController::class, 'store_sponsored']);
    Route::post('update/sponsored', [PromotionController::class, 'update_sponsored']);
    // Add Promotion Images
    Route::post('add/promotion', [PromotionController::class, 'store']);
    // Get Sites Users And Save Into Record The Admin Panel (Single by Single)
    Route::get('/get/user', [UserController::class, 'getnewUser']);

    // Bookmarks Actions get save approved and rejected
    // Get pending bookmarks also added single by single to the admin panel
    Route::get('/get/bookmarks', [BookmarkController::class, 'newPendingBookmark']);
    Route::post('/save/bookmark', [BookmarkController::class, 'saveBookmark']);
    Route::post('/bookmark/changeStatus', [BookmarkController::class, 'changeStatus']);

    // Blogs Actions get save approved and rejected
    //(/get/blogs) Get pending blogs also added single by single to the admin panel
    Route::get('/get/blogs', [BlogController::class, 'newPendingBlog']);
    Route::post('/save/blog', [BlogController::class, 'saveBlog']);
    Route::post('/blog/changeStatus', [BlogController::class, 'changeStatus']);
    Route::post('/comment/changeStatus', [BlogController::class, 'changeCommentStatus']);
    Route::get('/get/comments', [BlogController::class, 'newBlogComment']);


    // Get Analytics
    Route::get('/get/analytics', [UserController::class, 'getAnalytics']);

    Route::post('/store/tag-manager', [TagManagerController::class, 'storeTagManager']);
    Route::post('/store/google-ads', [TagManagerController::class, 'googleAds']);
    Route::post('/store/seo', [TagManagerController::class, 'storeSeo']);
    Route::post('/store/sell_banner', [TagManagerController::class, 'storeSellBanner']);
    Route::post('/store/feature', [TagManagerController::class, 'storeFeature']);
    Route::post('/store/feature/blog', [TagManagerController::class, 'storeFeatureBlog']);
    Route::post('/store/user/limit', [TagManagerController::class, 'storeUserLimit']);
    Route::post('/store/price', [TagManagerController::class, 'storePrice']);
    Route::post('/store/ads-inserter', [TagManagerController::class, 'storeAdsInserter']);

    // Route::post('/unzip', [TagManagerController::class, 'unzipSubDomainFile']);

    // Route::post('/store/contact', [TagManagerController::class, 'storeContact']);


    Route::controller(HandleDeleteApiController::class)->group(function () {
        Route::post('/sponsored/delete', 'sponsoredDelete');
        Route::post('/promotion/delete', 'promotionDelete');
        Route::post('/blog/delete', 'blogDelete');
        Route::post('/featureblog/delete', 'featureblogDelete');
        Route::post('/bookmark/delete', 'bookmarkDelete');
        Route::post('/tag/delete', 'tagDelete');
        Route::post('/user/delete', 'userDelete');
    });
});
