<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\BookmarkController;
use App\Http\Controllers\SitemapController;


Route::get('/ads.txt', function () {
    return response()->file(base_path('ads.txt'));
});
// Route::fallback(function () {
//     return redirect()->route('home');
// });


Route::get('/sitemap.xml', [SitemapController::class, 'index'])->name('sitemap');

Route::middleware(['guest', 'analytics'])->group(function () {
    Route::controller(UserController::class)->group(function () {
        Route::get('/register', 'index')->name('user.register');
        Route::get('/login', 'login')->name('user.login');
        Route::post('/create', 'create')->name('user.create');
        Route::post('/make_login', 'make_login')->name('user.make.login');
        Route::get('auth/google',  'redirectToGoogle')->name('user.google.login');
        Route::get('auth/google/callback',  'handleGoogleCallback');
    });
});
Route::middleware(['auth'])->group(function () {
    Route::controller(UserController::class)->group(function () {
        Route::get('/dashboard', 'dashboard')->name('user.dashboard');
        Route::get('/dashboard/profile', 'profile')->name('user.profile');
        Route::post('/profile/update', 'profileUpdate')->name('user.profile.update');
        Route::get('/logout', 'logout')->name('user.logout');
    });

    Route::controller(BookmarkController::class)->group(function () {
        Route::post('bookmarks/getMetaData', 'getMetaData')->name('bookmark.getMetaData');

        Route::get('/dashboard/bookmarks', 'index')->name('bookmark.list');
        Route::get('/dashboard/bookmarks/create', 'create')->name('bookmark.create');
        Route::post('bookmarks/store', 'store')->name('bookmark.store');
    });
    Route::middleware(['bookmark_owner'])->group(function () {
        Route::controller(BookmarkController::class)->group(function () {
            Route::get('/dashboard/bookmarks/edit/{id}/{slug}', 'edit')->name('bookmark.edit');
            Route::post('bookmarks/update/{id}/{slug}', 'update')->name('bookmark.update');
            Route::get('/dashboard/bookmarks/delete/{id}/{slug}', 'delete')->name('bookmark.delete');
        });
    });

    Route::controller(BlogController::class)->group(function () {
        Route::get('/dashboard/blogs', 'index')->name('blog.list');
        Route::get('/dashboard/blogs/create', 'create')->name('blog.create');
        Route::post('blog/store', 'store')->name('blog.store');
    });
    Route::middleware(['blog_owner'])->group(function () {
        Route::controller(BlogController::class)->group(function () {
            Route::get('/dashboard/blogs/edit/{id}/{slug}', 'edit')->name('blog.edit');
            Route::post('blog/update/{id}/{slug}', 'update')->name('blog.update');
            Route::get('/dashboard/blogs/delete/{id}/{slug}', 'delete')->name('blog.delete');
        });
    });
    Route::controller(HomeController::class)->group(function () {
        Route::get('/dashboard/bookmark/{bookmark_id}/{slug}', 'userBookmarkDetails');
        Route::get('/dashboard/blog/{id}/{slug}', 'userBlogDetails')->name('blog.user.details');
    });
});


Route::middleware(['analytics'])->group(function () {
    Route::controller(HomeController::class)->group(function () {
        Route::get('/', 'index')->name('home');
        Route::get('/bookmarks/featured', 'featuredBookmarkDetails')->name('featured.bookmark.details');

        Route::get('/bookmarks', 'getBookmarks')->name('user.bookmarks');
        // Route::get('/user/bookmark/{slug}', 'userCategory')->name('user.category.bookmark');

        Route::get('/blogs', 'getblogs')->name('user.blog');
        // Route::get('/bookmark', 'bookmark')->name('bookmark');
        Route::get('/contact', 'contact')->name('user.contact');
        Route::post('/contactSave', 'contactSave')->name('user.contactSave');
        Route::get('/price', 'price')->name('user.price');
        Route::get('/about-us', 'about')->name('user.about');

        Route::post('/blog/comment', 'blogComment')->name('user.blog.comment');
        Route::get('/blog/comment/list', 'getComments')->name('blog.comments');

        Route::get('/privacy-policy', 'policy')->name('privacyPolicy');
        Route::get('/terms-and-condition', 'term')->name('termsCondition');
        Route::get('/content-policy', 'content')->name('user.content');

        Route::get('/search','search')->name('bookmark.search');

        Route::get('/bookmarks/{category}/{slug}', 'bookmarkDetails')->name('bookmark.details');
        Route::get('/blogs/{category}/{slug}', 'blogDetails')->name('blog.details');
        Route::get('bookmarks/{slug}', 'categoryData')->name('user.category');
        Route::get('/blogs/{slug}', 'blogFeatureDetails')->name('featured.blog.details');

        Route::get('/clear-session/{key}','clearSession')->name('clear-session');
        // Route::get('blogs/{slug}', 'blogFeatureDetails')->name('featured.blog.details');
    });
});
