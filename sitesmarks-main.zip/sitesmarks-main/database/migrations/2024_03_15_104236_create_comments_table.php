<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('comments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('blog_id')->nullable()->constrained('blog_posts')->cascadeOnDelete();
            $table->foreignId('feature_id')->nullable()->constrained('feature_blogs')->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained('users')->cascadeOnDelete();
            $table->longText('comment');
            $table->boolean('api_status')->default(false);
            $table->boolean('status')->default(false);
            $table->boolean('is_feature')->default(false);
            $table->timestamps();
        });
        DB::statement('ALTER TABLE comments ADD CONSTRAINT check_feature_blog_id_combinations CHECK (
            (is_feature = 1 AND blog_id IS NULL AND feature_id IS NOT NULL) OR
            (is_feature = 0 AND blog_id IS NOT NULL AND feature_id IS NULL)
        )');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('comments');
    }
};
