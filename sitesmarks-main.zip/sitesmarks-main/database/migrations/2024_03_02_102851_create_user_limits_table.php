<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_limits', function (Blueprint $table) {
            $table->id();
            $table->integer('blog_limit')->default(0);
            $table->integer('bookmark_limit')->default(0);
            $table->integer('blog_min_title')->default(0);
            $table->integer('blog_min_description')->default(0);
            $table->integer('blog_max_title')->default(0);
            $table->integer('blog_max_description')->default(0);
            $table->integer('bookmark_min_title')->default(0);
            $table->integer('bookmark_min_description')->default(0);
            $table->integer('bookmark_max_title')->default(0);
            $table->integer('bookmark_max_description')->default(0);
            $table->integer('blog_tag')->default(0);
            $table->integer('bookmark_tag')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_limits');
    }
};
