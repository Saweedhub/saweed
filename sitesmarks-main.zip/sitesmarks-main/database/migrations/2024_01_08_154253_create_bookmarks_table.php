<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bookmarks', function (Blueprint $table) {
            $table->id();
            $table->string('url');
            $table->bigInteger('bookmark_id')->nullable()->unique();
            $table->string('cat_id');
            $table->foreignId('user_id')->nullable()->constrained('users')->cascadeOnDelete();
            $table->longText('tag');
            $table->string('title');
            $table->string('slug');

            $table->boolean('follow')->default(false);

            $table->longText('description');
            $table->string('captcha')->nullable();
            $table->boolean('api_status')->default(false);
            $table->boolean('status')->default(false);

            $table->boolean('by_admin')->default(false);
            $table->boolean('is_paid')->default(false);
            
            $table->timestamps();
            // Add unique constraint on combination of url and user_id
            $table->unique(['url', 'user_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bookmarks');
    }
};
