<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('blog_posts', function (Blueprint $table) {
            $table->id();
            $table->text('title');
            $table->bigInteger('blog_id')->nullable()->unique();
            $table->string('cat_id');
            $table->foreignId('user_id')->nullable()->constrained('users')->cascadeOnDelete();
            $table->longText('tag');
            $table->text('slug');
            // $table->string('image');
            $table->longText('description');
            $table->string('thumbnail')->nullable();
            $table->boolean('api_status')->default(false);
            $table->boolean('status')->default(false);
            $table->boolean('by_admin')->default(false);
            $table->boolean('is_paid')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('blog_posts');
    }
};
