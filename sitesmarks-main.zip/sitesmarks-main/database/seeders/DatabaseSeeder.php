<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        \App\Models\Setting::factory(1)->create();
        // \App\Models\User::factory(1)->create();
        // \App\Models\Bookmark::factory(40)->create();
        // \App\Models\BlogPost::factory(40)->create();
        // \App\Models\Feature::factory(1)->create();
        // \App\Models\Sponsored::factory(10)->create();
        // \App\Models\UserLimit::factory(1)->create();
        // \App\Models\FeatureBlog::factory(3)->create();
        // \App\Models\Promotion::factory(5)->create();
    }
}
