<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Feature>
 */
class FeatureFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'title' => 'Best Social And Directory Submission Sites',
            'url' => 'https://devitcity.com/',
            'email' => 'admin@devitcity.com',
            'description' => 'Business listings builds links from high quality, localized and industry relevant directories might just be one of the most overlooked tactics in the modern SEO repertoire. It is an effective way to build your online presence. When you add social bookmarks to the web, it helps search engines understand your site.',
            'status' => 1,
        ];
    }
}
