<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Setting>
 */
class SettingFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $policy = '<p>We are committed to protecting your privacy. We will only collect and use information about you
        lawfully
        and in accordance with the Data Protection Act 1998.</p>
        <p><strong>Personal Information Collection:</strong><br>
        We collect only your name, e-mail address, submitted stories and profile data. We care about the
        information we collect and it is used for helping you with the best possible services. We only
        collect
        personal information that is relevant to the purpose of our website, which is to enable users to
        discover and share information with one another. This information allows us to provide you with a
        customized and efficient experience. We do not process this information in a way that is
        incompatible
        with this objective. We receive and store any information you enter on our website or provide to us
        in
        any other way. You can choose not to provide us with certain information, but then you may not be
        able
        to take advantage of many of our special features.</p>
        <p><strong>Protection of Personal Information:</strong><br>
        Your account information is protected by a password for your privacy and security. Protect against
        unauthorized access to your password and to your computer by logging off once you have finished
        using a
        shared computer. As stated previously, you can always opt not to disclose information, but then you
        may
        be unable to use certain features on our website, such as posting new links. By visiting your User
        Profile, you can correct, amend, add or delete personal information on our website. When you update
        information, however, we often maintain a copy of the unrevised information in our records. You may
        request deletion of your account by visiting contact us page and sending email with detailed
        information. Please note that you will continue to receive all system e-mails (e.g. those regarding
        forgotten user passwords) and legal notices (e.g. updates to our policies) from us.</p>
        <p>We never share sensitive information about you without your explicit consent. We do not sell or pass
        any
        user’s personal information, e-mail addresses included, to any other organization for any purpose.
        The
        information is held under high security and would not be shared for any reasons whatsoever.
        Information
        will not be kept for longer than is necessary. The information we hold will be accurate and wherever
        necessary, kept up to date. You can check the information we hold about you, by contacting us via
        e-mail. We will immediately correct any errors you find. Data held about you will be done so under
        extreme.</p>
        <p><strong>Registration:</strong><br>
        In order for you to use website services, such as submitting new links to the website, you must
        complete
        a registration form. As part of this registration form, we require select personal information
        (including your full name, city, state and e-mail address).</p>
        <p><strong>User Profile:</strong><br>
        To allow you to express yourself beyond just the information collected during registration, we
        enable
        you to provide additional information, such as a bio, favorite URLs, and instant messaging IDs. In
        addition, you may choose to include photos of yourself in your profile. You can control how your
        information is displayed and used. We receive and store certain types of information whenever you
        interact with us. We are authorized to receive and record certain “traffic data” on their server
        logs
        from your browser including your IP address, cookie information, and the page you requested. We uses
        this traffic data to help diagnose problems with its servers, analyze trends and administer the
        website.
        We may collect and, on any page, display the total counts that page has been viewed.</p>
        <p><strong>Links to Other Sites :</strong><br>
        The website contains links to other sites. We are not responsible for the privacy practices of such
        websites. Inclusion of links to an outside website, whether in an advertisement or content area of
        the
        website, is not an endorsement of the website or a guarantee that the information it contains is
        accurate.</p>
        <p><strong>Cookies:</strong><br>
        Cookies are text files stored on your computer when you visit web pages on our web site. This site
        uses
        cookies to improve your visit and to display relevant ads to you on third party web sites. Your
        privacy
        is important to us, you should also know how browsers will direct you on how to prevent your browser
        from accepting new cookies, how to command the browser to tell you when you receive a new cookie, or
        how
        to fully disable cookies. Please note, however, that if your browser does not accept cookies, you
        will
        not be able to take advantage of some of our attractive features. The data contained in the cookie
        used
        for third party advertising is completely anonymous and does not contain any of your personal
        details.
        We would like to continue showing relevant ads to you, but if you would prefer to opt-out of this
        service. To do so, please visit https://policies.google.com/technologies/ads</p>
        <p><strong>Children Under 18 Years of Age:</strong><br>
        You must be 13 years and older to register to use the website. As a result our site does not
        specifically collect information about children. If we learn that collected information from a child
        under the age of 13, we will delete that information as quickly as possible. We recommend that
        minors
        between the ages of 13 and 18 ask and receive their parents’ permission before using site or sending
        information about themselves or anyone else over the Internet. We may amend this Privacy Policy from
        time to time, at its sole discretion. Use of information we collect now is subject to the Privacy
        Policy
        in effect at the time such information is used. If we make changes to the Privacy Policy, we will
        notify
        you by posting an announcement on the website so you are always aware of what information we
        collect,
        how we use it, and under what circumstances if any, it is disclosed.</p>
        <p><strong>Conditions of Use:</strong><br>
        If you decide to visit our website, your visit and any possible dispute over privacy is subject to
        this
        Privacy Policy and our Terms of Use, including limitations on damages, arbitration of disputes, and
        application of country law.</p>
        <p><strong>Contact Us:</strong><br>
        If you have any questions regarding our privacy policy then please <a href="/contact">Contact
        Us</a>
        for more details.</p>';
        $terms = '<p>This User Agreement explains the terms and conditions on which we offer you to be a posting contributor. The
        foundation of our relationship with our members is the website Terms of Agreement. The Site Guidelines,
        Member Agreement, and Privacy Policy collectively encompass the Terms of Agreement, and they are relevant to
        all site users and members. This summarizes your rights and responsibilities as a site member and our
        dedication to you.</p>
        <p>KINDLY UNDERSTAND CAREFULLY THE NEXT TERMS OF AGREEMENT. IF AFTER READING THESE TERMS AND CONDITIONS, YOU
        UNDERSTOOD AND RECOGNIZE THEM, YOU WILL BE BELIEVED TO HAVE DECIDED TO BE BOUND BY THE SAID TERMS AND
        CONDITIONS AND TO DEVOTEDLY MEET THE TERMS WITH THE SAME.</p>
        <p><strong>Registration:</strong><br>
        Information required upon registration for each participant on our site must be precise and absolute. You
        must update such information as needed in order to ensure that the information remains to be accurate and
        complete.</p>
        <p><strong>Requirements for Joining the Service:</strong><br>
        You can be a resident of any country, at least 18 years of age and legally able to enter personal
        information to qualify for site membership. If you are not yet 18 years old, we reserve the right to limit
        you from creating an account with us.</p>
        <p><strong>Use of user ID and Password:</strong><br>
        You must register using your own name and provide factual and current information. We will create an Account
        for you when you complete your online registration. You have to choose a username that will be identified
        with your Account for the life of your account. This username will be used by you to log on to website
        Services. We assume that you authorize all activities made using your user ID and password.</p>
        <p><strong>Submitting of posts:</strong><br>
        Upon registration to site, it allows you to post story and article (including without limitation text,
        music, sounds and videos, photos, data, graphics through links)(not sure if all are applicable) in the site
        in a number of forms and news, such as your opinion about any of the topics in site and comments to other
        people’s posts.</p>
        <p><strong>User Conduct:</strong><br>
        a. You agree not to provide any posts, News, Blogs, or Stories to the website that (a) contravene any
        third-party intellectual property or publicity/privacy rights, (b) is knowingly bogus, and/or offensive,
        imprecise, insulting, improper, intolerable, harassing, obscene, blasphemous, menacing, omnipresent of a
        person’s privacy, or otherwise violating of any law or bylaw, (c) be full of any viruses, worms, Trojan
        horses, cancel bots, time bombs, or other computer programming practice that are planned to harm, damagingly
        get in the way with, sneakily intercept or confiscate any system, data or personal information, and (d)
        encourages piracy.<br>
        b. As each site is purposely customized to address certain topics, you should hang about on-topic at all
        times. You are accountable for initiating new threads in the correct page. The suitable content for each
        site is illustrated specifically on the site Homepage.<br>
        c. You should be in agreement that you are not to post the same post in multiple topics without permission
        from the other Account holders. All such desires for authorization should be directed through the site.<br>
        d. “Impersonation,” or making use of the character of another user by replicating his username and mode of
        writing, is prohibited.<br>
        e. “Flaming,” or lashing out at other users is strictly not allowed. Proper manners are necessary for
        contribution in the site.<br>
        f. “Spamming,” or sending unwanted junk e-mails or junk postings, in any form, is strictly not
        permissible.<br>
        g. “Trolling,” or posting offensive or deliberately troublesome threads/replies for the main reason of (1)
        harvesting penalizing verbal abuse and flames, or (2) throwing off the sense of balance of the site, is also
        not allowed.<br>
        h. You should be in agreement that you are not to disturb the normal flow of Blinks.<br>
        i. You must agree not to use the website to either promote or endorse profitable events, which includes
        straight posts, and even, active links to other sites on the Internet, without the authorization from us.
        All such wishes for authorization should be directed through the executive site.<br>
        j. You also agree that you will not integrate any word in your name, post ID or custom user title that is
        slanderous, obscene or disrespectful, or which violates any service mark, trademark, or other intellectual
        property rights of any third party, including, without limitation, that of our site.</p>
        <p><strong>Content Filtering:</strong><br>
        a. We reserve the rights to edit, delete, or trim any and all articles or topics that, in its sole belief,
        infringes any of the terms and conditions of this Agreement.<br>
        b. We may elect, at its sole judgment, to observe some, all, or no areas of our site for observance to these
        agreement or website policies and guidelines. Other users may may also control individual sites. Questions
        about a particular site should be bound for the respective news, article poster.<br>
        c. Any user who feels that a post is offensive may request to us to delete said post by email through the
        pointed out address. Upon receipt of such a request, we will conclude, in its sole judgment, if such
        deletion is essential. If deemed essential, we will make every attempt to do so, within a levelheaded
        timeline.<br>
        d. We do not support or advocate any of the opinions or ideas supplied by its users. However, we authorize
        others to make judgments about your Posts.<br>
        e. We are not responsible for any and all posts expressed in the site. We do not attempt to control or
        validate any comments or recommendations provided by the participants and are not accountable for any
        inexactness in the posts.<br>
        f. Information enclosed in the site, including but not limited to those relating to law or medicine or other
        fields, is not intended to replace for the guidance or opinion of your own lawyer or physician or
        professional adviser. You agree not to depend on any of the advise or opinion shared. Under no conditions,
        including but not limited to carelessness, shall we be liable for any dependence on any such information,
        nor shall we be liable for any direct, secondary, individual, significant, roundabout or retaliatory damages
        that result from the use of, or inability to use, the information in our website.</p>
        <p><strong>User Security and Privacy:</strong><br>
        a. We bring together information during the registration process to operate the site (“Profile”). It
        collects non-personally identifiable information (often referred to as demographic information) such as:
        birth date, gender, occupation, country, region or city, and zip or postal code. You may update your Profile
        Information any time by clicking the “Profile” link found upper right hand corner of the site.<br>
        b. Your Profile Information is used only for demographic statistics. We keep all of your Personal
        Information secured and does not contribute it with any third parties. We will not divulge your Personal
        Information unless acting under a good faith belief that such action is essential to: (1) obey the rules of
        legal requirements or conform with legal process; (2) defend and preserve the rights or property of us;
        enforce the User Agreement; or (4) act to guard the welfare of its users or others.<br>
        c. We will not send you any unwelcome information, including junk e-mail, unless you choose otherwise. We
        may also send periodic user letters to announce important service changes, new features, and technical issue
        updates.<br>
        d. If at any time you believe that we are not remained to these guidelines, please notify us by e-mail using
        contact us form and we will use all rational labors to punctually settle on and correct the predicament.
        </p>
        <p><strong>Limitation of Use:</strong><br>
        We reserve the right to limit the use of our site to any individual or group at any time.</p>
        <p><strong>No Warranty:</strong><br>
        a. We repudiate any and all accountability or legal responsibility for the exactness, substance, totality,
        authority, dependability, or operable or accessibility of information or material in the Site.<br>
        b. We repudiate any accountability for the deletion, failure to store, inaccurate or premature delivery
        news, stories or blogs.<br>
        c. We disclaim any responsibility for any harm resulting from downloading or accessing any information or
        material through our website.<br>
        d. Our web site and services are given as it is, and we expressly repudiates all service contracts or
        circumstances of any kind (whether stated, disguised or constitutional), including without restraint the
        disguised warranties of title, non-infringement, and robustness for a particular purpose. Without limiting
        the foregoing, We do not swear or guarantee you that any feature of the web site and system will work
        suitably or will be available endlessly.</p>
        <p><strong>No Liability:</strong><br>
        In no event shall we be liable to any party for any loss or damage, including but not limited to lost
        revenues or proceeds or special, indirect, incidental or consequential reparation (howsoever happening,
        including abandonment) arising out of or in association with the our website, its services or this
        Agreement.</p>
        <p><strong>Access Limits:</strong><br>
        Without the prior written consent of site, you may not (a) use any computerized means to be admitted to the
        site or collect any information from the our website (including without limitation spiders, robots or
        scripts), or (b) place pop-up windows over its pages frame the site, or even those that could affect the
        display of the website pages.</p>
        <p><strong>Amendments:</strong><br>
        We reserve the right to alter any of the terms and conditions of this Agreement at any given time. Such
        alterations made to the terms and conditions shall be effective when posted at the our website.</p>
        <p><strong>Termination:</strong><br>
        We reserve the right to terminate your use of site at anytime, with or without notice. Following
        termination, at its sole option, We may remove some or all of your posts from the website or leave it
        available for public review, without necessarily a notice or authorization coming from you.</p>
        <p>If you have any questions about this user agreement, please send us email using <a href="/contact">Contact
        Us</a> form.</p>';
        $content = "<span style='color:#c43232;'><strong>WE DON'T ALLOW BELOW TYPES OF CONTENT FOR FREE OR PAID USERS
        BOTH. USER DATA WOULD BE DELETED PERMANENTLY ON VIOLATING CONTENT POLICY OR RULES OF THE
        SITE. PLEASE CAREFULLY READ BELOW POLICY:</strong></span>
        <ul class='list-unstyled mb-0 text-left position-relative'>
        <li>– Drugs, gambling, adult, 18+ age or matured content.</li>
        <li>– Spam, fake offers, free money, nulled script, duplicate site url or content.</li>
        <li>– Copyrighted materials including images, videos or any content.</li>
        <li>– Content title less than 30 or more than 100 characters or contains junk data.</li>
        <li>– Content description less than 250 or more than 2000 characters or contains junk data.
        </li>
        <li>– Content tag more than 50 characters or contains junk data.</li>
        <li>– Content that is excessively posted, repetitive, untargeted, unauthorized or
        non-english content.</li>
        <li>– Promises viewers they’ll see something but instead directs them off site.</li>
        <li>– Content linking to or promoting third-party view count or subscriber gaming websites
        or services.</li>
        <li>– Leaving large amounts of identical, untargeted or repetitive comments.</li>
        <li>– Content aiming to mislead participants about the time, means or eligibility
        requirements for participating in a census.</li>
        <li>– Using post title, thumbnails, description, or tags to trick users into believing the
        content is something it is not.</li>
        <li>– Content that has been technically manipulated or doctored in a way that misleads users
        (beyond clips taken out of context) and may pose a serious risk of egregious harm.</li>
        <li>– Content offering cash gifts, “get rich quick” schemes, or pyramid schemes (sending
        money without a tangible product in a pyramid structure).</li>
        <li>– Gets clicks, views, or traffic off this site by promising viewers that they’ll make
        money fast.</li>
        <li>– Sends audiences to sites that spread malware, try to gather personal information, or
        other sites that have a negative impact.</li>
        <li>– Content aiming to mislead voters about the time, place, means or eligibility
        requirements for voting.</li>
        <li>– Content that advances false claims related to the technical eligibility requirements
        for current political candidates and sitting elected government officials to serve in
        office. Eligibility requirements considered are based on applicable national law, and
        include age, citizenship, or vital status.</li>
        <li>– Links to or promotes third-party services that artificially inflate metrics like
        views, likes, and subscribers.</li>
        <li>– Content that sells engagement metrics such as views, likes, comments, or any other
        metric on this site. This also includes content where the only purpose is to boost
        subscribers, views, or other metrics (e.g. offering to subscribe to another creator’s
        channel solely in exchange for them subscribing to your channel, also known as “Sub4Sub”
        content).</li>
        <li>– Comments where the sole purpose is to gather personal information from viewers,
        misleadingly drive viewers off in this site, or perform any of the prohibited behaviors
        noted above.</li>
        <li>– Live streams intended to stream content that belongs to somebody else and are not
        corrected following repeated warnings of possible abuse. Live streams should be actively
        monitored by the channel owner, and any potential issues should be corrected in a timely
        manner.</li>
        <br>
        <li><b>This policy applies to all posts, usernames, meta, tags, comments and any kinds of
        content used in the site. Please keep in mind, this is not a complete list.</b></li>
        </ul>";
        return [
            'bg_title' => 'Free Bookmarking Sites',
            'bg_desc' => "Elevate your website's SEO effortlessly with our backlink submission service.",
            'footer_description' => "Discover, organize, and boost your online presence with our innovative backlinking and bookmarking platform. Register now to streamline your SEO strategy and amplify your content's reach effortlessly.",
            'primary_color' => '#0069FD',
            'secondary_color' => '#096d5c',
            "privacy_policy" => $policy,
            "terms_and_conditions" => $terms,
            "content_policy" => $content,
            "contact_address" => "86 Cissbury Cres, Saltdean, Brighton BN2<br>United Kingdom, Bn28rj",
            "contact_number" => "+44 (7762) 320743",
            "contact_email" => "info@devitcity.com",
        ];
    }
}
