<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;


class UserLimitFactory extends Factory
{
    public function definition(): array
    {
        return [
            'blog_limit' => 0,
            'bookmark_limit' => 0,

            'blog_min_title' => 50,
            'blog_max_title' => 150,

            'blog_min_description' => 700,
            'blog_max_description' => 1500,

            'bookmark_min_title' => 50,
            'bookmark_max_title' => 100,

            'bookmark_min_description' => 150,
            'bookmark_max_description' => 250,

            'blog_tag' => 5,
            'bookmark_tag' => 5
        ];
    }
}
