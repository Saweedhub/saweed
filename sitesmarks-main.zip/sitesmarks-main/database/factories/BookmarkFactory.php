<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Bookmark>
 */
class BookmarkFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $title = fake()->paragraph(1);
        $slug = Str::slug($title);
        return [
            'url' => fake()->url(),
            'title' => $title,
            'slug' => $slug,
            'cat_id' => 'sports',
            'user_id' => 1,
            'tag' => json_encode([['value' => 'tag1'], ['value' => 'tag2']]),
            'follow' => 'follow',
            'description' => fake()->paragraph(5),
            'by_admin' => fake()->randomElement([0, 1]),
            'is_paid' => 0,
            'status' => 1,
            'api_status' => 1,
        ];
    }
}
