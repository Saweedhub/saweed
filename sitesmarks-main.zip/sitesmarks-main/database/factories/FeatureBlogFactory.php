<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
class FeatureBlogFactory extends Factory
{
    public function definition(): array
    {
        
        $title = fake()->paragraph(1);
        return [
            'title' => $title,
            'blog_id'=>fake()->randomNumber(),
            'email' => 'admin@devitcity.com',
            'tag' => json_encode([['value' => 'tag1'], ['value' => 'tag2']]),
            'description' => fake()->paragraph(10),
            'thumbnail' =>fake()->imageUrl(360, 360, 'blog', true, 'thumbnail', true, 'jpg'),
            'status' => 1,

        ];
    }
}
