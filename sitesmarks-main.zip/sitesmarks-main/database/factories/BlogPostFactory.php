<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Bookmark>
 */
class BlogPostFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $title = fake()->paragraph(1);
        $slug = Str::slug($title);
        return [
            'title' => $title,
            'slug' => $slug,
            'cat_id' => 'sports',
            'user_id' => 1,
            'tag' => json_encode([['value' => 'tag1'], ['value' => 'tag2']]),
            'description' => fake()->paragraph(10),
            'thumbnail' =>fake()->imageUrl(360, 360, 'blog', true, 'thumbnail', true, 'jpg'),
            'by_admin' => fake()->randomElement([0, 1]),
            // 'blog_id' => 0,
            'is_paid' => 0,
            'status' => 1,
            'api_status' => 1,
        ];
    }
}
