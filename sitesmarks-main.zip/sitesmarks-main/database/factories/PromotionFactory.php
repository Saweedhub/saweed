<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;


class PromotionFactory extends Factory
{

    public function definition(): array
    {
        return [
            'url' => 'https://www.' . fake()->unique()->word . '.tk',
            'image' => fake()->imageUrl(640, 480, 'promotion', true, 'image', true, 'jpg'),
            'alt_text' => 'https://devitcity.com'
        ];
    }
}
