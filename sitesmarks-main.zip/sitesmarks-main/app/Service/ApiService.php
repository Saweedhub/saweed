<?php

namespace App\Service;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use App\Models\Bookmark;

trait ApiService
{
    public function sanitize_html($html)
    {
        $allowed_tags = '<div><pre><p><a><s><iframe><video><sub><sup><blockquote><ul><ol><li><strong><em><u><blockquote><h1><h2><h3><h4><h5><h6><br><hr><table><tr><tbody><td><span><img>';
        $sanitized_html = strip_tags($html, $allowed_tags);
        return $sanitized_html;
    }

    public function createDataToAdminPanel($data, $url)
    {
        try {
            $response = Http::post(config('app.api_url') . $url, [
                'data' => $data,
                'website'=> config('app.url'),
            ]);
            $responseData = $response->json();
            if ($response->successful() && $responseData['success'] == true) {
                $data->each(function ($da) {
                    $da->api_status = 1;
                    $da->save();
                });
                return null;
            } else {

                $errorMessage = $responseData['message'] ?? 'Failed to add data Api: ' . $url . ' Unknown error';
                return ['data' => $data, 'error' => $errorMessage];
            }
        } catch (\Exception $e) {
            // If an exception occurs, return error response
            throw new \Exception('Error :' . $e->getMessage());
        }
    }

    static public function getApiSetting()
    {
        $response = Http::get(config('app.api_url') . 'api/get/setting');
        if ($response->successful()) {
            $data = $response->json();
            return $data;
        } else {
            $statusCode = $response->status();
            logger()->error("Failed to fetch data. Status code: $statusCode");
        }
    }
    protected function createUniqueSlug($title,$model,$slugField = 'slug')
    {
        $slug = Str::slug($title);
        $originalSlug = $slug;
        $count = 1;
    
        while ($model::where($slugField, $slug)->exists()) {
            $slug = $originalSlug . '-' . $count++;
        }
        return $slug;
    }

}
