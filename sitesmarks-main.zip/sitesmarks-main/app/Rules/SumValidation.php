<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\Rule;
use Illuminate\Contracts\Validation\ValidationRule;

class SumValidation implements Rule
{
    public function passes($attribute, $value)
    {
        $v1 = request('value1');
        $v2 = request('value2');
        return (intval($v1) + intval($v2)) == intval($value);
    }

    public function message()
    {
        return 'The sum of value1 and value2 must be equal to the captcha value.';
    }
}
