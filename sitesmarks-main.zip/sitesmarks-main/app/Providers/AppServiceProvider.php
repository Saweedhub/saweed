<?php

namespace App\Providers;

// use App\Models\SMTPConnection;
use App\Service\ApiService;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    use ApiService;
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */

    public function boot(): void
    {

        // $response_categories = $this->getCategories();
        // $categories = $response_categories['categories'];


        $categories = [
            [
                'name' => 'Business & Services',
                'image' => 'service.svg',
            ],
            [
                'name' => 'Education',
                'image' => 'education.svg',
            ],
            [
                'name' => 'Entertainment',
                'image' => 'entertainment.svg',
            ],
            [
                'name' => 'Music',
                'image' => 'music.svg',
            ],
            [
                'name' => 'News & Politics',
                'image' => 'news.svg',
            ],
            [
                'name' => 'People & Blogs',
                'image' => 'people.svg',
            ],
            [
                'name' => 'Science & Technology',
                'image' => 'science.svg',
            ],
            [
                'name' => 'Sports',
                'image' => 'sports.svg',
            ],
            [
                'name' => 'Autos & Vehicles',
                'image' => 'auto.svg',
            ],
            [
                'name' => 'Insurance',
                'image' => 'insurance.svg',
            ],
            [
                'name' => 'Digital Marketing',
                'image' => 'marketing.svg',
            ],
            [
                'name' => 'Digital Services',
                'image' => 'digital.svg',
            ],
            [
                'name' => 'Travel',
                'image' => 'travel.svg',
            ],
            [
                'name' => 'Advertising',
                'image' => 'ad.svg',
            ],
            [
                'name' => 'Healthcare',
                'image' => 'health.svg',
            ],
            [
                'name' => 'Seo',
                'image' => 'seo.svg',
            ],
            [
                'name' => 'Fashion',
                'image' => 'fashion.svg',
            ],
            [
                'name' => 'Food',
                'image' => 'food.svg',
            ],
            [
                'name' => 'Electronics',
                'image' => 'electronics.svg',
            ],
            [
                'name' => 'Real Estate',
                'image' => "realesate.svg",
            ],
            [
                'name' => 'Job',
                'image' => 'job.svg',
            ],
            [
                'name' => 'Buy, Sell, Rent',
                'image' => 'buysell.svg',
            ],
            [
                'name' => 'Other',
                'image' => 'other.svg',
            ],
        ];

        $setting = \App\Models\Setting::first();
        $ads_inserter = \App\Models\AdsInserter::get();

        if ($setting) {
            [$r, $g, $b] = sscanf($setting->secondary_color, '#%02x%02x%02x');
            $rgbaColor = "rgba($r, $g, $b, 0.6)";
        } else {
            $rgbaColor = "rgba(0, 0, 0, 0.6)";
        }
        View::share('setting', $setting);
        View::share('rgbaColor', $rgbaColor);
        View::share(['categories' => $categories]);
        View::share('ads_inserter', $ads_inserter);
    }
}
