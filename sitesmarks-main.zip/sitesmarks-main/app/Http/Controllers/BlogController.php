<?php

namespace App\Http\Controllers;

use App\Models\BlogPost;
use App\Models\Category;
use App\Models\UserLimit;
use App\Rules\SumValidation;
use App\Service\ApiService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class BlogController extends Controller
{
    use ApiService;

    public function index()
    {
        $blogs = BlogPost::latest()->where('user_id', auth()->id())->get();
        return view('blog.list', compact('blogs'));
    }

    public function create()
    {
        $value1 = rand(9, 0);
        $value2 = rand(9, 0);
        return view('blog.create', compact('value1', 'value2'));
    }

    public function store(Request $request)
    {
        $user_limit = UserLimit::first();

        $blog = BlogPost::whereUserId(auth()->id())->count();

        if ($blog < $user_limit->blog_limit || $user_limit->blog_limit == 0 || Auth::user()->is_paid == 1) {
            $validate = $request->validate([
                'title' => 'required|min:' . $user_limit->blog_min_title . '|max:' . $user_limit->blog_max_title,
                'cat_id' => 'required|string',
                'thumbnail' => 'required|image|mimes:jpg,png,jpeg,webp|max:1024',
                'value1' => ['required', 'numeric', 'regex:/^[0-9]$/'],
                'value2' => ['required', 'numeric', 'regex:/^[0-9]$/'],
                'captcha' => ['required', new SumValidation()],
                'description' => 'required|min:' . $user_limit->blog_min_description . '|max:' . $user_limit->blog_max_description,
                'keywords' => [
                    'required',
                    'string',
                    function ($attribute, $value, $fail) use ($user_limit) {
                        $tags = json_decode($value, true);
                        if (!is_array($tags)) {
                            $fail($attribute . ' is invalid.');
                            return;
                        }
                        if (count($tags) >  $user_limit->bookmark_tag) {
                            $fail($attribute . ' cannot contain more than ' . $user_limit->bookmark_tag . ' keywords.');
                            return;
                        }
                        foreach ($tags as $tag) {
                            if (!isset($tag['value']) || !is_string($tag['value'])) {
                                $fail($attribute . ' contains invalid items.');
                                return;
                            }
                        }
                    },
                ],
            ]);
            // if ($validator->fails()) {
            //     return response()->json(['success' => false, 'message' => $validator->errors()->all()]);
            // }

            $thumbnail = "";
            if ($request->file("thumbnail")) {
                $thumbnail = $request->file("thumbnail")->store("blog/thumbnail", "public");
            }
            $blog = new BlogPost();
            $blog->title = $request->title;
            $blog->user_id = auth()->id();
            // $blog->slug = Str::slug($request->title);
            $blog->slug = $this->createUniqueSlug($request->title, BlogPost::class);
            $blog->cat_id = Str::slug($request->cat_id);
            $blog->thumbnail = $thumbnail;
            $blog->tag = $request->keywords;

            $blog->status = 1;
            $blog->api_status = 1;

            $blog->description = $this->sanitize_html($request->description);
            $blog->save();
            return to_route('blog.list')->with('success', 'Blog Added Successfully');
        } else {
            return to_route('blog.list')->with('error', 'Free user add only ' . $user_limit->bookmark_limit . ' Blogs');
        }
    }

    public function edit($id, $slug)
    {
        $blog = BlogPost::whereSlugAndId($slug, $id)->firstOrFail();
        $value1 = rand(9, 0);
        $value2 = rand(9, 0);
        return view('blog.update', compact('blog', 'value1', 'value2'));
    }

    public function update(Request $request, $id, $slug)
    {
        $user_limit = UserLimit::first();
        $blog = BlogPost::whereSlugAndId($slug, $id)->firstOrFail();

        if ($blog && $blog->user_id  == auth()->id()) {
            $request->validate([
                'title' => 'required|min:' . $user_limit->blog_min_title . '|max:' . $user_limit->blog_max_title,
                'cat_id' => 'required|string',

                'thumbnail' => 'nullable|image|mimes:jpg,png,jpeg,webp|max:1024',

                'value1' => ['required', 'numeric', 'regex:/^[0-9]$/'],
                'value2' => ['required', 'numeric', 'regex:/^[0-9]$/'],
                'captcha' => ['required', new SumValidation()],

                'description' => 'required|min:' . $user_limit->blog_min_description . '|max:' . $user_limit->blog_max_description,
               
                'keywords' => [
                    'required',
                    'string',
                    function ($attribute, $value, $fail) use ($user_limit) {
                        $tags = json_decode($value, true);
                        if (!is_array($tags)) {
                            $fail($attribute . ' is invalid.');
                            return;
                        }
                        if (count($tags) >  $user_limit->bookmark_tag) {
                            $fail($attribute . ' cannot contain more than ' . $user_limit->bookmark_tag . ' keywords.');
                            return;
                        }
                        foreach ($tags as $tag) {
                            if (!isset($tag['value']) || !is_string($tag['value'])) {
                                $fail($attribute . ' contains invalid items.');
                                return;
                            }
                        }
                    },
                ],
            ]);

            $thumbnail = $blog->thumbnail;
            if ($request->file('thumbnail')) {
                $thumbnail = $request->file('thumbnail')->store('blog/thumbnail', 'public');
                $oldThumbnailPath = public_path('storage/' . $blog->thumbnail);
                if (File::exists($oldThumbnailPath)) {
                    File::delete($oldThumbnailPath);
                }
            }
            $blog->title = $request->title;
            $blog->slug = Str::slug($request->title);
            $blog->cat_id = Str::slug($request->cat_id);
            $blog->thumbnail = $thumbnail;
            $blog->tag = $request->keywords;
            $blog->description = $request->description;
            $blog->save();
            return to_route('blog.list')->with('success', 'Blog Update successfully');
        } else {
            return to_route('blog.list')->with('error', 'Free user add only ' . $user_limit->blog_limit . ' blog');
        }
    }

    public function delete($id, $slug)
    {
        $blog = BlogPost::whereSlugAndId($slug, $id)->firstOrFail();

        if ($blog && $blog->user_id == auth()->id()) {
            $thumbnailPath = public_path('storage/' . $blog->thumbnail);
            if (File::exists($thumbnailPath)) {
                File::delete($thumbnailPath);
            }
            $blog->delete();
            return to_route('blog.list')->with('success', 'Blog delete successfully');
        } else {
            return to_route('blog.list')->with('error', 'Un Authorized Access');
        }
    }
}
