<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Rules\SumValidation;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Laravel\Socialite\Facades\Socialite;

class UserController extends Controller
{
    public function index()
    {
        $value1 = rand(9, 0);
        $value2 = rand(9, 0);
        return view('users.auth.register', compact('value1', 'value2'));
    }

    public function create(Request $request)
    {
        $validate = $request->validate([
            'name' => 'required|min:4|max:32',
            'email' => 'required|email|unique:users|max:64',
            'password' => 'required|min:4|max:22',
            'password_confirmation' => 'required|same:password',
            'value1' => 'required',
            'value2' => 'required',
            'captcha' => ['required', new SumValidation]
        ]);

        $user = User::create([
            'name' => $validate['name'],
            'email' => $validate['email'],
            'password' => Hash::make($validate['password'])
        ]);
        Auth::login($user);
        return to_route('user.dashboard')->with('success', 'Registration Successfully');
    }

    public function dashboard()
    {
        $user = Auth::user();
        return view('users.profile', compact('user'));
    }

    public function profile()
    {
        $user = Auth::user();
        return view('users.update-profile', compact('user'));
    }

    public function login()
    {
        $value1 = rand(9, 0);
        $value2 = rand(9, 0);
        return view('users.auth.login', compact('value1', 'value2'));
    }

    public function make_login(Request $request)
    {
        $validate = $request->validate([
            'email' => 'required|email|exists:users',
            'password' => 'required|min:4',
            'value1' => 'required',
            'value2' => 'required',
            'captcha' => ['required', new SumValidation]
        ]);

        $user = Auth::attempt(['email' => $request->email, 'password' => $request->password]);
        if ($user) {
            return to_route('user.dashboard')->with('success', 'User login successfully');
        } else {
            return to_route('user.login')->with('error', 'Invalid Email and Password');
        }
    }


    public function profileUpdate(Request $request)
    {
        $request->validate([
            'name' => 'required|min:4|max:32',
            'mobile' => 'nullable|string|min:10|max:15',
            'city' => 'nullable|string|max:50',
            'state' => 'nullable|string|max:50',
            'pincode' => 'nullable|string|min:6|max:10',
            'address' => 'nullable|string|max:255',
            'password' => 'nullable|string|min:4|max:50',
            'facebook' => 'nullable|string|min:4|max:50',
            'twitter' => 'nullable|string|min:4|max:22',
            'website_name' => 'nullable|url',
            'bio' => 'nullable|min:10|max:150',
            'profile' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
        ]);

        $user = User::findOrFail(auth()->id());
        $profilePath = $user->image;
        if ($request->hasFile('profile')) {
            $profilePath = $request->file('profile')->store('profile', 'public');
        }
        $user->name = $request->name ?? $user->name;
        // $user->email = $request->email ?? $user->email;
        $user->image = $profilePath;
        $user->mobile = $request->mobile;
        $user->city = $request->city;
        $user->state = $request->state;
        $user->pincode = $request->pincode;
        $user->address = $request->address;
        $user->password = $request->password == null ? $user->password : Hash::make($request->password);
        $user->facebook = $request->facebook;
        $user->twitter = $request->twitter;
        $user->website_name = $request->website_name;
        $user->bio = $request->bio;
        $user->save();
        return to_route('user.profile')->with('success', 'Profile update successfully');
    }

    public function logout()
    {
        Auth::logout();
        return to_route('user.login')->with('success', 'Logout out successfully');
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function handleGoogleCallback()
    {
        try {

            $user = Socialite::driver('google')->user();
            $find_user = User::where('google_id', $user->id)->first();

            if ($find_user) {
                Auth::login($find_user);

                return redirect()->intended('dashboard');
            } else {
                $newUser = User::create([
                    'name' => $user->name,
                    'email' => $user->email,
                    'google_id' => $user->id,
                    'password' => ''
                ]);

                Auth::login($newUser);
                return redirect()->intended('dashboard');
            }
        } catch (Exception $e) {
            // dd($e->getMessage());
        }
    }
}
