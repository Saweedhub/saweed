<?php

namespace App\Http\Controllers;

use App\Models\Bookmark;
use App\Models\FeatureBlog;
use App\Models\BlogPost;
use Illuminate\Support\Str;

class SitemapController extends Controller
{
    public function index()
    {
        // Generate URLs for the bookmarks
        $bookmarks = Bookmark::whereStatus(1)->get();
        $bookmarkUrls = $bookmarks->map(function ($bookmark) {
            return [
                'loc' => url('/bookmarks/' . $bookmark->slug),
                'lastmod' => $bookmark->updated_at->toAtomString(),
                'changefreq' => 'weekly',
                'priority' => '0.8',
            ];
        });

        // Generate URLs for the blog posts
        $blogs = BlogPost::whereStatus(1)->get();
        $blogUrls = $blogs->map(function ($blog) {
            return [
                'loc' => url('/blogs/' . $blog->slug),
                'lastmod' => $blog->updated_at->toAtomString(),
                'changefreq' => 'weekly',
                'priority' => '0.8',
            ];
        });

        $featureBlog = FeatureBlog::whereStatus(1)->get();
        $featureBlogUrls = $featureBlog->map(function ($blog) {
            return [
                'loc' => url('/blogs/' . Str::slug($blog->title)),
                'lastmod' => $blog->updated_at->toAtomString(),
                'changefreq' => 'weekly',
                'priority' => '0.9',
            ];
        });

        // Merge all URLs
        $urls = $featureBlogUrls->merge($bookmarkUrls)->merge($blogUrls);

        $sitemap = view('sitemap', compact('urls'));
        // Return response
        return response($sitemap, 200)->header('Content-Type', 'application/xml');
    }
}


