<?php

namespace App\Http\Controllers\Api;

use Carbon\Carbon;
use App\Models\User;
use App\Models\BlogPost;
use App\Models\Bookmark;
use App\Models\Promotion;
use App\Models\Sponsored;
use App\Models\TagManager;
use App\Models\FeatureBlog;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class HandleDeleteApiController extends Controller
{
    public function sponsoredDelete(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'url' => 'required|url',
        ]);

        // Check if the validation fails
        // Check validation results
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->all(),
            ], 422);
        }

        try {
            // Check if the sponsored URL exists
            $sponsored = Sponsored::whereUrl($request->url)->first();

            // If the sponsored URL exists, delete it
            if ($sponsored) {
                $sponsored->delete();
                return response()->json([
                    'success' => true,
                    'message' => ['Sponsored deleted Successfully on ' . url('/')]
                ]);
            } else {
                // If the sponsored URL does not exist, return an error message
                return response()->json([
                    'success' => true,
                    'message' => ['Sponsored not deleted Successfully URL does not exist on ' . url('/')]
                ]);
            }
        } catch (\Exception $e) {
            // If an exception occurs, return an error message
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while Sponsored deleted on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }

    public function promotionDelete(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'image' => 'required|url',
        ]);
        // Check validation results
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->all(),
            ], 422);
        }

        try {
            // Check if the promotion URL exists
            $promotion = Promotion::whereImage($request->image)->first();

            // If the promotion URL exists, delete it
            if ($promotion) {
                $promotion->delete();
                return response()->json([
                    'success' => true,
                    'message' => ['promotion deleted Successfully on ' . url('/')]
                ]);
            } else {
                // If the promotion image URL does not exist, return an error message
                return response()->json([
                    'success' => true,
                    'message' => ['Promotion not deleted Successfully on Image does not exist ' . url('/')]
                ]);
            }
        } catch (\Exception $e) {
            // If an exception occurs, return an error message
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while promotion deleted on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }
    public function blogDelete(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'blog_id' => 'required|integer',
        ]);
        // Check validation results
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->all(),
            ], 422);
        }

        try {
            // Check if the blog exists
            $blogPost = BlogPost::whereBlogId($request->blog_id)->first();

            // If the blog exists, delete it
            if ($blogPost) {
                $blogPost->delete();
                return response()->json([
                    'success' => true,
                    'message' => ['BlogPost deleted Successfully on ' . url('/')]
                ]);
            } else {
                // If the blog does not exist, return an error message
                return response()->json([
                    'success' => true,
                    'message' => ['BlogPost not deleted Successfully does not exist on ' . url('/')]
                ]);
            }
        } catch (\Exception $e) {
            // If an exception occurs, return an error message
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while BlogPost deleted on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }  public function featureblogDelete(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'blog_id' => 'required|integer',
        ]);
        // Check validation results
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->all(),
            ], 422);
        }

        try {
            // Check if the blog exists
            $blogPost = FeatureBlog::whereBlogId($request->blog_id)->first();

            // If the blog exists, delete it
            if ($blogPost) {
                $blogPost->delete();
                return response()->json([
                    'success' => true,
                    'message' => ['Feature BlogPost deleted Successfully on ' . url('/')]
                ]);
            } else {
                // If the blog does not exist, return an error message
                return response()->json([
                    'success' => true,
                    'message' => ['Feature BlogPost not deleted Successfully does not exist on ' . url('/')]
                ]);
            }
        } catch (\Exception $e) {
            // If an exception occurs, return an error message
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while Feature BlogPost deleted on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }
    public function bookmarkDelete(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'bookmark_id' => 'required|integer',
        ]);
        // Check validation results
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->all(),
            ], 422);
        }

        try {
            // Check if the bookmark exists
            $bookmark = Bookmark::whereBookmarkId($request->bookmark_id)->first();

            // If the bookmark exists, delete it
            if ($bookmark) {
                $bookmark->delete();
                return response()->json([
                    'success' => true,
                    'message' => ['bookmark deleted Successfully on ' . url('/')]
                ]);
            } else {
                // If the bookmark does not exist, return an error message
                return response()->json([
                    'success' => true,
                    'message' => ['bookmark not deleted Successfully does not exist on ' . url('/')]
                ]);
            }
        } catch (\Exception $e) {
            // If an exception occurs, return an error message
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while bookmark deleted on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }
    public function tagDelete(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'tag_id' => 'required|integer',
        ]);
        // Check validation results
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->all(),
            ], 422);
        }

        try {
            // Check if the sponsored URL exists
            $tagManager = TagManager::whereTagId($request->tag_id)->first();

            // If the sponsored URL exists, delete it
            if ($tagManager) {
                $tagManager->delete();
                return response()->json([
                    'success' => true,
                    'message' => ['TagManager deleted Successfully on ' . url('/')]
                ]);
            } else {
                // If the sponsored URL does not exist, return an error message
                return response()->json([
                    'success' => true,
                    'message' => ['TagManager not deleted Successfully on does not exist' . url('/')]
                ]);
            }
        } catch (\Exception $e) {
            // If an exception occurs, return an error message
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while TagManager deleted on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }


    public function userDelete(Request $request)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'start_date' => 'required|date',
            'end_date' => 'required|date',
        ]);
        // Check validation results
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->errors()->all(),
            ], 422);
        }
        try {
            $startDate = Carbon::parse($request->input('start_date'));
            $endDate = Carbon::parse($request->input('end_date'));
            $users = User::whereIsPaid(0)->whereBetween('created_at', [$startDate, $endDate])->get();
            foreach ($users as $user) {
                foreach ($user->blogPosts as $blogPost) {
                    $path = public_path('storage/' . $blogPost->thumbnail);
                    if (File::exists($path)) {
                        File::delete($path);
                    }
                }
                $user_path = public_path('storage/' . $user->image);
                if (File::exists($user_path)) {
                    File::delete($user_path);
                }
                $user->delete();
            }
            return response()->json(['message' => 'Users deleted successfully']);
        } catch (\Exception $e) {
            // If an exception occurs, return an error message
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while Users deleted on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }
}
