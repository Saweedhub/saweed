<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Promotion;
use App\Models\Sponsored;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PromotionController extends Controller
{
    public function store(Request $request)
    {
        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'url' => 'required|url',
                'alt_text' => 'required|string',
                'image' => [
                    'required',
                    'url',
                    function ($attribute, $value, $fail) {
                        if (Promotion::where('image', $value)->exists()) {
                            $fail($attribute . ' already exists in the Sponsored table. on ' . url('/'));
                        }
                    },
                ],
            ]);

            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }

            // Save the new Promotion
            Promotion::create($request->only([
                'image',
                'alt_text',
                'url',
            ]));

            // Return success response
            return response()->json([
                'success' => true,
                'message' => ['Promotion Image saved successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            // If an exception occurs, return error response
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while saving Promotion Image on ' . url('/')  . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }
    public function store_sponsored(Request $request)
    {
        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'url' => [
                    'required',
                    'url',
                    function ($attribute, $value, $fail) {
                        if (Sponsored::where('url', $value)->exists()) {
                            $fail($attribute . ' already exists in the Sponsored table. on ' . url('/'));
                        }
                    },
                ],
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }

            Sponsored::create([
                'url' => $request->url,
            ]);

            // Return success response
            return response()->json([
                'success' => true,
                'message' => ['Sponsored URL saved successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            // If an exception occurs, return error response
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while saving sponsored URL on ' . url('/') . '. Error message: ' . $e->getMessage()]
            ]);
        }
    } 
    
    public function update_sponsored(Request $request)
    {
        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'newurl' => [
                    'required',
                    'url',
                    function ($attribute, $value, $fail) {
                        if (Sponsored::where('url', $value)->exists()) {
                            $fail($attribute . ' already exists in the Sponsored table. on ' . url('/'));
                        }
                    },
                ],
                'url'=>'required|exists:sponsoreds,url',
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            $sponsored = Sponsored::whereUrl($request->url)->first();
            $sponsored->url = $request->newurl;
            $sponsored->save();
           

            // Return success response
            return response()->json([
                'success' => true,
                'message' => ['Sponsored URL saved successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            // If an exception occurs, return error response
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while saving sponsored URL on ' . url('/') . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }
}
