<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AdsInserter;
use App\Models\ContactSetting;
use App\Models\Feature;
use App\Models\FeatureBlog;
use App\Models\GoogleAd;
use App\Models\Price;
use App\Models\SellBanner;
use App\Models\Seo;
use App\Models\Setting;
use App\Models\TagManager;
use App\Models\UserLimit;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;

class TagManagerController extends Controller
{
    public function storeTagManager(Request $request)
    {
        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'tag_id' => 'required|unique:tag_managers|integer',
                'name' => 'required|string',
                'header_script' => ['required_without_all:body_script', 'string'],
                'body_script' => ['required_without_all:header_script', 'string'],
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            TagManager::create([
                'tag_id' => $request->tag_id,
                'name' => $request->name,
                'header_script' => $request->header_script,
                'body_script' => $request->body_script,
            ]);

            return response()->json([
                'success' => true,
                'message' => ['Tag Manager Created Successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while added tags on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }


    public function googleAds(Request $request)
    {
        try {
            if (GoogleAd::count() != 0) {
                return response()->json([
                    'success' => true,
                    'message' => ['Already Added Google adsense Approval request code if you want to modify the code so first delete the previous one'],
                ], 200);
            }
            // Validations
            $validator = Validator::make($request->all(), [
                // 'google_id' => 'required|unique:google_ads|integer',
                'code' => 'required_without_all:meta_txt,meta_tag|string',
                'meta_txt' => 'required_without_all:code,meta_tag|string',
                'meta_tag' => 'required_without_all:code,meta_txt|string',
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            GoogleAd::create([
                // 'google_id' => $request->google_id,
                'code' => $request->code,
                'meta_txt' => $request->meta_txt,
                'meta_tag' => $request->meta_tag,
            ]);
            if ($request->meta_txt) {
                $filePath = base_path('ads.txt');
                $content = $request->meta_txt;
                // Check if the file exists and delete it
                if (file_exists($filePath)) {
                    unlink($filePath);
                }
                // Create a new file and write the content
                file_put_contents($filePath, $content);
            }

            return response()->json([
                'success' => true,
                'message' => ['Google Ads Created Successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while Google Ads tags on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }

    public function storeSeo(Request $request)
    {

        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'title' => 'required|string',
                'name' => [
                    'required',
                    'string',
                    Rule::in([
                        'Home', 'bookmark', 'contact', 'price', 'about-us', 'privacy-policy',
                        'terms-and-condition', 'content-policy', 'blogs'
                    ])
                ],
                'description' => 'required|string',
                'keywords' => 'nullable|string',
                'robots' => 'nullable|string',
                'facebook' => 'nullable|string',
                'twitter' => 'nullable|string',
                'schema' => 'nullable|string',
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }

            // $is_seo = Seo::first();
            $is_seo = Seo::where('name', $request->name)->first();
            if ($is_seo) {
                $is_seo->update([
                    'title' => $request->title,
                    'name' => $request->name,
                    'description' => $request->description,
                    'keywords' => $request->keywords,
                    'robots' => $request->robots,
                    'facebook' => $request->facebook,
                    'twitter' => $request->twitter,
                    'schema' => $request->schema,
                ]);
            } else {
                Seo::create([
                    'title' => $request->title,
                    'name' => $request->name,
                    'description' => $request->description,
                    'keywords' => $request->keywords,
                    'robots' => $request->robots,
                    'facebook' => $request->facebook,
                    'twitter' => $request->twitter,
                    'schema' => $request->schema,
                ]);
            }
            // Return success response
            return response()->json([
                'success' => true,
                'message' => ['Seo updated successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while updated Seo on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }

    public function storeAdsInserter(Request $request)
    {

        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'name' => [
                    'required',
                    'string',
                    Rule::in([
                        'dashboard', 'auth', 'screens', 'bookmark-list', 'blog-list',
                        'sidebar', 'footer'
                    ])
                ],
                'top' => 'nullable|string',
                'bottom' => 'nullable|string',
                'left' => 'nullable|string',
                'right' => 'nullable|string',
                'between' => 'nullable|string',
                'inside' => 'nullable|string',
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }

            $is_AdsInserter = AdsInserter::where('name', $request->name)->first();
            if ($is_AdsInserter) {
                $is_AdsInserter->update([
                    'name' => $request->name,
                    'top' => $request->top,
                    'bottom' => $request->bottom,
                    'left' => $request->left,
                    'right' => $request->right,
                    'between' => $request->between,
                    'inside' => $request->inside,
                ]);
            } else {
                AdsInserter::create([
                    'name' => $request->name,
                    'top' => $request->top,
                    'bottom' => $request->bottom,
                    'left' => $request->left,
                    'right' => $request->right,
                    'between' => $request->between,
                    'inside' => $request->inside,
                ]);
            }
            // Return success response
            return response()->json([
                'success' => true,
                'message' => ['Ads Inserter updated successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while updated Ads Inserter on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }

    public function storeSellBanner(Request $request)
    {
        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'banner' => 'required|string',
                'status' => 'required|in:0,1'
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            $is_banner = SellBanner::first();
            if ($is_banner) {
                $is_banner->sell_banners = $request->banner;
                $is_banner->status = $request->status;
                $is_banner->save();
            } else {
                SellBanner::create([
                    'sell_banners' => $request->banner,
                    'status' => $request->status
                ]);
            }
            return response()->json([
                'success' => true,
                'message' => ['Sell banner Added Successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while added Sell Baner on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }

    public function storeFeature(Request $request)
    {
        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'url' => 'required|url',
                'title' => 'required|string',
                'description' => 'required|string',
                'email' => 'required|email',
                'status' => 'required|in:0,1'
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            $is_feature = Feature::first();
            if ($is_feature) {
                $is_feature->title = $request->title;
                $is_feature->description = $request->description;
                $is_feature->url = $request->url;
                $is_feature->email = $request->email;
                $is_feature->status = $request->status;
                $is_feature->save();
            } else {
                Feature::create([
                    'title' => $request->title,
                    'description' => $request->description,
                    'url' => $request->url,
                    'email' => $request->email,
                    'status' => $request->status,
                ]);
            }
            return response()->json([
                'success' => true,
                'message' => ['Feature Bookmark Added Successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while added Feature Bookmark on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }

    public function storeFeatureBlog(Request $request)
    {
        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'blog_id' => 'required|integer',
                'thumbnail' => 'required|url',
                'title' => 'required|string',
                'description' => 'required|string',
                'email' => 'required|email',
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            FeatureBlog::updateOrCreate(
                ['blog_id' => $request->blog_id,], // The condition to check
                [
                    'title' => $request->title,
                    'email' => $request->email,
                    'description' => $request->description,
                    'thumbnail' => $request->thumbnail,
                    'status' => 1,
                ]
            );
  
            return response()->json([
                'success' => true,
                'message' => ['Feature Blog Added Successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while added Feature Blog on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }
    public function storeUserLimit(Request $request)
    {
        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'blog_limit' => 'required|integer',
                'bookmark_limit' => 'required|integer',
                'blog_min_title' => 'required|integer',
                'blog_min_description' => 'required|integer',
                'blog_max_title' => 'required|integer',
                'blog_max_description' => 'required|integer',
                'bookmark_min_title' => 'required|integer',
                'bookmark_min_description' => 'required|integer',
                'bookmark_max_title' => 'required|integer',
                'bookmark_max_description' => 'required|integer',
                'blog_tag' => 'required|integer',
                'bookmark_tag' => 'required|integer',
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            $limit = UserLimit::first();
            if ($limit) {
                $limit->update([
                    'blog_limit' => $request->blog_limit,
                    'bookmark_limit' => $request->bookmark_limit,
                    'blog_min_title' => $request->blog_min_title,
                    'blog_min_description' => $request->blog_min_description,
                    'blog_max_title' => $request->blog_max_title,
                    'blog_max_description' => $request->blog_max_description,
                    'bookmark_min_title' => $request->bookmark_min_title,
                    'bookmark_min_description' => $request->bookmark_min_description,
                    'bookmark_max_title' => $request->bookmark_max_title,
                    'bookmark_max_description' => $request->bookmark_max_description,
                    'blog_tag' => $request->blog_tag,
                    'bookmark_tag' => $request->bookmark_tag,
                ]);
            } else {
                UserLimit::create([
                    'blog_limit' => $request->blog_limit,
                    'bookmark_limit' => $request->bookmark_limit,
                    'blog_min_title' => $request->blog_min_title,
                    'blog_min_description' => $request->blog_min_description,
                    'blog_max_title' => $request->blog_max_title,
                    'blog_max_description' => $request->blog_max_description,
                    'bookmark_min_title' => $request->bookmark_min_title,
                    'bookmark_min_description' => $request->bookmark_min_description,
                    'bookmark_max_title' => $request->bookmark_max_title,
                    'bookmark_max_description' => $request->bookmark_max_description,
                    'blog_tag' => $request->blog_tag,
                    'bookmark_tag' => $request->bookmark_tag,
                ]);
            }
            return response()->json([
                'success' => true,
                'message' => ['User Limit Updated Successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while Updated User Limit on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }

    public function storePrice(Request $request)
    {
        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'content' => 'required|string',
                'status' => 'required|in:0,1'
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            $is_price = Price::first();
            if ($is_price) {
                $is_price->update([
                    'price' => $request->content,
                    'status' => $request->status,
                ]);
            } else {
                Price::create([
                    'price' => $request->content,
                    'status' => $request->status,
                ]);
            }
            return response()->json([
                'success' => true,
                'message' => ['Price Section Added Successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while Added Price Section on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }

    // public function storeContact(Request $request)
    // {

    //     $is_contact = ContactSetting::first();
    //     if ($is_contact) {
    //         $is_contact->update([
    //             'contact' => $request->content,
    //             'status' => $request->status,
    //         ]);
    //         return response()->json([
    //             'success' => true,
    //             'message' => 'ContactSetting Created Successfully'
    //         ]);
    //     } else {
    //         ContactSetting::create([
    //             'contact' => $request->content,
    //             'status' => $request->status,
    //         ]);

    //         return response()->json([
    //             'success' => true,
    //             'message' => 'ContactSetting Created Successfully'
    //         ]);
    //     }
    // }

    public function save_setting(Request $request)
    {
        try {
            // Validations
            $validator = Validator::make($request->all(), [
                'bg_image' => 'nullable|url',
                'footer_logo' => 'nullable|url',
                'header_logo' => 'nullable|url',
                'primary_color' => ['nullable', 'string', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
                'secondary_color' => ['nullable', 'string', 'regex:/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/'],
                'bg_title' => 'nullable|string',
                'bg_desc' => 'nullable|string',
                'footer_description' => 'nullable|string',
                'contact_address' => 'nullable|string',
                'contact_number' => 'nullable|string',
                'contact_email' => 'nullable|string',
                'privacy_policy' => 'nullable|string',
                'terms_and_conditions' => 'nullable|string',
                'content_policy' => 'nullable|string'
            ]);


            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }

            // Retrieve setting
            $setting = Setting::first();


            // Check if setting exists
            if ($setting) {
                // Update existing setting
                $setting->bg_image = $request->bg_image ?? $setting->bg_image;
                $setting->bg_title = $request->bg_title ?? $setting->bg_title;
                $setting->bg_desc = $request->bg_desc ?? $setting->bg_desc;
                $setting->footer_logo = $request->footer_logo ?? $setting->footer_logo;
                $setting->header_logo = $request->header_logo ?? $setting->header_logo;
                $setting->primary_color = $request->primary_color ?? $setting->primary_color;
                $setting->secondary_color = $request->secondary_color ?? $setting->secondary_color;
                $setting->footer_description = $request->footer_description ?? $setting->footer_description;
                $setting->contact_email = $request->contact_email ?? $setting->contact_email;
                $setting->contact_number = $request->contact_number ?? $setting->contact_number;
                $setting->contact_address = $request->contact_address ?? $setting->contact_address;
                $setting->privacy_policy = $request->privacy_policy ?? $setting->privacy_policy;
                $setting->terms_and_conditions = $request->terms_and_conditions ?? $setting->terms_and_conditions;
                $setting->content_policy = $request->content_policy ?? $setting->content_policy;
                $setting->save();
            } else {
                // Create new setting
                Setting::create($request->only([
                    'bg_image', 'bg_title', 'bg_desc', 'footer_logo', 'header_logo',
                    'primary_color', 'secondary_color', 'footer_description', 'privacy_policy',
                    'terms_and_conditions', 'content_policy', 'contact_address',
                    'contact_number', 'contact_email'
                ]));
            }

            // Return success response
            return response()->json([
                'success' => true,
                'message' => ['Site Theme Setting updated successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            return response()->json(
                [
                    'success' => false,
                    'message' => ['An error occurred while updated theme setting on ' . url('/') . '. Error message: ' . $e->getMessage()]
                ]
            );
        }
    }

    // public function unzipSubDomainFile(Request $request)
    // {
    //     $sub_domain = $request->sub_domain;
    //     $db_database = $request->database_username;
    //     $db_password = $request->password;

    //     $parsedUrl = parse_url(url('/'));

    //     $call_back_url = $parsedUrl['scheme'] . '://' . $sub_domain . '.' . $parsedUrl['host'] . '/auth/google/callback';

    //     $path = base_path("generate_sub_domains_script.sh");
    //     $exec = exec("bash $path $sub_domain $db_database $db_password $call_back_url");
    //     if ($exec) {
    //         return response()->json(['success' => true, 'message' => $exec]);
    //     } else {
    //         return response()->json(['success' => false, 'message' => 'not succ
    //         ess']);
    //     }
    // }
}
