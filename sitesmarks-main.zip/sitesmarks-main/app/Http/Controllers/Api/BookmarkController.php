<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Bookmark;
use App\Models\User;
use Illuminate\Http\Request;
use App\Service\ApiService;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;


class BookmarkController extends Controller
{
    use ApiService;

    public function changeStatus(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'status' => 'required|in:0,1',
                'bookmark_id' => 'required|integer|exists:bookmarks,id',
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            $bookmark = Bookmark::findOrFail($request->bookmark_id);
            if ($request->status) {
                $bookmark->status = 1;
                $bookmark->save();
            } else {
                $bookmark->delete();
            }

            return response()->json([
                'success' => true,
                'message' => [
                    'Bookmark status change successfully bookmark id: ' . $request->bookmark_id . ' on ' . url('/')
                ]
            ]);
        } catch (\Throwable $e) {
            // If an exception occurs, return error response
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while status change these bookmark id: ' . $request->bookmark_id . 'on ' . url('/')  . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }


    public function saveBookmark(Request $request)
    {
        try {
            // Retrieve user by email
            $user = User::where('email', $request->email)->first();
            $bookmarkID = Bookmark::where('bookmark_id', $request->bookmark_id)->first();
            if($bookmarkID) {
                $validator = Validator::make($request->all(), [
                    'email' => 'required|email',
                    'url' => [
                        'required',
                        'url'
                    ],
                    "bookmark_id" => 'required|integer',
                    "title" => 'required|string',
                    "category_name" => 'required|string',
                    'tags' => [
                        'required',
                        'string',
                        function ($attribute, $value, $fail) {
                            // Convert the string to array
                            $tags = json_decode($value, true);
                            if (!is_array($tags)) {
                                $fail($attribute . ' is invalid.'); // Fail if not in the expected format
                                return;
                            }

                            // Check if each item in the array has the correct structure
                            foreach ($tags as $tag) {
                                if (!isset($tag['value']) || !is_string($tag['value'])) {
                                    $fail($attribute . ' contains invalid items.'); // Fail if an item is not in the expected format
                                    return;
                                }
                            }
                        },
                    ],
                    'is_paid' => 'required|in:0,1',
                    'follow' => 'required|in:0,1',

                    "description" => 'required|string',
                    'user.name' => 'required|string',
                    'user.password' => 'required|string',
                    'user.mobile' => 'nullable|string',
                    'user.city' => 'nullable|string',
                    'user.state' => 'nullable|string',
                    'user.pincode' => 'nullable|string',
                    'user.address' => 'nullable|string',
                    'user.facebook' => 'nullable|string',
                    'user.twitter' => 'nullable|string',
                    'user.website_name' => 'nullable|url',
                    'user.bio' => 'nullable|string',
                    'user.image' => 'nullable|url',
                    'user.is_paid' =>  'required|in:0,1',
                ]);
            } else {
                $validator = Validator::make($request->all(), [
                    'email' => 'required|email',
                    'url' => [
                        'required',
                        'url',
                        $user ? Rule::unique('bookmarks')->where(function ($query) use ($user) {
                            return $query->where('user_id', $user->id);
                        }) : "",
                    ],
                    "bookmark_id" => 'required|unique:bookmarks|integer',
                    "title" => 'required|string',
                    "category_name" => 'required|string',
                    'tags' => [
                        'required',
                        'string',
                        function ($attribute, $value, $fail) {
                            // Convert the string to array
                            $tags = json_decode($value, true);
                            if (!is_array($tags)) {
                                $fail($attribute . ' is invalid.'); // Fail if not in the expected format
                                return;
                            }

                            // Check if each item in the array has the correct structure
                            foreach ($tags as $tag) {
                                if (!isset($tag['value']) || !is_string($tag['value'])) {
                                    $fail($attribute . ' contains invalid items.'); // Fail if an item is not in the expected format
                                    return;
                                }
                            }
                        },
                    ],
                    'is_paid' => 'required|in:0,1',
                    'follow' => 'required|in:0,1',

                    "description" => 'required|string',
                    'user.name' => 'required|string',
                    'user.password' => 'required|string',
                    'user.mobile' => 'nullable|string',
                    'user.city' => 'nullable|string',
                    'user.state' => 'nullable|string',
                    'user.pincode' => 'nullable|string',
                    'user.address' => 'nullable|string',
                    'user.facebook' => 'nullable|string',
                    'user.twitter' => 'nullable|string',
                    'user.website_name' => 'nullable|url',
                    'user.bio' => 'nullable|string',
                    'user.image' => 'nullable|url',
                    'user.is_paid' =>  'required|in:0,1',
                ]);
            }



            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            // Check if the User already exists
            $user = User::updateOrCreate(
                ['email' => $request->email],
                [
                    'name' => $request->user['name'],
                    'password' => $request->user['password'],
                    'mobile' => $request->user['mobile'],
                    'city' => $request->user['city'],
                    'state' => $request->user['state'],
                    'pincode' => $request->user['pincode'],
                    'address' => $request->user['address'],
                    'facebook' => $request->user['facebook'],
                    'twitter' => $request->user['twitter'],
                    'website_name' => $request->user['website_name'],
                    'bio' => $request->user['bio'],
                    'image' => $request->user['image'],

                    'is_paid' =>  $request->user['is_paid'],
                    'api_status' => 1,
                ]
            );

            Bookmark::updateOrCreate(
                ['bookmark_id' => $request->bookmark_id,],
                [
                    'user_id' => $user->id,
                    'url' => $request->url,
                    'bookmark_id' => $request->bookmark_id,
                    'cat_id' => $request->category_name,
                    'tag' => $request->tags,
                    'title' => $request->title,

                    // 'slug' => Str::slug($request->title),
                    'slug' => $this->createUniqueSlug($request->title, Bookmark::class),
                    'description' => $request->description,

                    'follow' =>  $request->follow,
                    'by_admin' => 1,
                    'is_paid' =>  $request->is_paid,

                    'status' => 1,
                    'api_status' => 1,
                ]
            );


            // Return success response
            return response()->json([
                'success' => true,
                'message' => ['Bookmark saved successfully on ' . url('/')]
            ]);
        } catch (\Throwable $e) {
            // If an exception occurs, return error response
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while saving Bookmarks on ' . url('/')  . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }

    public function newPendingBookmark()
    {

        try {
            $bookmarks = Bookmark::where('api_status', 0)
                ->where('status', 0)
                ->with('user')
                ->get();
            $failed = $this->createDataToAdminPanel($bookmarks, 'api/add/bookmark');

            return response()->json([
                'success' => true,
                'failed' =>  $failed,
                'message' => ['Get Site Pending Bookmarks successfully on ' . url('/')],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while Get Site Pending Bookmarks on ' . url('/') . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }
}
