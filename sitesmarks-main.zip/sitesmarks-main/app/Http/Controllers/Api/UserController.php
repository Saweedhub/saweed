<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Service\ApiService;
use App\Models\BlogPost;
use App\Models\Bookmark;
use App\Models\Analytic;

class UserController extends Controller
{
    use ApiService;

    public function getnewUser()
    {
        try {
            $users = User::whereApiStatus(0)->get();

          
            $failed = $this->createDataToAdminPanel($users, 'api/add/user');
      
            return response()->json([
                'success' => true,
                'failed' =>  $failed,
                'message' => ['Get Site Users successfully on ' . url('/')]
            ]);
        } catch (\Exception $e) {
            // If an exception occurs, return error response
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while Get Site Users on ' . url('/') . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }


    public function getAnalytics()
    {
        try {
            $total_visitors = Analytic::count();
            $total_views = Analytic::sum('views');
            $total_users = User::count();
            $total_bookmarks = Bookmark::count();
            $total_blogs = BlogPost::count();

            // Get total count of pending bookmarks and blogs
            $pendingBookMarks = Bookmark::whereStatus(0)->count();
            $pendingBlogs = BlogPost::whereStatus(0)->count();

            // Get total count of bookmarks and blogs by category
            $total_count_category_bookmark = Bookmark::select('cat_id')
                ->selectRaw('count(*) as count')
                ->groupBy('cat_id')
                ->orderByDesc('count')
                ->get()
                ->map(fn ($item) => ['category' => $item->cat_id, 'count' => $item->count]);

            $total_count_category_blog = BlogPost::select('cat_id')
                ->selectRaw('count(*) as count')
                ->groupBy('cat_id')
                ->orderByDesc('count')
                ->get()
                ->map(fn ($item) => ['category' => $item->cat_id ?? 'null', 'count' => $item->count]);

            // Get total count of visitors by country
            $total_count_country = Analytic::select('country')
                ->selectRaw('count(*) as visitors')
                ->groupBy('country')
                ->orderByDesc('visitors')
                ->get()
                ->map(fn ($item) => ['country' => $item->country, 'visitors' => $item->visitors]);

            return response()->json([
                'success' => true,
                'data' => compact(
                    'total_visitors',
                    'total_views',
                    'pendingBookMarks',
                    'pendingBlogs',
                    'total_users',
                    'total_bookmarks',
                    'total_blogs',
                    'total_count_category_bookmark',
                    'total_count_category_blog',
                    'total_count_country'
                )
            ]);
        } catch (\Exception $e) {
            // If an exception occurs, return error response
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while getting analytics. Error message: ' . $e->getMessage()
            ]);
        }

    }
}
