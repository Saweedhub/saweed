<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BlogPost;
use App\Models\Comment;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Service\ApiService;
use Illuminate\Support\Facades\Validator;

class BlogController extends Controller
{
    use ApiService;

    public function changeStatus(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'status' => 'required|in:0,1',
                'blog_id' => 'required|integer|exists:blog_posts,id',
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            $blog = BlogPost::findOrFail($request->blog_id);
            if ($request->status) {
                $blog->status = 1;
                $blog->save();
            } else {
                $blog->delete();
            }

            return response()->json([
                'success' => true,
                'message' => [
                    'blog status change successfully blog id: ' . $request->blog_id . ' on ' . url('/')
                ]
            ]);
        } catch (\Throwable $e) {
            // If an exception occurs, return error response
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while status change these blog id: ' . $request->blog_id . 'on ' . url('/')  . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }


    public function saveBlog(Request $request)
    {
        try {
            // Retrieve user by email
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                "blog_id" => 'required|integer',
                "title" => 'required|string',
                "category_name" => 'required|string',
                "thumbnail" => 'required|url',
                "description" => 'required|string',
                'tag' => [
                    'required',
                    'string',
                    function ($attribute, $value, $fail) {
                        // Convert the string to array
                        $tags = json_decode($value, true);
                        if (!is_array($tags)) {
                            $fail($attribute . ' is invalid.'); // Fail if not in the expected format
                            return;
                        }

                        // Check if each item in the array has the correct structure
                        foreach ($tags as $tag) {
                            if (!isset($tag['value']) || !is_string($tag['value'])) {
                                $fail($attribute . ' contains invalid items.'); // Fail if an item is not in the expected format
                                return;
                            }
                        }
                    },
                ],
                'is_paid' => 'required|in:0,1',
                'user.name' => 'required|string',
                'user.password' => 'required|string',
                'user.mobile' => 'nullable|string',
                'user.city' => 'nullable|string',
                'user.state' => 'nullable|string',
                'user.pincode' => 'nullable|string',
                'user.address' => 'nullable|string',
                'user.facebook' => 'nullable|string',
                'user.twitter' => 'nullable|string',
                'user.website_name' => 'nullable|url',
                'user.bio' => 'nullable|string',
                'user.image' => 'nullable|url',
                'user.is_paid' => 'required|in:0,1',
            ]);

            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            // Check if the User already exists
            $user = User::updateOrCreate(
                ['email' => $request->email],
                [
                    'name' => $request->user['name'],
                    'password' => $request->user['password'],
                    'mobile' => $request->user['mobile'],
                    'city' => $request->user['city'],
                    'state' => $request->user['state'],
                    'pincode' => $request->user['pincode'],
                    'address' => $request->user['address'],
                    'facebook' => $request->user['facebook'],
                    'twitter' => $request->user['twitter'],
                    'website_name' => $request->user['website_name'],
                    'bio' => $request->user['bio'],
                    'image' => $request->user['image'],

                    'is_paid' =>  $request->user['is_paid'],
                    'api_status' => 1,
                ]
            );

            // Save Blog

            BlogPost::updateOrCreate(
                ['blog_id' => $request->blog_id,],
                [
                    'user_id' => $user->id,
                    'title' => $request->title,
                    'blog_id' => $request->blog_id,
                    'slug' => $this->createUniqueSlug($request->title, BlogPost::class),
                    'cat_id' => Str::slug($request->category_name),
                    'thumbnail' => $request->thumbnail,
                    'description' => $request->description,
                    'tag' => $request->tag,

                    'is_paid' =>  $request->is_paid,

                    'by_admin' => 1,
                    'status' => 1,
                    'api_status' => 1,
                ]
            );

            // Return success response
            return response()->json([
                'success' => true,
                'message' => ['Blogs saved successfully on ' . url('/')]
            ]);
        } catch (\Throwable $e) {
            // If an exception occurs, return error response
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while saving Blogs on ' . url('/')  . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }
    public function newPendingBlog()
    {
        try {
            $blogs = BlogPost::where('api_status', 0)
                ->where('status', 0)
                ->with('user')
                ->get();
            $failed = $this->createDataToAdminPanel($blogs, 'api/add/blog');
            return response()->json([
                'success' => true,
                'failed' =>  $failed,
                'message' => ['Get Site Pending Blogs successfully on ' . url('/')],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while Get Site Pending Blogs on ' . url('/') . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }

    public function changeCommentStatus(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'status' => 'required|in:0,1',
                'comment_id' => 'required|integer|exists:comments,id',
            ]);
            // Check validation results
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => $validator->errors()->all(),
                ], 422);
            }
            $comment = Comment::findOrFail($request->comment_id);
            if ($request->status) {
                $comment->status = 1;
                $comment->save();
            } else {
                $comment->delete();
            }

            return response()->json([
                'success' => true,
                'message' => [
                    'blog comment status change successfully comment id: ' . $request->blog_id . ' on ' . url('/')
                ]
            ]);
        } catch (\Throwable $e) {
            // If an exception occurs, return error response
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while status change these comment id: ' . $request->comment . 'on ' . url('/')  . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }

    public function newBlogComment()
    {
        try {
            $comments = Comment::where('api_status', 0)
                ->where('status', 0)
                ->with('user')
                ->with('blog_post')
                ->get();

            $failed = $this->createDataToAdminPanel($comments, 'api/add/comment');
            return response()->json([
                'success' => true,
                'failed' =>  $failed,
                'message' => ['Get Site Pending Blog Comments successfully on ' . url('/')],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => ['An error occurred while Get Site Pending Blog Comments on ' . url('/') . '. Error message: ' . $e->getMessage()]
            ]);
        }
    }
}
