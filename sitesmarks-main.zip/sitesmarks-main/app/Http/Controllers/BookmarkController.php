<?php

namespace App\Http\Controllers;

use App\Models\Bookmark;
use App\Models\UserLimit;
use App\Rules\SumValidation;
use App\Service\ApiService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Symfony\Component\DomCrawler\Crawler;
use Illuminate\Validation\Rule;

class BookmarkController extends Controller
{
    use ApiService;
    public function getMetaData(Request $request)
    {

        $bookmark = Bookmark::whereUserIdAndUrl(auth()->id(), $request->url)->first();
        if ($bookmark) {
            return response()->json(['success' => false, 'message' => 'You already added these url. Please add different one. OR create a new user.']);
        } else {
            $options = [
                'http' => [
                    'header' => 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                ],
            ];
            $context = stream_context_create($options);
            $html = file_get_contents($request->url, false, $context);
            if ($html === FALSE) {
                return response()->json(['success' => false, 'message' => 'Unable to retrieve the webpage content']);
            }
            $crawler = new Crawler($html);
            $titleNode = $crawler->filter('title');
            $descriptionNode = $crawler->filter('meta[name="description"], meta[property="og:description"]');
            if ($titleNode->count() > 0 && $descriptionNode->count() > 0) {
                $title = $titleNode->text();
                $description = $descriptionNode->attr('content');
                return response()->json(['success' => true, "data" => ['title' => $title, 'description' => $description]]);
            } else {
                return response()->json(['success' => false, 'message' => 'Unable to retrieve the webpage content']);
            }
        }
    }
    public function index()
    {
        $bookmarks = Bookmark::latest()->where('user_id', auth()->id())->get();
        return view("bookmarks.list", compact("bookmarks"));
    }

    public function create()
    {
        $value1 = rand(9, 0);
        $value2 = rand(9, 0);
        return view("bookmarks.create", compact('value1', 'value2'));
    }

    public function store(Request $request)
    {
        $user_limit = UserLimit::first();
        $bookmark = Bookmark::whereUserId(auth()->id())->count();
        if ($bookmark < $user_limit->bookmark_limit || $user_limit->bookmark_limit == 0 || Auth::user()->is_paid == 1) {
            $validate = $request->validate([
                "title" => 'required|min:' . $user_limit->bookmark_min_title . '|max:' . $user_limit->bookmark_max_title,
                'cat_id' => 'required|string',
                'description' => 'required|min:' . $user_limit->bookmark_min_description . '|max:' . $user_limit->bookmark_max_description,
                'url' => [
                    'required',
                    'url',
                    Rule::unique('bookmarks')->where(function ($query) {
                        return $query->where('user_id', auth()->id());
                    })->ignore($bookmark->id ?? null),
                ],
                'keywords' => [
                    'required',
                    'string',
                    function ($attribute, $value, $fail) use ($user_limit) {
                        $tags = json_decode($value, true);
                        if (!is_array($tags)) {
                            $fail($attribute . ' is invalid.');
                            return;
                        }
                        if (count($tags) >  $user_limit->bookmark_tag) {
                            $fail($attribute . ' cannot contain more than ' . $user_limit->bookmark_tag . ' keywords.');
                            return;
                        }
                        foreach ($tags as $tag) {
                            if (!isset($tag['value']) || !is_string($tag['value'])) {
                                $fail($attribute . ' contains invalid items.');
                                return;
                            }
                        }
                    },
                ],
                'follow' => 'required|in:0,1',
                'value1' => ['required', 'numeric', 'regex:/^[0-9]$/'],
                'value2' => ['required', 'numeric', 'regex:/^[0-9]$/'],
                'captcha' => ['required', new SumValidation()],
            ]);

            $bookmark = Bookmark::create([
                'title' => $request->title,
                // 'slug' => Str::slug($request->title),
                'slug' => $this->createUniqueSlug($request->title,Bookmark::class),
                'url' => $request->url,
                'cat_id' => Str::slug($request->cat_id),
                'user_id' => auth()->id(),
                'description' => $this->sanitize_html($request->description),

                'status' => 1,
                'api_status' => 1,
                
                'tag' => $request->keywords,
                'follow' => $request->follow,
            ]);
            return to_route('bookmark.list')->with('success', 'Bookmark Added Successfully');
        } else {
            return to_route('bookmark.list')->with('error', 'Free user add only ' . $user_limit->bookmark_limit . ' bookmarks');
        }
    }

    public function edit($id, $slug)
    {
        $bookmark = Bookmark::whereSlugAndId($slug, $id)->firstOrFail();
        $value1 = rand(9, 0);
        $value2 = rand(9, 0);
        return view('bookmarks.update', compact('bookmark', 'value1', 'value2'));
    }

    public function update(Request $request, $id, $slug)
    {
        $user_limit = UserLimit::first();
        $bookmark = $bookmark = Bookmark::whereSlugAndId($slug, $id)->firstOrFail();
        if ($bookmark && $bookmark->user_id  == auth()->id()) {
            $validate = $request->validate([
                "title" => 'required|min:' . $user_limit->bookmark_min_title . '|max:' . $user_limit->bookmark_max_title,
                'cat_id' => 'required|string',
                'description' => 'required|min:' . $user_limit->bookmark_min_description . '|max:' . $user_limit->bookmark_max_description,
                'keywords' => [
                    'required',
                    'string',
                    function ($attribute, $value, $fail) use ($user_limit) {
                        $tags = json_decode($value, true);
                        if (!is_array($tags)) {
                            $fail($attribute . ' is invalid.');
                            return;
                        }
                        if (count($tags) >  $user_limit->bookmark_tag) {
                            $fail($attribute . ' cannot contain more than ' . $user_limit->bookmark_tag . ' keywords.');
                            return;
                        }
                        foreach ($tags as $tag) {
                            if (!isset($tag['value']) || !is_string($tag['value'])) {
                                $fail($attribute . ' contains invalid items.');
                                return;
                            }
                        }
                    },
                ],
                'follow' => 'required|in:0,1',
                'value1' => ['required', 'numeric', 'regex:/^[0-9]$/'],
                'value2' => ['required', 'numeric', 'regex:/^[0-9]$/'],
                'captcha' => ['required', new SumValidation()],
            ]);

            $bookmark->update([
                'title' => $request->title,
                // 'slug' => Str::slug($request->title),
                'slug' => $this->createUniqueSlug($request->title,Bookmark::class),
                'cat_id' => Str::slug($request->cat_id),
                'description' => $this->sanitize_html($request->description),
                'tag' => $request->keywords,
                'follow' => $request->follow,
            ]);
            return to_route('bookmark.list')->with('success', 'Bookmark Update Successfully');
        } else {
            return to_route('bookmark.list')->with('error', 'Un Authorized Access');
        }
    }

    public function delete($id, $slug)
    {
        $bookmark = Bookmark::whereIdAndSlug($id, $slug)->firstOrFail();
        if ($bookmark && $bookmark->user_id == auth()->id()) {
            $bookmark->delete();
            return to_route('bookmark.list')->with('success', 'Bookmark delete successfully');
        } else {
            return to_route('bookmark.list')->with('error', 'Un Authorized Access');
        }
    }
}
