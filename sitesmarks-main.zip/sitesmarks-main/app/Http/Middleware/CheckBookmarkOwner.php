<?php

namespace App\Http\Middleware;

use App\Models\Bookmark;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckBookmarkOwner
{
    public function handle(Request $request, Closure $next): Response
    {
        $bookmarkId = $request->route('id');
        $userId = auth()->id();

        // Check if the bookmark belongs to the authenticated user
        $bookmark = Bookmark::where('id', $bookmarkId)
            ->where('user_id', $userId)
            ->first();

        if (!$bookmark) {
            return redirect()->back()->with('error', 'Unauthorized access to bookmark.');
        }

        return $next($request);
    }
}
