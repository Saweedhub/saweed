<?php

namespace App\Http\Middleware;

use App\Models\Analytic;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Route;

class Analytics
{
    public function handle(Request $request, Closure $next): Response
    {
        try {

            $ip = $request->ip();
            $is_ip = Analytic::whereIp($ip)->first();
            if (!$is_ip) {

                $response = Http::get("http://www.geoplugin.net/json.gp?ip=$ip");

                if ($response->successful()) {
                    $ipdat = $response->json();

                    $country_name = $ipdat['geoplugin_countryName'];
                    $city_name = $ipdat['geoplugin_city'];

                    $analytics = new Analytic();
                    $analytics->ip = $ip;
                    $analytics->country = $country_name;
                    $analytics->city = $city_name;
                    $analytics->save();
                }
            } else {
                $is_ip->views = $is_ip->views + 1;
                $is_ip->save();
            }
        } catch (\Throwable $th) {
        }
        $response = $next($request);

        // if ($response instanceof \Illuminate\Http\Response) {
        //     $content = $response->getContent();
        //     $content = preg_replace('/\s+/', ' ', $content); 
        //     $content = preg_replace('/<!--.*?-->/', '', $content); 
        //     $response->setContent($content);
        // }
        return $response;
    }
}
