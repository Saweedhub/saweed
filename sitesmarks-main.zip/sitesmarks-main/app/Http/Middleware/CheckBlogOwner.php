<?php

namespace App\Http\Middleware;

use App\Models\BlogPost;
use App\Models\Bookmark;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckBlogOwner
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $blogId = $request->route('id');
        $userId = auth()->id();

        // Check if the bookmark belongs to the authenticated user
        $blog = BlogPost::where('id', $blogId)
            ->where('user_id', $userId)
            ->first();

        if (!$blog) {
            return redirect()->back()->with('error', 'Unauthorized access to bookmark.');
        }
        return $next($request);
    }
}
