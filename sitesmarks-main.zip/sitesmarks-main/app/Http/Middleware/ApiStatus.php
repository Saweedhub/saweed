<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Service\ApiService;
use Illuminate\Support\Facades\Crypt;

class ApiStatus
{

    public function handle(Request $request, Closure $next): Response
    {
        try {
            $api_status = ApiService::getApiSetting();
            if ($api_status['success'] == true && $api_status['setting']['api_status']== 1) {
                $bearerToken = $request->bearerToken();
                $apiToken = $api_status['setting']['token'];
                if ($bearerToken && hash_equals($bearerToken, $apiToken)) {
                    return $next($request);
                }
            }
        } catch (\Exception $e) {
        }
        return redirect('/');
    }
}
