<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TagManager extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'tag_id',
        'header_script',
        'body_script',
    ];
}
