<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FeatureBlog extends Model
{
    use HasFactory;

    protected $table = 'feature_blogs';
    protected $fillable = [
        'title',
        'blog_id',
        'email',
        'tag',
        'description',
        'thumbnail',
        'status',
    ];
    public function comments(){
        return $this->hasMany(Comment::class,'feature_id');
    }
}
