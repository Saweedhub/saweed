<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    use HasFactory;

    protected $table = 'comments';

    protected $fillable = [
        'comment',
        'user_id',
        'blog_id',
        'feature_id',
        'is_feature',
        'api_status',
        'status'
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
    public function blog_post()
    {
        return $this->belongsTo(BlogPost::class, 'blog_id');
    }
}
