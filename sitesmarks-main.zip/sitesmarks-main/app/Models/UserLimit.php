<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserLimit extends Model
{
    use HasFactory;

    protected $table = 'user_limits';
    protected $fillable = [
        'blog_limit',
        'bookmark_limit',
        'blog_min_title',
        'blog_min_description',
        'blog_max_title',
        'blog_max_description',
        'bookmark_min_title',
        'bookmark_min_description',
        'bookmark_max_title',
        'bookmark_max_description',
        'blog_tag',
        'bookmark_tag',
    ];
}
