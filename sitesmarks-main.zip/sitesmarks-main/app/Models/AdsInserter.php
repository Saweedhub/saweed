<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdsInserter extends Model
{
    use HasFactory;

    protected $table = 'ads_inserter';

    protected $fillable = [
        'name',
        'top',
        'bottom',
        'left',
        'right',
        'between',
        'inside',
    ];
}
