<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bookmark extends Model
{
    use HasFactory;

    protected $table = 'bookmarks';
    protected $fillable = [
        'url',
        'bookmark_id',
        'title',
        'slug',
        'cat_id',
        'user_id',
        'keywords',
        'tag',
        'follow',
        'description',
        'by_admin',
        'is_paid',
        'status',
        'api_status',
    ];

    // public function category()
    // {
    //     return $this->belongsTo(Category::class, 'cat_id');
    // }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
