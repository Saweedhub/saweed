<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BlogPost extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'blog_id',
        'title',
        'slug',
        'cat_id',
        'thumbnail',
        'description',
        'tag',
        'is_paid',
        'by_admin',
        'status',
        'api_status',
    ];
    // public function category()
    // {
    //     return $this->belongsTo(Category::class, 'cat_id');
    // }
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function comments(){
        return $this->hasMany(Comment::class,'blog_id');
    }
}
