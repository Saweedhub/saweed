<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SellBanner extends Model
{
    use HasFactory;

    protected $table = 'sell_banners';

    protected $fillable = [
        'sell_banners',
        'status'
    ];
}
