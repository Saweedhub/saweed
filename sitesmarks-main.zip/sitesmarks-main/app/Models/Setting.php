<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    use HasFactory;
    protected $fillable = [
        'bg_image', 'bg_title', 'bg_desc', 'footer_logo', 'header_logo',
        'primary_color', 'secondary_color', 'footer_description', 'privacy_policy',
        'terms_and_conditions', 'content_policy','contact_address',
        'contact_number','contact_email'
    ];
}
