@extends('layouts.app')
@section('title')
    Home
@endsection
@section('content')
    <div>
        <x-authbreadcrumb :name="date('Y') . '  Free DoFollow Bookmarks'" />

        <div class="my-10">
            <h1 class="text-center text-4xl mt-[30px]">Update Blog</h1>
        </div>
        <div class="container mx-auto px-3 md:px-10 my-4">
            <div class=" block lg:flex items-start gap-5">
                <div class="lg:w-[70%] w-full">
                    <div class=" flex items-center justify-center">
                        <div class="container max-w-screen-lg mx-auto">
                            <div>
                                <div class="bg-zinc-50 border rounded p-4 px-4 mb-6">
                                    <form method="POST" enctype="multipart/form-data"
                                        action="{{ route('blog.update', ['id' => $blog->id, 'slug' => $blog->slug]) }}"
                                        class="grid gap-4  text-sm grid-cols-1 lg:grid-cols-1">
                                        @csrf
                                        @honeypot
                                        <div class="">
                                            <div class="block gap-4 gap-y-2 text-sm grid-cols-1 md:grid-cols-5 my-2 "
                                                id="remaning_fields">
                                                <div class="md:col-span-5 my-2">
                                                    <label for="full_name">Title</label>
                                                    <input type="text" name="title" id="title"
                                                        class="h-10 border mt-1 rounded px-4 w-full bg-gray-50 focus:bg-white"
                                                        value="{{ old('title') == '' ? $blog->title : old('title') }}" />
                                                    @error('title')
                                                        <span class="text-red-500">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <div class="md:col-span-5 my-2">
                                                    <label for="full_name">Choose Category</label>
                                                    <select name="cat_id" id=""
                                                        class="h-10 border mt-1 rounded px-4 w-full bg-gray-50">
                                                        <option value="">Choose Category</option>
                                                        @foreach ($categories as $category)
                                                            @php
                                                                $category_name = Illuminate\Support\Str::slug(
                                                                    $category['name'],
                                                                );
                                                            @endphp
                                                            <option @selected(old('cat_id') == '' ? $category_name == $blog->cat_id : $category['name'] == old('cat_id'))
                                                                value="{{ $category['name'] }}">
                                                                {{ $category['name'] }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                    @error('cat_id')
                                                        <span class="text-red-500">{{ $message }}</span>
                                                    @enderror
                                                </div>

                                                <div class="md:col-span-5 my-2">
                                                    <label for="email">Enter the Tag</label>
                                                    <input type="text" name="keywords" id="keywords"
                                                        class="h-10 border mt-1 rounded px-4 w-full bg-gray-50 focus:bg-white"
                                                        value="{{ old('keywords') == '' ? $blog->tag : old('keywords') }}"
                                                        placeholder="Enter the Tags:" />
                                                    @error('tag')
                                                        <span class="text-red-500">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <div class="md:col-span-5 my-2">
                                                    <label class="text-gray-800 font-semibold block my-3 text-md"
                                                        for="thumbnail">Upload Thumbnail</label>
                                                    <input
                                                        class="mt-1 w-full  cursor-pointer rounded border 
                                                            bg-transparent px-3 py-[0.32rem] text-base 
                                                            font-normal file:-mx-3 file:-my-[0.32rem] file:me-3 
                                                            file:cursor-pointer  file:border-0 file:border-e file:border-solid 
                                                            file:border-inherit file:px-3  file:py-[0.32rem] file:text-surfac"
                                                        type="file" name="thumbnail" onchange="previewImage(event)"
                                                        id="thumbnail" />
                                                    <label id="charCount" class="block text-end">Max
                                                        File upload 1MB</label>
                                                    <div id="imagePreview" class="mt-2"></div>
                                                    @if ($blog->thumbnail)
                                                        <img id="previousThumbnail"
                                                            src="{{ asset('storage/' . $blog->thumbnail) }}"
                                                            class="mt-2 w-full max-h-[28em] object-cover img-fluid mx-auto">
                                                    @endif

                                                    @error('thumbnail')
                                                        <span class="text-red-500">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <div class="md:col-span-5 my-2">
                                                    <label class="text-gray-800 font-semibold block my-3 text-md"
                                                        for="editor">Enter the Description</label>
                                                    <textarea name="description" id="editor" class="focus:bg-white border mt-1 rounded px-4 w-full bg-gray-50">{{ old('description') }}</textarea>
                                                    <label id="charCount2" class=" text-end block"></label>
                                                    @error('description')
                                                        <span class="text-red-500">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <div class="md:col-span-5 my-2">
                                                    <label for="email">Captcha : <span
                                                            id="value1">{{ $value1 }}</span> + <span
                                                            id="value2">{{ $value2 }}</span> = </label>
                                                    <input type="hidden" name="value1" value="{{ $value1 }}"
                                                        id="">
                                                    <input type="hidden" name="value2" value="{{ $value2 }}"
                                                        id="">
                                                    <input type="text" name="captcha" id="captcha"
                                                        class="h-10 border mt-1 rounded px-4 w-full bg-gray-50 focus:bg-white"
                                                        value="" placeholder="Enter Captcha:" />

                                                    @error('captcha')
                                                        <span class="text-red-500">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <div class="md:col-span-5 text-right mt-3">
                                                    <div class="inline-flex items-end">
                                                        <button type="submit"
                                                            class="secondary_color text-white font-bold py-2 px-4 rounded">Update</button>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @include('includes.profile-sidebar')
            </div>
        </div>
    </div>
@endsection
@section('script')
    <script src="{{ asset('vendor/tinymce/js/tinymce/tinymce.min.js') }}"></script>

    @php
        $user_limit = \App\Models\UserLimit::first();
    @endphp
    <script>
        if (typeof(tinyMCE) != "undefined") {
            function tinymceEditor(target, button, height = 200, content) {
                var rtl = $("html[lang=ar]").attr('dir');
                limit = ' {{ $user_limit->blog_max_description }}';
                tinymce.init({

                    menubar: false,
                    statusbar: false,
                    toolbar: false,
                    selector: target || '.textarea',
                    directionality: rtl,
                    height: height,
                    plugins: ['advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview', 'anchor',
                        'searchreplace', 'visualblocks', 'fullscreen', 'insertdatetime', 'media',
                        'table', 'help', 'wordcount'
                    ],
                    toolbar: 'undo redo | blocks | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | image media link table | removeformat preview fullscreen',
                    content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }',
                    automatic_uploads: false,

                    setup: function(editor) {
                        editor.on('init', function() {
                            editor.setContent(content);
                            const charCountLabel = document.getElementById('charCount2');
                            charCountLabel.textContent =
                                `0 / ${limit} Characters`;
                            editor.on('keyup', function() {
                                var characterLength = editor.getContent().length;
                                charCountLabel.textContent =
                                    `${characterLength}  / ${limit} Characters`;
                            });
                        });
                    }
                });
            }
        }
        tinymceEditor('#editor', function(ed) {}, 450, {!! json_encode(old('description') == '' ? $blog->description ?? '' : old('description')) !!})

        var input = document.querySelector('input[name=keywords]');
        new Tagify(input, {
            maxTags: {{ $user_limit->blog_tag }}
        })

        function previewImage(event) {

            document.getElementById('previousThumbnail').hidden = true

            var input = event.target;
            var reader = new FileReader();

            reader.onload = function() {
                var imagePreview = document.getElementById('imagePreview');
                imagePreview.innerHTML = '<img src="' + reader.result +
                    '" class="w-full max-h-[28em] object-cover img-fluid mx-auto" />';
            };
            reader.readAsDataURL(input.files[0]);
        }
    </script>
@endsection
