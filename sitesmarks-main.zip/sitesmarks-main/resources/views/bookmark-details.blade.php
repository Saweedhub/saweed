@extends('layouts.app')
@section('seo')
    <title>{{ $bookmark->title }} - {{ env('APP_NAME') }}</title>
    <meta name="description" content="{{ Illuminate\Support\Str::limit(strip_tags($bookmark->description), 160, '.....') }}">
    <meta name="author" content="{{ $bookmark->user->name }}">
@endsection
@section('content')
    <style>
        .bookmark-desc a {
            color: {{ $setting->primary_color }};
            text-decoration: none;
            font-weight: bold;

        }

        .bookmark-desc p {
            font-size: 16px;
            line-height: 1.5;
            color: black;
            /* Default text color */
        }

        .bookmark-desc a:hover {
            text-decoration: underline;
        }
    </style>
    <x-breadcrumb :name="$bookmark->title" :page="$bookmark->title" :category="'Bookmarks'" />
    <section class="container mx-auto px-3 md:px-10 my-4 block lg:flex items-start gap-5">

        <div class="lg:w-[70%] w-full">
            <div class="mt-4">
                <x-ads-section :name="'screens'" :position="'top'" />
            </div>
            <div class="bg-white p-8 mb-2">
                <div class="flex my-4 justify-between">
                    <di class="flex">
                        <div class="h-6 w-1 mr-2 rounded bg-[#b91c1c]"></div>
                        <p>{{ $bookmark->cat_id }}</p>
                    </di>
                    <div class="flex items-center space-x-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="w-4 h-4">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                        </svg>
                        <x-bookmark-share :bookmark="$bookmark" :bookmark_url="'{{ request()->fullUrl() }}'" />
                    </div>
                </div>
                <a class=" font-bold text-3xl mt-2 underline-hover-effect">
                    {{ $bookmark->title }}
                </a>


                <p class="mt-5 mb-3">
                    By
                    <a class="flip-animate text-red-600">
                        <span data-hover="{{ $bookmark->user->name }}">
                            {{ $bookmark->user->name }}
                        </span>
                    </a>
                    At
                    <span class="text-red-600">
                        {{ date('Y-m-d', strtotime($bookmark->created_at)) }}
                    </span>
                </p>

                <p class="mb-3">
                    User Website : <a href="{{ $bookmark->url }}" target="_blank"
                        rel="{{ $bookmark->follow ? 'dofollow' : 'nofollow' }}"
                        class="text-blue-500 font-bold">{{ Illuminate\Support\Str::limit($bookmark->url, 60, '......') }}</a>
                </p>
                <div class="mb-4">
                    <x-ads-section :name="'screens'" :position="'inside'" />
                </div>

                <div class="bookmark-desc font-light text-xl my-2">
                    {!! $bookmark->description !!}
                </div>

                <div class="flex justify-start gap-2 flex-wrap my-4">
                    <span>Tags: </span>
                    @foreach (json_decode($bookmark->tag) as $tag)
                        <span class="bg-gray-100 rounded-full px-3 py-1 text-sm font-semibold text-gray-600">
                            #{{ $tag->value }}</span>
                    @endforeach
                </div>

                <div class="my-4" style="margin-top: 20px">
                    <span>Categories: </span>
                    <a href="{{ route('user.category', ['slug' => Illuminate\Support\Str::slug($bookmark->cat_id)]) }}"
                        style="    background-color: #e3e1e1;
                                        padding: 5px 26px  ;
                                        border-radius: 6px;
                                        margin-left: 10px;">{{ str_replace('-', ' ', $bookmark->cat_id) }}</a>
                </div>
            </div>
            @if (count($user_bookmarks) > 0)
                <h2 class="my-3 block text-2xl">Other Submission of {{ $bookmark->user->name }}</h2>
            @endif

            @foreach ($user_bookmarks as $user_bookmark)
                @php
                    $category = Illuminate\Support\Str::slug($user_bookmark->cat_id);
                    $user_bookmark_url = "/bookmarks/$category/$user_bookmark->slug";
                @endphp
                <div class=" px-4 py-2 my-4 rounded-xl border">
                    <header class="flex font-light text-sm my-4  justify-between">
                        <div class="flex">
                            <div class="h-6 w-1 mr-2 rounded bg-[#b91c1c]"></div>
                            <p>{{ $user_bookmark->cat_id }}</p>
                        </div>

                        @if ($user_bookmark->is_paid && $user_bookmark->by_admin)
                            <button class="secondary_color px-4 py-2 text-white rounded-full flex gap-2">
                                <svg class="w-4 h-4 m-auto" viewBox="0 0 84 84" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M41.6667 83.3333C64.6785 83.3333 83.3333 64.6785 83.3333 41.6667C83.3333 18.6548 64.6785 0 41.6667 0C18.6548 0 0 18.6548 0 41.6667C0 64.6785 18.6548 83.3333 41.6667 83.3333Z"
                                        fill="url(#paint0_linear_217_147)" />
                                    <path
                                        d="M41.6667 77.0833C61.2267 77.0833 77.0833 61.2267 77.0833 41.6667C77.0833 22.1066 61.2267 6.25 41.6667 6.25C22.1066 6.25 6.25 22.1066 6.25 41.6667C6.25 61.2267 22.1066 77.0833 41.6667 77.0833Z"
                                        fill="#F5BE00" />
                                    <path
                                        d="M52.604 48.6497C52.604 37.9393 36.7915 40.0309 36.7915 33.7038C36.7915 30.4018 40.5061 30.2268 41.6665 30.2268C44.4582 30.2268 47.1519 30.9747 49.2061 31.9393C49.854 32.2434 50.5978 31.7934 50.5978 31.0788V27.9622C50.5978 26.9163 50.204 26.2976 49.5769 26.0518C48.1686 25.5059 46.1478 25.1038 43.1561 25.0059V21.5768C43.1561 21.1663 42.8228 20.833 42.4123 20.833H40.9248C40.5144 20.833 40.1811 21.1663 40.1811 21.5768V25.0622C35.5394 25.5122 30.729 28.1309 30.729 34.2205C30.729 45.3226 46.5415 43.1205 46.5415 48.9684C46.5415 50.8059 45.3665 52.3893 41.6665 52.3893C37.9457 52.3893 34.5269 51.0893 32.6353 50.1226C31.9978 49.7976 31.2478 50.2684 31.2478 50.9851V54.533C31.2478 55.2143 31.6561 55.8184 32.2853 56.083C34.5269 57.0351 37.5353 57.7559 40.179 57.9663V61.758C40.179 62.1684 40.5123 62.5018 40.9228 62.5018H42.4103C42.8207 62.5018 43.154 62.1684 43.154 61.758V57.9768C50.0936 57.3976 52.604 52.7497 52.604 48.6497Z"
                                        fill="#FEE119" />
                                    <defs>
                                        <linearGradient id="paint0_linear_217_147" x1="13.0687" y1="13.0667"
                                            x2="71.0667" y2="71.0687" gradientUnits="userSpaceOnUse">
                                            <stop stop-color="#FEDE00" />
                                            <stop offset="1" stop-color="#FFD000" />
                                        </linearGradient>
                                    </defs>
                                </svg>
                                Sponsored
                            </button>
                        @endif
                    </header>
                    <div class="flex items-start ">
                        <img class="w-12 h-12 rounded-full object-cover mr-4 shadow"
                            src="{{ $user_bookmark->user->image ? (Str::startsWith($user_bookmark->user->image, ['http://', 'https://']) ? $user_bookmark->user->image : asset('storage/' . $user_bookmark->user->image)) : '/assets/images/user_profile_placeholder.webp' }}"
                            loading="lazy" alt="avatar">

                        <div class="w-full break-all">
                            <div class="flex">

                                <a href="{{ $user_bookmark_url }}"
                                    class="break-all text-lg font-semibold text_color -mt-1 underline-hover-effect">{{ $user_bookmark->title }}
                                </a>

                            </div>
                            <div class="flex items-center space-x-4 flex-wrap  mt-2 ">
                                <div>
                                    <span class="text-gray-700">Submited By</span>
                                    <a class="flip-animate break-all" href="{{ $user_bookmark_url }}">
                                        <span data-hover="{{ $user_bookmark->user->name }}">
                                            {{ $user_bookmark->user->name }}
                                        </span>
                                    </a>
                                </div>

                                <div class="break-all flex items-center space-x-2 ">
                                    <svg class="w-4 h-4" viewBox="0 0 84 92" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M34 0V6H38V8.19531C16.7006 10.2149 0 28.1776 0 50C0 73.1723 18.8277 92 42 92C65.1723 92 84 73.1723 84 50C84 28.1776 67.2994 10.2149 46 8.19531V6H50V0H34ZM72.4727 6.29297L68.4609 10.3047L77.6914 19.5352L81.7031 15.5234L72.4727 6.29297ZM42 12C63.0105 12 80 28.9895 80 50C80 71.0105 63.0105 88 42 88C20.9895 88 4 71.0105 4 50C4 28.9895 20.9895 12 42 12ZM21.9805 27.9805C21.5826 27.9806 21.1938 28.0993 20.8638 28.3216C20.5338 28.5438 20.2775 28.8594 20.1278 29.228C19.9781 29.5966 19.9417 30.0015 20.0233 30.3909C20.1049 30.7803 20.3008 31.1366 20.5859 31.4141L38.1406 48.9688C38.049 49.3049 38.0018 49.6516 38 50C38 51.0609 38.4214 52.0783 39.1716 52.8284C39.9217 53.5786 40.9391 54 42 54C42.3495 53.9999 42.6976 53.9539 43.0352 53.8633L46.5859 57.4141C46.7702 57.606 46.991 57.7593 47.2352 57.8648C47.4795 57.9704 47.7423 58.0262 48.0084 58.0289C48.2745 58.0316 48.5385 57.9812 48.7848 57.8806C49.0312 57.78 49.255 57.6313 49.4431 57.4431C49.6313 57.255 49.78 57.0312 49.8806 56.7848C49.9812 56.5385 50.0316 56.2745 50.0289 56.0084C50.0262 55.7423 49.9704 55.4795 49.8648 55.2352C49.7593 54.991 49.606 54.7702 49.4141 54.5859L45.8594 51.0312C45.951 50.6951 45.9982 50.3484 46 50C46 48.9391 45.5786 47.9217 44.8284 47.1716C44.0783 46.4214 43.0609 46 42 46C41.6505 46.0001 41.3024 46.0461 40.9648 46.1367L23.4141 28.5859C23.2277 28.3943 23.0048 28.2421 22.7586 28.1381C22.5123 28.0341 22.2478 27.9805 21.9805 27.9805Z"
                                            fill="black" />
                                    </svg>
                                    <span class="text_color">about
                                        {{ $user_bookmark->created_at->diffForHumans() }}
                                    </span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                                    </svg>

                                    <x-bookmark-share :bookmark="$user_bookmark" :bookmark_url="$user_bookmark_url" />

                                </div>
                                <a href="{{ $user_bookmark_url }}" class="flex items-center space-x-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 0 1-2.555-.337A5.972 5.972 0 0 1 5.41 20.97a5.969 5.969 0 0 1-.474-.065 4.48 4.48 0 0 0 .978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25Z" />
                                    </svg>
                                    <span class="text_color">0 Comment</span>
                                </a>
                            </div>
                            <div class="flex break-all items-center -ml-2 my-2">
                                <div class="flex items-center space-x-2 ml">
                                    <img src="{{ asset('assets/browser-svg.svg') }}" class="h-5 w-5"
                                        alt="user_bookmark-url.svg">
                                    </svg>

                                    <a href="{{ $user_bookmark->url }}" target="_blank"
                                        rel="{{ $user_bookmark->follow ? 'dofollow' : 'nofollow' }}"
                                        class="break-all text-blue-500 hover:underline">{{ Illuminate\Support\Str::limit($user_bookmark->url, 90, '.....') }}</a>
                                </div>
                            </div>
                            <div class="break-all flex items-center -ml-2 my-2 flex-wrap ">
                                @if ($user_bookmark->user->mobile)
                                    <div class="flex items-center space-x-2 mr-8">
                                        <img src="{{ asset('assets/phone-svg.svg') }}" class="h-5 w-5" alt="phone.svg">

                                        </svg>


                                        <span class="text_color ">{{ $user_bookmark->user->mobile }}</span>
                                    </div>
                                @endif
                                <div class="flex items-center space-x-2 ">
                                    <img src="{{ asset('assets/mail-svg.svg') }}" class="h-5 w-5" alt="mail.svg">
                                    <span class="text_color break-all">{{ $user_bookmark->user->email }}</span>
                                </div>


                            </div>
                            @if ($user_bookmark->user->address)
                                <div class="break-all flex items-center space-x-2 -ml-2">
                                    <img src="{{ asset('assets/contact-svg.svg') }}" class="h-5 w-5" alt="address.svg">

                                    <span class="text_color break-all">{{ $user_bookmark->user->address }}</span>
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="mb-4">
                        <x-ads-section :name="'bookmark-list'" :position="'inside'" />
                    </div>
                    <p class="mt-3 text-gray-700 text-sm" style="margin-bottom: 20px;">
                        {!! Illuminate\Support\Str::limit($user_bookmark->description, 250, '.....') !!}
                    </p>
                    <button onclick="window.open('{{ $user_bookmark_url }}','_self')"
                        class="readmorebutton secondary_color rounded px-4 py-2 text-lg text-white tracking-wide font-semibold font-sans"><span>Read
                            More</span></button>

                </div>
                <div class="mb-4">
                    <x-ads-section :name="'bookmark-list'" :position="'between'" />
                </div>
            @endforeach
            {{ $user_bookmarks->appends(['user_bookmarks' => $user_bookmarks->currentPage()])->links() }}
            <div class="h-10"></div>
            <section>
                <div class="my-3">
                    <h2 class="text-2xl">{{ $bookmark->user->name }} Details</h2>
                </div>
                <div class=" block lg:flex items-start gap-5">
                    <div class="w-full">
                        <div class="bg-white overflow-hidden shadow rounded-lg border">
                            <div class="px-4 py-5 sm:px-6">
                                <h3 class="text-lg leading-6 font-medium text-gray-900">
                                    User Profile
                                </h3>
                            </div>
                            <div class="border-t border-gray-200 px-4 py-5 sm:p-0">
                                <dl class="sm:divide-y sm:divide-gray-200">
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            Full name
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ $bookmark->user->name }}
                                        </dd>
                                    </div>
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            Email address
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ $bookmark->user->email }}
                                        </dd>
                                    </div>
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            Join Date
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ date('Y-m-d', strtotime($bookmark->user->created_at)) }}
                                        </dd>
                                    </div>
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            State
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ $bookmark->user->state }}
                                        </dd>
                                    </div>
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            City
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ $bookmark->user->city }}
                                        </dd>
                                    </div>
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            Pincode
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ $bookmark->user->pincode }}
                                        </dd>
                                    </div>
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            Address
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ $bookmark->user->address }}
                                        </dd>
                                    </div>
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            Follow us on Facebook
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ $bookmark->user->facebook }}
                                        </dd>
                                    </div>
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            Follow us on Twitter
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ $bookmark->user->twitter }}
                                        </dd>
                                    </div>
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            Website Name
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ $bookmark->user->website_name }}
                                        </dd>
                                    </div>
                                    <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                        <dt class="text-sm font-medium text-gray-500">
                                            Bio
                                        </dt>
                                        <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                            {{ $bookmark->user->bio }}
                                        </dd>
                                    </div>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="my-10">
                <h2 class="text-2xl">Other Related Submission Of {{ $bookmark->cat_id }}</h2>
            </div>
            @foreach ($bookmarks as $bookmark1)
                @php
                    $categor1 = Illuminate\Support\Str::slug($bookmark1->cat_id);
                    $bookmark1_url = "/bookmarks/$categor1/$bookmark1->slug";
                @endphp
                <div class=" px-4 py-2 my-4 rounded-xl border">
                    <header class="flex font-light text-sm my-4  justify-between">
                        <div class="flex">
                            <div class="h-6 w-1 mr-2 rounded bg-[#b91c1c]"></div>
                            <p>{{ $bookmark1->cat_id }}</p>
                        </div>

                        @if ($bookmark1->is_paid && $bookmark1->by_admin)
                            <button class="secondary_color px-4 py-2 text-white rounded-full flex gap-2">
                                <svg class="w-4 h-4 m-auto" viewBox="0 0 84 84" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M41.6667 83.3333C64.6785 83.3333 83.3333 64.6785 83.3333 41.6667C83.3333 18.6548 64.6785 0 41.6667 0C18.6548 0 0 18.6548 0 41.6667C0 64.6785 18.6548 83.3333 41.6667 83.3333Z"
                                        fill="url(#paint0_linear_217_147)" />
                                    <path
                                        d="M41.6667 77.0833C61.2267 77.0833 77.0833 61.2267 77.0833 41.6667C77.0833 22.1066 61.2267 6.25 41.6667 6.25C22.1066 6.25 6.25 22.1066 6.25 41.6667C6.25 61.2267 22.1066 77.0833 41.6667 77.0833Z"
                                        fill="#F5BE00" />
                                    <path
                                        d="M52.604 48.6497C52.604 37.9393 36.7915 40.0309 36.7915 33.7038C36.7915 30.4018 40.5061 30.2268 41.6665 30.2268C44.4582 30.2268 47.1519 30.9747 49.2061 31.9393C49.854 32.2434 50.5978 31.7934 50.5978 31.0788V27.9622C50.5978 26.9163 50.204 26.2976 49.5769 26.0518C48.1686 25.5059 46.1478 25.1038 43.1561 25.0059V21.5768C43.1561 21.1663 42.8228 20.833 42.4123 20.833H40.9248C40.5144 20.833 40.1811 21.1663 40.1811 21.5768V25.0622C35.5394 25.5122 30.729 28.1309 30.729 34.2205C30.729 45.3226 46.5415 43.1205 46.5415 48.9684C46.5415 50.8059 45.3665 52.3893 41.6665 52.3893C37.9457 52.3893 34.5269 51.0893 32.6353 50.1226C31.9978 49.7976 31.2478 50.2684 31.2478 50.9851V54.533C31.2478 55.2143 31.6561 55.8184 32.2853 56.083C34.5269 57.0351 37.5353 57.7559 40.179 57.9663V61.758C40.179 62.1684 40.5123 62.5018 40.9228 62.5018H42.4103C42.8207 62.5018 43.154 62.1684 43.154 61.758V57.9768C50.0936 57.3976 52.604 52.7497 52.604 48.6497Z"
                                        fill="#FEE119" />
                                    <defs>
                                        <linearGradient id="paint0_linear_217_147" x1="13.0687" y1="13.0667"
                                            x2="71.0667" y2="71.0687" gradientUnits="userSpaceOnUse">
                                            <stop stop-color="#FEDE00" />
                                            <stop offset="1" stop-color="#FFD000" />
                                        </linearGradient>
                                    </defs>
                                </svg>
                                Sponsored
                            </button>
                        @endif
                    </header>
                    <div class="flex items-start ">
                        <img class="w-12 h-12 rounded-full object-cover mr-4 shadow"
                            src="{{ $bookmark1->user->image ? (Str::startsWith($bookmark1->user->image, ['http://', 'https://']) ? $bookmark1->user->image : asset('storage/' . $bookmark1->user->image)) : '/assets/images/user_profile_placeholder.webp' }}"
                            loading="lazy" alt="avatar">

                        <div class="w-full break-all">
                            <div class="flex">

                                <a href="{{ $bookmark1_url }}"
                                    class="break-all text-lg font-semibold text_color -mt-1 underline-hover-effect">{{ $bookmark1->title }}
                                </a>

                            </div>
                            <div class="flex break-all items-center space-x-4 flex-wrap  mt-2 ">
                                <div>
                                    <span class="text-gray-700">Submited By</span>
                                    <a class="flip-animate break-all" href="{{ $bookmark1_url }}">
                                        <span data-hover="{{ $bookmark1->user->name }}">
                                            {{ $bookmark1->user->name }}
                                        </span>
                                    </a>
                                </div>

                                <div class="flex break-all items-center space-x-2 ">
                                    <svg class="w-4 h-4" viewBox="0 0 84 92" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M34 0V6H38V8.19531C16.7006 10.2149 0 28.1776 0 50C0 73.1723 18.8277 92 42 92C65.1723 92 84 73.1723 84 50C84 28.1776 67.2994 10.2149 46 8.19531V6H50V0H34ZM72.4727 6.29297L68.4609 10.3047L77.6914 19.5352L81.7031 15.5234L72.4727 6.29297ZM42 12C63.0105 12 80 28.9895 80 50C80 71.0105 63.0105 88 42 88C20.9895 88 4 71.0105 4 50C4 28.9895 20.9895 12 42 12ZM21.9805 27.9805C21.5826 27.9806 21.1938 28.0993 20.8638 28.3216C20.5338 28.5438 20.2775 28.8594 20.1278 29.228C19.9781 29.5966 19.9417 30.0015 20.0233 30.3909C20.1049 30.7803 20.3008 31.1366 20.5859 31.4141L38.1406 48.9688C38.049 49.3049 38.0018 49.6516 38 50C38 51.0609 38.4214 52.0783 39.1716 52.8284C39.9217 53.5786 40.9391 54 42 54C42.3495 53.9999 42.6976 53.9539 43.0352 53.8633L46.5859 57.4141C46.7702 57.606 46.991 57.7593 47.2352 57.8648C47.4795 57.9704 47.7423 58.0262 48.0084 58.0289C48.2745 58.0316 48.5385 57.9812 48.7848 57.8806C49.0312 57.78 49.255 57.6313 49.4431 57.4431C49.6313 57.255 49.78 57.0312 49.8806 56.7848C49.9812 56.5385 50.0316 56.2745 50.0289 56.0084C50.0262 55.7423 49.9704 55.4795 49.8648 55.2352C49.7593 54.991 49.606 54.7702 49.4141 54.5859L45.8594 51.0312C45.951 50.6951 45.9982 50.3484 46 50C46 48.9391 45.5786 47.9217 44.8284 47.1716C44.0783 46.4214 43.0609 46 42 46C41.6505 46.0001 41.3024 46.0461 40.9648 46.1367L23.4141 28.5859C23.2277 28.3943 23.0048 28.2421 22.7586 28.1381C22.5123 28.0341 22.2478 27.9805 21.9805 27.9805Z"
                                            fill="black" />
                                    </svg>
                                    <span class="text_color">about {{ $bookmark1->created_at->diffForHumans() }}
                                    </span>
                                </div>
                                <div class="flex break-all items-center space-x-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                                    </svg>
                                    <x-bookmark-share :bookmark="$bookmark1" :bookmark_url="$bookmark1_url" />
                                </div>
                                <a href="{{ $bookmark1_url }}" class="flex items-center space-x-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 0 1-2.555-.337A5.972 5.972 0 0 1 5.41 20.97a5.969 5.969 0 0 1-.474-.065 4.48 4.48 0 0 0 .978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25Z" />
                                    </svg>
                                    <span class="text_color">0 Comment</span>
                                </a>
                            </div>
                            <div class="flex break-all items-center -ml-2 my-2">
                                <div class="flex items-center space-x-2 ml">
                                    <img src="{{ asset('assets/browser-svg.svg') }}" class="h-5 w-5"
                                        alt="bookmark-url.svg">
                                    </svg>

                                    <a href="{{ $bookmark1->url }}" target="_blank"
                                        rel="{{ $bookmark1->follow ? 'dofollow' : 'nofollow' }}"
                                        class="break-all text-blue-500 hover:underline">{{ Illuminate\Support\Str::limit($bookmark1->url, 90, '.....') }}</a>
                                </div>
                            </div>
                            <div class="flex break-all items-center -ml-2 my-2 flex-wrap ">
                                @if ($bookmark1->user->mobile)
                                    <div class="flex items-center space-x-2 mr-8">
                                        <img src="{{ asset('assets/phone-svg.svg') }}" class="h-5 w-5" alt="phone.svg">

                                        </svg>


                                        <span class="text_color break-all">{{ $bookmark1->user->mobile }}</span>
                                    </div>
                                @endif
                                <div class="flex break-all items-center space-x-2 ">
                                    <img src="{{ asset('assets/mail-svg.svg') }}" class="h-5 w-5" alt="mail.svg">
                                    <span class="text_color break-all">{{ $bookmark1->user->email }}</span>
                                </div>


                            </div>
                            @if ($bookmark1->user->address)
                                <div class="flex break-all items-center space-x-2 -ml-2">
                                    <img src="{{ asset('assets/contact-svg.svg') }}" class="h-5 w-5" alt="address.svg">

                                    <span class="text_color break-all">{{ $bookmark1->user->address }}</span>
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="mb-4">
                        <x-ads-section :name="'bookmark-list'" :position="'inside'" />
                    </div>
                    <p class="mt-3 text-gray-700 text-sm" style="margin-bottom: 20px;">

                        {!! Illuminate\Support\Str::limit($bookmark1->description, 250, '.....') !!}
                    </p>
                    <button onclick="window.open('{{ $bookmark1_url }}','_self')"
                        class="readmorebutton secondary_color rounded px-4 py-2 text-lg text-white tracking-wide font-semibold font-sans"><span>Read
                            More</span></button>

                </div>
                <div class="mb-4">
                    <x-ads-section :name="'bookmark-list'" :position="'between'" />
                </div>
            @endforeach
            {{ $bookmarks->appends(['bookmarks' => $bookmarks->currentPage()])->links() }}
            <div class="h-10"></div>

        </div>
        @include('includes.sidebar')
    </section>
@endsection
