<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>{{ env("APP_URL") }}</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ env("APP_URL") }}/bookmarks</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ env("APP_URL") }}/blogs</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ env("APP_URL") }}/contact</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ env("APP_URL") }}/login</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ env("APP_URL") }}/register</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ env("APP_URL") }}/privacy-policy</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ env("APP_URL") }}/terms-and-condition</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ env("APP_URL") }}/content-policy</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ env("APP_URL") }}/about-us</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ env("APP_URL") }}/bookmarks/featured</loc>
        <lastmod>{{ \Carbon\Carbon::yesterday()->format("Y-m-d\TH:i:sP") }}</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.9</priority>
    </url>
    <?php foreach ($urls as $url): ?>
        <url>
            <loc>{{ $url["loc"] }}</loc>
            <lastmod>{{ $url["lastmod"] }}</lastmod>
            <changefreq>{{ $url["changefreq"] }}</changefreq>
            <priority>{{ $url["priority"] }}</priority>
        </url>
    <?php endforeach; ?>
</urlset>



