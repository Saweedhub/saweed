<div class="flex flex-col lg:w-[30%] w-full lg:mt-0 mt-2">
    <div class="mb-4">
        <x-ads-section :name="'sidebar'" :position="'top'" />
    </div>
    <div class="  bg-zinc-50">
        @php
            $promotions = \App\Models\Promotion::latest('id')->get();
        @endphp
        <div class="bg-zinc-50">
            <div id="ad_slider" class=" owl-carousel owl-theme">
                @foreach ($promotions as $ad_promotion)
                    @php
                        $url = $ad_promotion->image;
                    @endphp
                    <div class="item h-[250px]">
                        <a class="" href="{{ $ad_promotion->url }}">
                            <img src="{{ $url }}" class="w-1/5 rounded-t-2xl "
                                alt="{{ $ad_promotion->alt_text }}"></img>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
        <form action="{{ route('bookmark.search') }}" method="GET" class="w-full">
            <div class="flex mt-4 items-center bg-white px-2 py-4 rounded-lg shadow">
                <input type="text" name="q" class="w-full outline-none px-4" placeholder="Search bookmarks..."
                    id="search" value="{{ request('q') }}" />
                <button type="submit" class="w-6 h-6 bg-transparent border-none cursor-pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                    </svg>
                </button>
            </div>
        </form>
        <div class="my-5 ">
            <div>
                <div class="secondary_color py-4 px-4 text-lg rounded-t-xl text-white">
                    <h3>Latest Bookmarks Sites</h3>
                </div>
                @php
                    $sponsoreds = \App\Models\Sponsored::latest('id')->get();
                @endphp
                <div class="bg-white py-4 px-4 rounded-b-xl shadow">
                    @foreach ($sponsoreds as $key => $sponsored)
                        <div class="flex items-center space-x-2 my-2 ">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M13.19 8.688a4.5 4.5 0 0 1 1.242 7.244l-4.5 4.5a4.5 4.5 0 0 1-6.364-6.364l1.757-1.757m13.35-.622 1.757-1.757a4.5 4.5 0 0 0-6.364-6.364l-4.5 4.5a4.5 4.5 0 0 0 1.242 7.244" />
                            </svg>
                            <a class="hover:underline hover:text-blue-500" href="{{ $sponsored->url }}"
                                target="_blank">{{ $sponsored->url }}</a>
                        </div>
                        @if (!$loop->last)
                        @endif
                        @if ($loop->last)
                            <hr>
                            <a class="underline block mt-2 text-center text-blue-500"
                                href="{{ route('featured.bookmark.details') }}" target="_blank">
                                Submit on other sites </a>
                        @else
                            <hr>
                        @endif
                    @endforeach
                </div>
            </div>
        </div>
        <div class="mb-4">
            <x-ads-section :name="'sidebar'" :position="'inside'" />
        </div>
        <div class="my-5">
            <div>
                <div class="secondary_color py-2 px-4 text-lg rounded-t-xl text-white">
                    <h3>All Categories</h3>
                </div>
                <div class="bg-white py-4 px-4 rounded-b-xl shadow">
                    @foreach ($categories as $category)
                        <div class="flex items-center space-x-2 my-2">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M13.19 8.688a4.5 4.5 0 0 1 1.242 7.244l-4.5 4.5a4.5 4.5 0 0 1-6.364-6.364l1.757-1.757m13.35-.622 1.757-1.757a4.5 4.5 0 0 0-6.364-6.364l-4.5 4.5a4.5 4.5 0 0 0 1.242 7.244" />
                            </svg>
                            @php
                                $currentPath = Illuminate\Support\Facades\Request::path();
                                $routeName = str_starts_with($currentPath, 'blogs')
                                    ? 'featured.blog.details'
                                    : 'user.category';
                            @endphp

                            <a class="hover:underline"
                                href="{{ route($routeName, ['slug' => Illuminate\Support\Str::slug($category['name'])]) }}">
                                {{ $category['name'] }}
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <x-ads-section :name="'sidebar'" :position="'bottom'" />

</div>
