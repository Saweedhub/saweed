@php
    $user = Auth::user();
@endphp

<div class="lg:w-[30%] w-full lg:mt-0 mt-2 border rounded-t-lg shadow ">
    <x-ads-section :name="'sidebar'" :position="'top'" />

    <div class=" px-6 py-4  text-center secondary_color rounded-t-lg lg:mt-0 xl:px-10">
        <div class="space-y-4 xl:space-y-6 pt-4">

            <img src="{{ $user->image ? (Str::startsWith($user->image, ['http://', 'https://']) ? $user->image : asset('storage/' . $user->image)) : '/assets/images/user_profile_placeholder.webp' }}"
                loading="lazy" class="mx-auto rounded-full h-36 w-36 object-cover border"
                src="{{ asset('storage/' . $user->image) }}" alt="author avatar">

            <div class="space-y-2">
                <div class="flex justify-center items-center flex-col space-y-3 text-lg font-medium leading-6">
                    <h3 class="text-white">{{ $user->name }}</h3>
                    <p class="text-white">{{ $user->email }}</p>
                    <a href="{{ $user->website_name }}" target="_blank" class=""
                        style="color: rgb(73, 73, 209);text-decoration: underline">{{ $user->website_name }}</a>
                    <p class="text-white">{{ $user->bio }}</p>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-white rounded-b-lg py-2 px-4 ">
        <div class="group">
            <a href="{{ route('user.dashboard') }}"
                class="p-2.5  flex items-center rounded-md px-4 duration-300 cursor-pointer  {{ Request::routeIs('user.dashboard') ? 'secondary_color' : '' }} group-hover:bg-[{{ $setting->secondary_color }}] ">
                <i class="bi bi-house-door-fill"></i>
                <span
                    class="text-[15px] ml-4 text-gray-800 font-bold  {{ Request::routeIs('user.dashboard') ? 'text-white' : '' }}">Dashboard</span>
            </a>
        </div>
        <div class="group">
            <a href="{{ route('user.profile') }}"
                class="p-2.5 mt-2 flex items-center rounded-md px-4 duration-300 cursor-pointer group-hover:bg-[{{ $setting->secondary_color }}] {{ Request::routeIs('user.profile') ? 'secondary_color' : '' }}">
                <i class="bi bi-bookmark-fill"></i>
                <span
                    class="text-[15px] ml-4 text-gray-800 font-bold  {{ Request::routeIs('user.profile') ? 'text-white' : '' }}">Edit
                    Profile</span>
            </a>
        </div>
        <div class="group">
            <a href="{{ route('bookmark.list') }}"
                class="p-2.5 mt-2 flex items-center rounded-md px-4 duration-300 cursor-pointer group-hover:bg-[{{ $setting->secondary_color }}] {{ Request::routeIs('bookmark.list') ? 'secondary_color' : '' }}">
                <i class="bi bi-bookmark-fill"></i>
                <span
                    class="text-[15px] ml-4 text-gray-800 font-bold  {{ Request::routeIs('bookmark.list') ? 'text-white' : '' }}">My
                    Bookmarks</span>
            </a>
        </div>
        <div class="group">

            <a href="{{ route('blog.list') }}"
                class="p-2.5 mt-2 flex items-center rounded-md px-4 duration-300 cursor-pointer group-hover:bg-[{{ $setting->secondary_color }}] {{ Request::routeIs('blog.list') ? 'secondary_color' : '' }}">
                <i class="bi bi-bookmark-fill"></i>
                <span
                    class="text-[15px] ml-4 text-gray-800 font-bold  {{ Request::routeIs('blog.list') ? 'text-white' : '' }}">My
                    Blogs</span>
            </a>
        </div>
        <div class="group">

            <a href="{{ route('user.logout') }}"
                class="p-2.5 mt-2 flex items-center rounded-md px-4 duration-300 cursor-pointer group-hover:bg-[{{ $setting->secondary_color }}] {{ Request::routeIs('user.logout') ? 'secondary_color' : '' }}">
                <i class="bi bi-bookmark-fill"></i>
                <span
                    class="text-[15px] ml-4 text-gray-800 font-bold  {{ Request::routeIs('user.logout') ? 'text-white' : '' }}">Logout</span>
            </a>
        </div>
    </div>
    <x-ads-section :name="'sidebar'" :position="'top'" />

</div>
