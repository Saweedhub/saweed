@extends('layouts.app')
@section('title')
    Home
@endsection
@section('content')
    <x-authbreadcrumb :name="'Profile'" />
    <section class="container mx-auto px-3 md:px-10 my-4">
        <div class=" block lg:flex items-start gap-5">
            <div class="lg:w-[70%] w-full">
                <div class="bg-white overflow-hidden shadow rounded-lg border">
                    <div class="px-4 py-5 sm:px-6">
                        <h2 class="text-xl text-center leading-6 font-medium text-gray-900">
                            User Profile
                            </h3>
                    </div>
                    <div class="w-full">
                        <form method="POST" action="{{ route('user.profile.update') }}" enctype="multipart/form-data"
                            class="bg-white  px-5 rounded-lg shadow-lg min-w-full">
                            @csrf
                            @honeypot
                            <div>

                                <label class="text-gray-800 font-semibold block my-3 text-md">Name</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text"
                                    name="name" value="{{ $user->name }}"  id="Name"
                                    placeholder="Name" />
                                @error('name')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror

                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Email</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text"
                                    name="email" id="email" readonly disabled value="{{ $user->email }}"
                                    placeholder="" />
                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md"
                                    for="password">Password</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text"
                                    name="password" id="password" placeholder="*******" />
                                @error('password')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="mobile">Mobile</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="tel"
                                    name="mobile" id="mobile"
                                    value="{{ old('mobile') == '' ? $user->mobile : old('mobile') }}"
                                    placeholder="Enter your phone number" />
                                @error('mobile')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="city">City</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text"
                                    name="city" id="city"
                                    value="{{ old('city') == '' ? $user->city : old('city') }}"
                                    placeholder="Enter your city" />
                                @error('city')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="state">State</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text"
                                    name="state" id="state"
                                    value="{{ old('state') == '' ? $user->state : old('state') }}"
                                    placeholder="Enter your State" />
                                @error('state')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="pincode">Pincode</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text"
                                    name="pincode" id="pincode"
                                    value="{{ old('pincode') == '' ? $user->pincode : old('pincode') }}"
                                    placeholder="Enter your postal code" />
                                @error('pincode')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="address">Address</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text"
                                    name="address" id="address"
                                    value="{{ old('address') == '' ? $user->address : old('address') }}"
                                    placeholder="Enter your address" />
                                @error('address')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="facebook">Follow us
                                    on Facebook</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text"
                                    name="facebook" id="facebook"
                                    value="{{ old('facebook') == '' ? $user->facebook : old('facebook') }}"
                                    placeholder="Enter your facebook username" />
                                @error('facebook')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="twitter">Follow us
                                    on Twitter</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text"
                                    name="twitter" id="twitter"
                                    value="{{ old('twitter') == '' ? $user->twitter : old('twitter') }}"
                                    placeholder="Enter your twitter username" />
                                @error('twitter')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="website_name">Website
                                    Url</label>
                                <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="url"
                                    name="website_name" id="website_name"
                                    value="{{ old('website_name') == '' ? $user->website_name : old('website_name') }}"
                                    placeholder="Enter your website url" />
                                @error('website_name')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                            </div>
                            <div>
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="bio">Bio</label>
                                <textarea oninput="updateCharCount(this)" maxlength="150" name="bio"
                                    class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" id="bio" cols="30" rows="10">{{ old('bio') == '' ? $user->bio : old('bio') }}</textarea>
                                @error('bio')
                                    <span class="text-red-500">{{ $message }}</span>
                                @enderror
                                <label id="charCount"
                                    style="    display: flex;
                                        justify-content: end;
                                    ">0
                                    / 150 Characters</label>
                            </div>
                            <div class="w-full">
                                <label class="text-gray-800 font-semibold block my-3 text-md" for="">Profile
                                    Image</label>
                                <div id="preview" class="mt-4 flex justify-center">
                                </div>
                                <div class=" w-full">
                                    <div class="extraOutline p-4 bg-white w-full bg-whtie m-auto rounded-lg">
                                        <div
                                            class="file_upload p-5 relative border-4 border-dotted border-gray-300 rounded-lg w-full">
                                            <svg class="text-indigo-500 w-24 mx-auto mb-4"
                                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                                stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                                            </svg>
                                            <div class="input_field flex flex-col w-max mx-auto text-center">
                                                <label>
                                                    <input id="fileInput" name="profile"
                                                        class="text-sm cursor-pointer w-36 hidden" type="file"
                                                        accept="image/png, image/jpeg, image/jpg,image/webp" />
                                                    <div
                                                        class="text bg-indigo-600 text-white border border-gray-300 rounded font-semibold cursor-pointer p-1 px-3 hover:bg-indigo-500">
                                                        Select
                                                    </div>
                                                </label>
                                                <div class="title text-indigo-500 uppercase">Maximum Upload File size:
                                                    2mb</div>
                                            </div>
                                        </div>

                                        @error('profile')
                                            <span class="text-red-500">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>


                            </div>
                            <button type="submit"
                                class=" mt-6 mb-3 secondary_color rounded-lg px-4 py-2 text-lg text-white tracking-wide font-semibold font-sans">Update</button>
                        </form>
                    </div>
                </div>
            </div>
            @include('includes.profile-sidebar')
        </div>
    </section>
@endsection
@section('script')
    <script>
        const charCountLabel = document.getElementById('charCount');
        const currentCharCount = document.getElementById('bio').value.length;
        charCountLabel.textContent = `${currentCharCount} / 150 Characters`;

        function updateCharCount(textarea) {
            const charCountLabel = document.getElementById('charCount');
            const currentCharCount = textarea.value.length;
            charCountLabel.textContent = `${currentCharCount} / 150 Characters`;
        }
        const fileInput = document.getElementById('fileInput');
        const previewContainer = document.getElementById('preview');

        fileInput.addEventListener('change', function() {
            const file = this.files[0];

            if (file) {
                const reader = new FileReader();

                reader.addEventListener('load', function() {
                    const previewImage = document.createElement('img');
                    previewImage.src = reader.result;
                    previewImage.style.width = '200px';
                    previewImage.style.height = '200px';
                    previewImage.style.borderRadius = '100%';
                    previewImage.style.border = '2px solid #ccc';
                    previewImage.style.objectFit = 'cover';
                    previewContainer.innerHTML = '';
                    previewContainer.appendChild(previewImage);
                });

                reader.readAsDataURL(file);
            }
        });
    </script>
@endsection
