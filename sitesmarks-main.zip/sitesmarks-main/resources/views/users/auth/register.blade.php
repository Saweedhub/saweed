@extends('layouts.app')
@section('seo')
    <title>Register - {{ env('APP_NAME') }}</title>
    <meta name="description"
        content="Create an account and start submitting your social bookmarks and articles for free. Enhance your backlink profile and boost your website’s SEO. Register now.">
    <meta name="robots" content="noindex, nofollow">
@endsection
@section('content')
    <x-breadcrumb :name="'Register'" :page="'Register'" />
    <div class="block lg:grid grid-cols-4 gap-40 items-center my-10">
        <div>
            <x-ads-section :name="'auth'" :position="'left'" />
        </div>
        <div class=" w-full col-span-2 lg:m-0">
            <form method="POST" action="{{ route('user.create') }}" class="bg-white p-10 rounded-2xl border min-w-full">
                @csrf
                @honeypot
                <h2 class="text-center text-3xl mb-10 font-bold font-sans">User Register</h2>
                <div class="flex items-center justify-center ">
                    <a href="{{ route('user.google.login') }}"
                        class="w-full lg:w-2/3 px-4 py-2 border flex justify-center gap-2 border-slate-200  rounded-lg text-slate-700  hover:border-slate-400  hover:text-slate-900 shadow transition duration-150">
                        <img class="w-6 h-6" src="https://www.svgrepo.com/show/475656/google-color.svg" loading="lazy"
                            alt="google logo">
                        <span>Sign up with Google</span>
                    </a>
                </div>
                <div class="my-6 border-b text-center">
                    <div
                        class="leading-none px-2 inline-block text-sm text-gray-600 tracking-wide font-medium bg-white transform translate-y-1/2">
                        Or register with email
                    </div>
                </div>
                <div>
                    <label class="text-gray-800 font-semibold block my-3 text-md" for="username">Name</label>
                    <input
                        class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white "
                        type="text" name="name" id="Name" placeholder="Name" />
                    @error('name')
                        <span class="text-red-500">{{ $message }}</span>
                    @enderror
                </div>
                <div>
                    <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Email</label>
                    <input
                        class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white "
                        type="text" name="email" id="email" placeholder="Enter your email" />
                    @error('email')
                        <span class="text-red-500">{{ $message }}</span>
                    @enderror
                </div>
                <div>
                    <label class="text-gray-800 font-semibold block my-3 text-md" for="password">Password</label>
                    <input
                        class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white "
                        type="password" name="password" id="password" placeholder="Enter your password" />
                    @error('password')
                        <span class="text-red-500">{{ $message }}</span>
                    @enderror
                </div>
                <div>
                    <label class="text-gray-800 font-semibold block my-3 text-md" for="confirm">Confirm
                        password</label>
                    <input
                        class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white "
                        type="password" name="password_confirmation" id="confirm"
                        placeholder="Enter your confirm password" />
                    @error('password_confirmation')
                        <span class="text-red-500">{{ $message }}</span>
                    @enderror
                </div>
                <div class="pb-8">
                    <label class="text-gray-800 font-semibold block my-3 text-md " for="confirm">Captcha :
                        <span>{{ $value1 }}</span> + <span>{{ $value2 }}</span> = </label>
                    <input type="hidden" name="value1" value="{{ $value1 }}" id="value1">
                    <input type="hidden" name="value2" value="{{ $value2 }}" id="value2">
                    <input
                        class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white "
                        type="number" name="captcha" id="confirm" placeholder="Captcha" />
                    @error('captcha')
                        <span class="text-red-500">{{ $message }}</span>
                    @enderror
                </div>
                <div class="my-4">
                    <x-ads-section :name="'auth'" :position="'inside'" />
                </div>
                <button type="submit"
                    class="w-full mt-2 secondary_color rounded-lg px-4 py-2 text-lg text-white tracking-wide font-semibold font-sans">Register</button>
                <div class="my-6">
                    <x-ads-section :name="'auth'" :position="'inside'" />
                </div>

                <div class="flex justify-center items-center mt-10">
                    <p class="inline-flex items-center text-gray-700 font-medium text-xs text-center">
                        <span class="ml-2">Already have an account?
                            <a href="{{ route('user.login') }}" class="text-sm ml-2 text-blue-500 font-semibold">Login
                                now &rarr;</a>
                        </span>
                    </p>
                </div>

            </form>
        </div>
        <div>
            <x-ads-section :name="'auth'" :position="'right'" />
        </div>
    </div>
@endsection
