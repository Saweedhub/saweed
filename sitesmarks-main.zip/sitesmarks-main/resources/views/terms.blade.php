@extends('layouts.app')
<x-seo-section :page="'terms-and-condition'" />
@section('content')
    <x-breadcrumb :name="'Terms & Conditions'" :page="'Terms & Conditions'" />
    <section class="container mx-auto px-5 my-5">
        <h2 class="text-4xl text-center mt-10 text-black font-extrabold">Terms and Conditions</h2>
        <div class="mt-5 mb-20">
            {!! $setting->terms_and_conditions !!}
        </div>
    </section>
@endsection
