@extends('layouts.app')
<x-seo-section :page="'Home'" />
@section('content')
    @php
        $sell_banner = \App\Models\SellBanner::where('status', 1)->first();
    @endphp
    <div class="cursor"></div>
    <section class=" container mx-auto px-4 mt-10">
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="h-[350px] md:h-[450px] rounded-xl col-span-3 " id="hero"
                style="background:{{ $rgbaColor }} url('{{ !$setting->bg_image ? '/assets/images/hero_banner.jpg' : $setting->bg_image }}');background-repeat: no-repeat;width: 100%;background-position: center center;background-size: cover;background-blend-mode: darken;">
                <div class="cursor-none h-[350px] md:h-[450px] relative area w-full">
                    <ul class="circles">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                    </ul>
                    <div class="flex flex-col gap-4 justify-center w-full h-full px-3 md:px-10">

                        <div class="flex w-full h-fit ">
                            <span class="h-20"></span>
                            <h1 id="typewriter" class=" pr-5 text-4xl md:text-6xl font-bold text-white cursor-default">
                            </h1>
                        </div>
                        <p class="text-gray-300 cursor-default max-w-[75%]">
                            {{ $setting->bg_desc }}
                        </p>
                    </div>
                </div>
            </div>
            <div class="relative h-[350px] md:h-[450px] rounded-xl block lg:col-span-1 col-span-3 secondary_color border">
                @if ($sell_banner)
                    {!! $sell_banner->sell_banners !!}
                @else
                    <div class="flex flex-col  gap-4 justify-around  w-full h-full px-3 md:px-7">
                        <div></div>
                        <div>
                            <h2 class="  text-lg font-bold text-white cursor-default">
                                SUBMIT ONCE,<br> BOOST EVERYWHERE
                            </h2>
                            <p class="text-gray-300 mt-5 cursor-default">
                                Say goodbye to time-consuming processes and hello to effortless link-building services. Our
                                streamlined platform publishes your bookmark and article on multiple platforms, enhancing
                                your website's visibility and increasing traffic.
                            </p>
                        </div>
                        <div>
                            <a class="block border py-4 px-6 text-center bg-black text-sm text-white font-bold rounded-full"
                                href="{{ route('user.register') }}">
                                Get Started
                            </a>
                        </div>
                    </div>
                @endif

            </div>

        </div>
    </section>
    <section class="container mx-auto px-3  mt-10">
        <div class="p-4 rounded-lg">
            <div class="owl-carousel owl-theme " id="category_slider">
                @foreach ($categories as $category)
                    <div class="px-4 pt-4 pb-1 bg-zinc-100 item rounded-md">
                        <a href="{{ route('user.category', ['slug' => Illuminate\Support\Str::slug($category['name'])]) }}">
                            <img loading="lazy" src="{{ asset('category/' . $category['image']) }}"
                                class="hover:scale-110 transition-transform duration-300 ease-in-out w-[80px] mx-auto"
                                style="width: 80px !important;height: 80px;object-fit: scale-down;"
                                alt="{{ $category['image'] }}">
                            <h3 class="text-center my-4">{{ $category['name'] }}</h3>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
    <x-bookmarks-list :bookmarks="$bookmarks" :feature_bookmark="$feature_bookmark" :feature_bookmark_url="$feature_bookmark_url" />
    <x-blogs-list :blogs="$blogs" :feature_blog="$feature_blog" :feature_blog_url="$feature_blog_url" :grid="3" />
@endsection
@section('script')
    <script>
        const words = [@json($setting->bg_title), "Free Bookmarks Site", "Free Profile Creation Site",
            "Free DoFollow Backlinks"
        ];
        let i = 0,
            j = 0,
            isTyping = true;

        function type() {
            const currentWord = words[i];
            const delay = isTyping ? (j < currentWord.length ? 100 : 1000) : (j > 0 ? 100 : 1000);
            document.getElementById("typewriter").textContent = currentWord.substring(0, isTyping ? ++j : --j);
            if ((!isTyping && j === 0) || (isTyping && j === currentWord.length)) {
                isTyping = !isTyping;
                i = isTyping ? (i + 1) % words.length : i;
            }
            setTimeout(type, delay);
        }
        type();

        const cursor = document.querySelector(".cursor");
        var timeout;
        const heroElement = document.querySelector("#hero");
        heroElement &&
            (heroElement.addEventListener("mousemove", (e) => {
                    let o = e.pageX,
                        t = e.pageY;
                    (cursor.style.top = t + "px"),
                    (cursor.style.left = o + "px"),
                    (cursor.style.display = "block"),
                    (cursor.style.cursor = "none "),
                    clearTimeout(timeout),
                        (timeout = setTimeout(function() {
                            cursor.style.display = "none";
                        }, 5e3));
                }),
                heroElement.addEventListener("mouseout", () => {
                    cursor.style.display = "none";
                }));
    </script>
@endsection
