@extends('layouts.app')
<x-seo-section :page="'bookmark'" />
@section('content')
    <x-breadcrumb :name="date('Y') . '  Free DoFollow Social Bookmarking & Profile Creation Sites'" :page="'Bookmarks'" :seo="'bookmark'"/>
    <div class="h-10"></div>
    <x-bookmarks-list :bookmarks="$bookmarks" :feature_bookmark="$feature_bookmark" :feature_bookmark_url="$feature_bookmark_url" />
@endsection
