@extends('layouts.app')
@section('title')
    Home
@endsection

@section('content')
    <style>
        .ck.ck-editor__main>.ck-editor__editable:not(.ck-focused) {
            background-color: #FAFAFA;
            border-width: 0.5px;
            border-radius: 3px;
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .ck.ck-balloon-panel.ck-powered-by-balloon {
            display: none;
        }
        .ck-rounded-corners .ck.ck-editor__top .ck-sticky-panel .ck-toolbar,
        .ck.ck-editor__top .ck-sticky-panel .ck-toolbar.ck-rounded-corners {
            border-width: 0.5px;
            border-radius: 3px;
            background-color: #FAFAFA;
            border-bottom-left-radius: 0px;
            border-bottom-right-radius: 0px;
        }
    </style>
    <x-authbreadcrumb :name="date('Y') . '  Free DoFollow Bookmarks'" />
    <div class="my-10">
        <h1 class="text-center text-4xl mt-[30px]">Add Bookmark</h1>
    </div>
    <section class="container mx-auto px-3 md:px-10 my-4">
        <div class=" block lg:flex items-start gap-5">
            <div class="lg:w-[70%] w-full">
                <div class=" bg-zinc-50 border flex items-center rounded justify-center">
                    <div class="container max-w-screen-lg mx-auto">
                        <div class="pt-4 px-4 mb-6">
                            <form method="POST" action="{{ route('bookmark.store') }}"
                                class="grid gap-4  text-sm grid-cols-1 lg:grid-cols-1">
                                @csrf
                                @honeypot
                                <div class="container  px-5 rounded-md">
                                    <div class="md:col-span-5 my-2">
                                        <label class="  text-gray-800 font-semibold block my-3 text-md" for="url">
                                            Url
                                        </label>

                                        <input type="url" id="url"
                                            class="focus:bg-white h-10 border mt-1 rounded px-4 w-full bg-gray-50"
                                            name="url" value="{{ old('url') }}" />
                                        @error('url')
                                            <span
                                                class="text-red-500">{{ $message == 'The url has already been taken.' ? 'You already added these url. Please add different one. OR create a new user' : $message }}</span>
                                        @enderror

                                    </div>
                                    <div>
                                        <button id="getData" type="button"
                                            class="secondary_color text-white font-bold py-2 mt-4 px-4 rounded">Submit</button>
                                        <div class="hidden items-center justify-center my-10" id="loading">
                                            <div role="status">
                                                <svg aria-hidden="true"
                                                    class="w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                                                    viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                                        fill="currentColor" />
                                                    <path
                                                        d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                                        fill="currentFill" />
                                                </svg>
                                                <span class="sr-only">Loading...</span>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="hidden gap-4 gap-y-2 text-sm grid-cols-1 md:grid-cols-5 my-2 "
                                        id="remaning_fields">
                                        <div class="md:col-span-5 my-2">
                                            <label
                                                for="title"class="text-gray-800 font-semibold block my-3 text-md">Title</label>
                                            <input type="text" name="title" id="title"
                                                class="focus:bg-white h-10 border mt-1 rounded px-4 w-full bg-gray-50"
                                                value="{{ old('title') }}" />
                                            @error('title')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="md:col-span-5 my-2">
                                            <label for="cat_id"
                                                class="text-gray-800 font-semibold block my-3 text-md">Choose
                                                Category</label>
                                            <select name="cat_id" id="cat_id"
                                                class="h-10 border mt-1 rounded px-4 w-full bg-gray-50">
                                                <option value="">Choose Category</option>

                                                @foreach ($categories as $category)
                                                    <option value="{{ $category['name'] }}"
                                                        {{ old('cat_id') == $category['name'] ? 'selected' : '' }}>
                                                        {{ $category['name'] }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('cat_id')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="md:col-span-5 my-2">
                                            <label for="tags"
                                                class="text-gray-800 font-semibold block my-3 text-md">Enter the
                                                Tag</label>
                                            <input type="text" name="keywords" id=""
                                                class="focus:bg-white h-10 border mt-1 rounded px-4 w-full bg-gray-50"
                                                value="{{ old('keywords') }}" placeholder="Enter the Tags" />
                                            @error('keywords')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="md:col-span-5 my-2">
                                            <label for="follow"
                                                class="text-gray-800 font-semibold block my-3 text-md">Enter the
                                                url Type</label>
                                            <select name="follow" id="follow"
                                                class="h-10 border mt-1 rounded px-4 w-full bg-gray-50">
                                                <option value="1" {{ old('follow') == '1' ? 'selected' : '' }}>Do
                                                    Follow</option>
                                                <option value="0" {{ old('follow') == '0' ? 'selected' : '' }}>No
                                                    Follow</option>
                                            </select>
                                            @error('follow')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="md:col-span-5 my-2">
                                            <label for="description"
                                                class="text-gray-800 font-semibold block my-3 text-md">Enter the
                                                Description</label>
                                            <textarea id="editor" name="description" id="description" cols="30" rows="10"
                                                class="border focus:bg-white mt-1 rounded px-4 w-full bg-gray-50">{{ old('description') }}</textarea>
                                            <label id="charCount" class=" text-end block"></label>
                                            @error('description')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="md:col-span-5 my-2">
                                            <label for="email"
                                                class="text-gray-800 font-semibold block my-3 text-md">Captcha : <span
                                                    id="value1">{{ $value1 }}</span> + <span
                                                    id="value2">{{ $value2 }}</span> = </label>
                                            <input type="hidden" name="value1" value="{{ $value1 }}"
                                                id="">
                                            <input type="hidden" name="value2" value="{{ $value2 }}"
                                                id="">
                                            <input type="number" name="captcha" id="captcha"
                                                class="h-10 border mt-1 rounded px-4 w-full bg-gray-50 focus:bg-white"
                                                value="" placeholder="Enter Captcha:" />

                                            @error('captcha')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="md:col-span-5 text-right mt-3">
                                            <div class="inline-flex items-end">
                                                <button type="submit"
                                                    class="secondary_color text-white font-bold py-2 px-4 rounded">Submit</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
            @include('includes.profile-sidebar')
        </div>
    </section>
    <div class="h-10"></div>
@endsection

@section('script')
    <script src="https://cdn.ckeditor.com/ckeditor5/41.2.0/classic/ckeditor.js"></script>

    @php
        $user_limit = \App\Models\UserLimit::first();
    @endphp
    <script>
        let urlValue = $('#url').val();
        if (urlValue != "") {
            $("#remaning_fields").addClass('grid').removeClass('hidden');
            $("#getData").addClass('hidden');
        }
        let editorInit;
        const charCountLabel = document.getElementById('charCount');
        ClassicEditor.create(document.querySelector("#editor"), {
                toolbar: [
                    "link",
                    "undo",
                    "redo",
                ],
            })
            .then(editor => {
                editorInit = editor;
                editor.model.document.on('change:data', () => {
                    const text = editor.getData();
                    const currentCharCount = text.length;
                    console.log();
                    charCountLabel.textContent =
                        `${currentCharCount} / {{ $user_limit->bookmark_max_description }} Characters`;
                });
            })
            .catch((e) => {});

        var input = document.querySelector('input[name=keywords]');
        new Tagify(input, {
            maxTags: {{ $user_limit->bookmark_tag }}
        })
        $("#getData").on('click', function() {
            let urlValue = $('#url').val();
            if (urlValue == "") {
                toastr['error']('Please Enter the url');
                return false;
            }
            if (!urlValue.startsWith('http://') && !urlValue.startsWith('https://')) {
                const correctedUrl = 'https://' + urlValue;
                urlValue = correctedUrl;
            } else {
                urlValue = urlValue;
            }
            $(this).addClass('hidden')
            $("#loading").removeClass('hidden').addClass('flex')
            fetch("{{ route('bookmark.getMetaData') }}", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        url: urlValue,
                        "_token": "{{ csrf_token() }}"
                    }),
                })
                .then(response => response.json())
                .then(data => {
                    $("#loading").removeClass('flex').addClass('hidden')
                    if (!data.success) {
                        toastr['error'](data.message);
                        $(this).removeClass('hidden')
                        return;
                    }
                    charCountLabel.textContent =
                        `${data.data.description.length} / {{ $user_limit->bookmark_max_description }} Characters`;
                    $("#title").val(data.data.title)
                    editorInit.setData(data.data.description);

        
                    $("#keywords").val(data.data.keywords)
                    $("#remaning_fields").addClass('grid').removeClass('hidden');
                })
                .catch(error => {
                    $("#loading").removeClass('flex').addClass('hidden')
                    $("#remaning_fields").addClass('grid').removeClass('hidden');
                });
        })
    </script>
@endsection
