@extends('layouts.app')
@section('title')
    Home
@endsection
@section('content')
    <style>
        .ck.ck-editor__main>.ck-editor__editable:not(.ck-focused) {
            background-color: #FAFAFA;
            border-width: 0.5px;
            border-radius: 3px;
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .ck.ck-balloon-panel.ck-powered-by-balloon {
            display: none;
        }

        .ck-rounded-corners .ck.ck-editor__top .ck-sticky-panel .ck-toolbar,
        .ck.ck-editor__top .ck-sticky-panel .ck-toolbar.ck-rounded-corners {
            border-width: 0.5px;
            border-radius: 3px;
            background-color: #FAFAFA;
            border-bottom-left-radius: 0px;
            border-bottom-right-radius: 0px;
        }
    </style>
    <x-authbreadcrumb :name="date('Y') . '  Free DoFollow Bookmarks'" />
    <div class="my-10">
        <h1 class="text-center text-4xl mt-[30px]">Add Bookmark</h1>
    </div>
    <section class="container mx-auto px-3 md:px-10 my-4">
        <div class=" block lg:flex items-start gap-5">
            <div class="lg:w-[70%] w-full">
                <div class=" flex items-center justify-center">
                    <div class="container max-w-screen-lg mx-auto">
                        <div>
                            <div class= "bg-zinc-50 border rounded  px-4 mb-6">
                                <form method="POST"
                                    action="{{ route('bookmark.update', ['id' => $bookmark->id, 'slug' => $bookmark->slug]) }}"
                                    class="grid gap-4  text-sm grid-cols-1 lg:grid-cols-1">
                                    @csrf
                                    @honeypot

                                    <div class="block gap-4 gap-y-2 px-4 text-sm grid-cols-1 md:grid-cols-5 my-2 ">
                                        <div class="md:col-span-5 my-2">
                                            <label class="text-gray-800 font-semibold block my-3 text-md" for="url">Url
                                            </label>
                                            <input type="url" readonly disabled name="url" id="url"
                                                class="h-10 border mt-1 rounded px-4 w-full bg-gray-50 focus:bg-white"
                                                value="{{ $bookmark->url }}" />
                                            @error('url')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="md:col-span-5 my-2">
                                            <label class="text-gray-800 font-semibold block my-3 text-md"
                                                for="title">Title</label>
                                            <input type="text" name="title" id="title"
                                                class="h-10 border mt-1 rounded px-4 w-full bg-gray-50 focus:bg-white"
                                                value="{{ old('title') == '' ? $bookmark->title : old('title') }}" />
                                            @error('title')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="md:col-span-5 my-2">
                                            <label class=" text-gray-800 font-semibold block my-3 text-md "
                                                for="cat_id">Choose Category</label>
                                            <select name="cat_id" id="cat_id"
                                                class="h-10 border mt-1 rounded px-4 w-full bg-gray-50">
                                                <option value="">Choose Category</option>

                                                @foreach ($categories as $category)
                                                    @php
                                                        $category_name = Illuminate\Support\Str::slug(
                                                            $category['name'],
                                                        );
                                                    @endphp
                                                    <option @selected(old('cat_id') == '' ? $category_name == $bookmark->cat_id : $category['name'] == old('cat_id')) value="{{ $category['name'] }}">
                                                        {{ $category['name'] }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('cat_id')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="md:col-span-5 my-2">
                                            <label class=" text-gray-800 font-semibold block my-3 text-md"
                                                for="keywords">Enter the Tag</label>
                                            <input type="text" name="keywords" id="keywords"
                                                class="h-10 border mt-1 rounded px-4 w-full bg-gray-50"
                                                value="{{ old('keywords') == '' ? $bookmark->tag : old('keywords') }}"
                                                placeholder="Enter the Tags:" />
                                            @error('keywords')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="md:col-span-5 my-2">
                                            <label for="follow"
                                                class="text-gray-800 font-semibold block my-3 text-md">Enter the
                                                url Type</label>
                                            <select name="follow" id="follow"
                                                class="h-10 border mt-1 rounded px-4 w-full bg-gray-50">
                                                <option value="1" @selected(old('follow') == '' ? $bookmark->follow == 1 : old('follow') == '1')>Do Follow
                                                </option>
                                                <option value="0" @selected(old('follow') == '' ? $bookmark->follow == 0 : old('follow') == '0')>No Follow
                                                </option>
                                            </select>
                                            @error('follow')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="md:col-span-5 my-2">
                                            <label for="description"
                                                class="text-gray-800 font-semibold block my-3 text-md">Enter the
                                                Description</label>
                                            <textarea id="editor2" name="description" id="description" cols="30" rows="10"
                                                class="border focus:bg-white mt-1 rounded px-4 w-full bg-gray-50">{{ old('description') == '' ? $bookmark->description : old('description') }}</textarea>
                                            <label id="charCount" class=" text-end block"></label>
                                            @error('description')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="md:col-span-5 my-2">
                                            <label class=" text-gray-800 font-semibold block my-3 text-md"
                                                for="captcha">Captcha : <span id="value1">{{ $value1 }}</span> +
                                                <span id="value2">{{ $value2 }}</span> = </label>
                                            <input type="hidden" name="value1" value="{{ $value1 }}"
                                                id="">
                                            <input type="hidden" name="value2" value="{{ $value2 }}"
                                                id="">
                                            <input type="text" name="captcha" id="captcha"
                                                class="h-10 border mt-1 rounded px-4 w-full bg-gray-50 focus:bg-white"
                                                value="" placeholder="Enter Captcha:" />

                                            @error('captcha')
                                                <span class="text-red-500">{{ $message }}</span>
                                            @enderror
                                        </div>

                                        <div class="md:col-span-5 text-right mt-6 mb-6">
                                            <div class="inline-flex items-end">
                                                <button type="submit"
                                                    class="secondary_color text-white font-bold py-2 px-4 rounded">Update</button>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            @include('includes.profile-sidebar')
        </div>
    </section>
    <div class="h-10"></div>
@endsection

@section('script')
    <script src="https://cdn.ckeditor.com/ckeditor5/41.2.0/classic/ckeditor.js"></script>
    @php
        $user_limit = \App\Models\UserLimit::first();
    @endphp
    <script>
        let editorInit;
        const charCountLabel = document.getElementById('charCount');
        ClassicEditor.create(document.querySelector("#editor2"), {
                toolbar: [
                    "link",
                    "undo",
                    "redo",
                ],
            })
            .then(editor => {
                editorInit = editor;
                editor.model.document.on('change:data', () => {
                    const text = editor.getData();
                    const currentCharCount = text.length;
                    console.log();
                    charCountLabel.textContent =
                        `${currentCharCount} / {{ $user_limit->bookmark_max_description }} Characters`;
                });
            })
            .catch((e) => {});
        var input = document.querySelector('input[name=keywords]');
        new Tagify(input, {
            maxTags: {{ $user_limit->bookmark_tag }}
        })
    </script>
@endsection
