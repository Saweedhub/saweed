<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
    <link rel="manifest" href="/favicon/site.webmanifest">
    <link rel="mask-icon" href="/favicon/safari-pinned-tab.svg" color="#0069fd">
    <meta name="msapplication-TileColor" content="#0069fd">
    <meta name="theme-color" content="#0069fd">
    @php
        $fullUrl = Illuminate\Support\Facades\Request::fullUrl();
    @endphp
    <link rel="canonical" href="{{ $fullUrl }}" />

    @if (View::hasSection('seo'))
        @yield('seo')
    @else
        <title> {{ env('APP_NAME') }} - @yield('title')</title>
    @endif
    @vite('resources/css/app.css')
    @vite('resources/js/app.js')
    <link rel="stylesheet" href="/assets/css/owl.theme.default.css" />
    <link rel="stylesheet" href="/assets/css/owl.carousel.css" />
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
    <link href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <style>
        .primary_color,
        .secondary_color {
            background-color: {{ $setting->primary_color }};
        }

        .group:hover .secondary_color {
            background-color: {{ $setting->secondary_color }} !important;
        }

        .text_color {
            color: {{ $setting->secondary_color }};
        }
    </style>

    @php
        $google_ad = \App\Models\GoogleAd::first();
    @endphp
    @if ($google_ad)
        {!! $google_ad->meta_tag !!}
        {!! $google_ad->code !!}
    @endif
    @php
        $tag_managers = \App\Models\TagManager::latest()->get();
    @endphp
    @foreach ($tag_managers as $manager)
        {!! $manager->header_script !!}
    @endforeach
</head>

<body>
    <div class="min-h-[100vh]">
        <x-header />
        @yield('content')
    </div>
    <x-footer />

    <button id="scrollToTopBtn" style="align-items: center;"
        class="w-12 h-12 rounded-full hidden fixed bottom-4 right-4 z-50 bg-blue-500 text-white py-2 px-4 shadow-md transition-opacity duration-300 opacity-0">
        <svg width="19" height="13" viewBox="0 0 19 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M18.5137 12.0924C18.5148 12.2805 18.4571 12.4642 18.3487 12.6179C18.2403 12.7716 18.0866 12.8876 17.9091 12.9497C17.7316 13.0119 17.5391 13.0171 17.3585 12.9646C17.1779 12.9121 17.0182 12.8045 16.9017 12.6568L9.24785 3.00713L1.57143 12.6568C1.42233 12.8449 1.20465 12.9659 0.966271 12.9935C0.727889 13.021 0.488332 12.9527 0.300309 12.8036C0.112287 12.6545 -0.00880163 12.4368 -0.0363235 12.1984C-0.0638454 11.96 0.00445502 11.7205 0.153556 11.5325L8.57955 0.993192C8.66408 0.886077 8.77179 0.799509 8.89457 0.739992C9.01736 0.680475 9.15204 0.649559 9.28849 0.649559C9.42494 0.649559 9.55961 0.680475 9.6824 0.739992C9.80519 0.799509 9.9129 0.886077 9.99743 0.993192L18.3376 11.5415C18.4551 11.7009 18.517 11.8944 18.5137 12.0924Z"
                fill="white" />
        </svg>
    </button>
    {{-- dialog --}}
    <section id="showModal" class="hidden fixed inset-0 backdrop-blur-sm  items-center justify-center z-50">
        <div class="bg-white border-2 rounded-lg p-6 w-96 max-w-full shadow-lg transform transition-all duration-300">
            <!-- Modal Header -->
            <div class="flex justify-between items-center border-b-2 border-gray-200 pb-4">
                <h2 class="text-2xl font-semibold">Free Bookmarks sites</h2>
                <button onclick='$("#showModal").removeClass("flex").addClass("hidden");'
                    class="text-gray-500 hover:text-gray-700 focus:outline-none">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" class="feather feather-x">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                </button>
            </div>

            <!-- Modal Content -->
            <div class="mt-6 space-y-4">
                <p class="text-lg text-gray-600">
                    <b> {{ env('APP_NAME') }}</b> Provides You The Best Backlink Sites.
                </p>
                <div class="flex flex-col space-y-4">
                    <a href="{{ route('featured.bookmark.details') }}"
                        class="border hover:bg-green-800 text-white text-center px-4 py-2 rounded-full bg-black transition duration-300">Submit
                        On Other Sites</a>

                </div>
            </div>

            <!-- Additional Information -->
            <div class="mt-6 text-sm text-gray-500">
                <p>Feel free click the button to check our all <a class="text-blue-500 underline"
                        href="{{ route('featured.bookmark.details') }}">backlinks sites</a></p>
            </div>
        </div>
    </section>

    @foreach ($tag_managers as $manager)
        {!! $manager->body_script !!}
    @endforeach
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script type="text/javascript" src="/assets/js/owl.carousel.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    @if (session()->has('success'))
        <script>
            toastr.success('{{ session('success') }}')
            if ('{{ session('success') }}' == 'Bookmark Added Successfully' ||
                '{{ session('success') }}' == 'blog added successfully') {
                $("#showModal").removeClass('hidden').addClass('flex')
            }
            $.ajax({
                url: "{{ route('clear-session', ['key' => 'success']) }}",
                type: 'GET',
                success: function(response) {
                    console.log('Session success message cleared');
                }
            });
        </script>
    @endif
    @if (session()->has('error'))
        <script>
            toastr.error('{{ session('error') }}')
            $.ajax({
                url: "{{ route('clear-session', ['key' => 'error']) }}",
                type: 'GET',
                success: function(response) {
                    console.log('Session success message cleared');
                }
            });
        </script>
    @endif
    <script>
        const alertTemplate = document?.getElementById("alertMsg");
        const appendAlert = (message, type) => {
            const wrapper = document.createElement("div");
            wrapper.classList.add("alert-root");
            wrapper.innerHTML = [
                `<div class="flex items-center justify-between p-3 rounded-md ${
            type == "success" ? "bg-green-300" : "bg-red-300"
        } gap-4" role="alert">`,
                `  <div class="${
            type == "success" ? "text-green-900" : "text-red-900"
        }">${message}</div>`,
                '  <button type="button" class="flex items-center justify-center rounded-full transition-all duration-300 p-1.5 hover:bg-black/10" data-dismiss="alert" aria-label="Close"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line> <line x1="6" y1="6" x2="18" y2="18"></line> </svg></button>',
                "</div>",
            ].join("");

            alertTemplate?.append(wrapper);
            setTimeout(function() {
                wrapper.remove();
            }, 3000);
            const dismissAlert = document?.querySelectorAll('[data-dismiss="alert"]');

            dismissAlert.forEach((button) => {
                button.addEventListener("click", () => {
                    wrapper.remove();
                });
            });
        };
    </script>
    @yield('script')
</body>

</html>
