@extends('layouts.app')
<x-seo-section :page="'privacy-policy'" />
@section('content')
    <x-breadcrumb :name="'Privacy Policy'" :page="'Privacy Policy'" />

    <section class="container mx-auto px-5 my-5">
        <h2 class="text-4xl text-center mt-10 text-black font-extrabold">Privacy Policy</h2>
        <div class="mt-5 mb-20">
            {!! $setting->privacy_policy !!}
        </div>
    </section>
@endsection
