@extends('layouts.app')
@section('seo')
    <title>{{ $blog->title }} - {{ env('APP_NAME') }}</title>
    <meta name="description" content="{{ Illuminate\Support\Str::limit(strip_tags($blog->description), 160, '.....') }}">
    <meta name="author" content="{{ $type == 'featured' ? env('APP_NAME') : $blog->user->name }}">
@endsection
@section('content')
    <style>
        .desc-content a {
            color: blue;
            text-decoration: underline;

        }

        .desc-content * {
            font-size: revert !important;
            font-weight: revert !important;
            line-height: revert !important;
        }

        .desc-content ol,
        .desc-content ul,
        .desc-content menu {
            list-style: disc !important;
            padding: 0;
            margin-left: 40px !important;
        }
    </style>
    <x-breadcrumb :name="$blog->title" :page="$blog->title" :category="'Blogs'" />
    <section class="container mx-auto px-3 md:px-10 my-4">
        <div class="mt-4">
            <x-ads-section :name="'screens'" :position="'top'" />
        </div>
        <div class=" block lg:flex items-start gap-5  mt-10">
            <div class="lg:w-[70%] w-full">
                <div class="mb-4 md:mb-0 w-full mx-auto relative">
                    <div class=" px-4 lg:px-0 ">
                        @if ($type == 'featured')
                            <div class="flex items-center mb-4 ">
                                <img class="w-12 h-12 rounded-full object-cover mr-4 shadow"
                                    src="{{ '/assets/images/admin_profile.jpeg' }}" loading="lazy" alt="avatar">
                                <div class="flex-col">
                                    <a class="flip-animate">
                                        <span data-hover="{{ env('APP_NAME') }}">
                                            {{ env('APP_NAME') }}
                                        </span>
                                    </a>
                                    @php
                                        $wordCount = str_word_count(strip_tags($blog->description));
                                        $readingTime = ceil($wordCount / 200);
                                    @endphp
                                    <p class="text-[14px] text_color" href="#">
                                        {{ date('F d,Y', strtotime($blog->created_at)) }}
                                        <span class="text-[10px]">
                                            • {{ $readingTime }} min read
                                        </span>
                                    </p>
                                </div>
                            </div>
                        @else
                            <di class="flex pb-4">
                                <div class="h-6 w-1 mr-2 rounded bg-[#b91c1c]"></div>
                                <p>{{ $blog->cat_id }}</p>

                            </di>
                            <div class="flex items-center mb-4 justify-between ">
                                <div class="flex ">

                                    <img class="w-12 h-12 rounded-full object-cover mr-4 shadow"
                                        src="{{ $blog->user->image ? (Str::startsWith($blog->user->image, ['http://', 'https://']) ? $blog->user->image : asset('storage/' . $blog->user->image)) : '/assets/images/user_profile_placeholder.webp' }}"
                                        loading="lazy" alt="avatar">

                                    <div class="flex-col">
                                        <a class="flip-animate">
                                            <span data-hover="{{ $blog->user->name }}">
                                                {{ $blog->user->name }}
                                            </span>
                                        </a>
                                        @php
                                            $wordCount = str_word_count(strip_tags($blog->description));
                                            $readingTime = ceil($wordCount / 200);
                                        @endphp
                                        <p class="text-[14px] text_color" href="#">
                                            {{ date('F d,Y', strtotime($blog->created_at)) }}
                                            <span class="text-[10px]">
                                                • {{ $readingTime }} min read

                                            </span>
                                        </p>

                                    </div>

                                </div>
                                <div class="flex items-center space-x-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                                    </svg>
                                    <x-bookmark-share :bookmark="$blog" :bookmark_url="'{{ parse_url(request()->fullUrl(), PHP_URL_PATH) }}'" />
                                </div>

                            </div>
                        @endif
                        <h2>
                            <a
                                class=" underline-hover-effect text-4xl font-semibold text-gray-800 leading-tight cursor-default">
                                {{ $blog->title }}
                            </a>
                        </h2>

                        <div class="h-4"></div>
                    </div>
                    <a>
                        <div class="relative h-[28em] w-full overflow-hidden">
                            <img src="{{ $blog->thumbnail
                                ? (Str::startsWith($blog->thumbnail, ['http://', 'https://'])
                                    ? $blog->thumbnail
                                    : asset('storage/' . $blog->thumbnail))
                                : '/assets/images/blog_placeholder.jpeg' }}"
                                loading="lazy" alt="{{ $blog->title }}"
                                class="img-fluid rounded-xl h-[28em] object-cover w-full transition-transform transform hover:scale-110">
                        </div>

                    </a>
                </div>
                <div class="mt-4">
                    <x-ads-section :name="'screens'" :position="'inside'" />
                </div>
                <div class="flex flex-col  lg:flex-row lg:space-x-12">
                    <div class="desc-content px-4 lg:px-0 mt-12 text-gray-700 text-lg leading-relaxed w-full">
                        {!! $blog->description !!}
                        @if ($type != '')
                            <div>
                                <x-oursites />
                            </div>
                        @else
                            <div class="flex justify-start gap-2 flex-wrap my-4">
                                <span>Tags: </span>
                                @foreach (json_decode($blog->tag) as $tag)
                                    <span style="font-size: 14px !important; font-weight:600 !important"
                                        class="bg-gray-100 rounded-full px-3 py-1 text-2sm font-semibold text-gray-600">
                                        #{{ $tag->value }}</span>
                                @endforeach
                            </div>
                        @endif
                    </div>
                </div>
                <div class="mt-4">
                    <x-ads-section :name="'screens'" :position="'inside'" />
                </div>
                @if ($type != 'featured')
                    <section>
                        <div class="my-3">
                            <h2 class="text-2xl">{{ $blog->user->name }} Details</h2>
                        </div>
                        <div class=" block lg:flex items-start gap-5">
                            <div class="w-full">
                                <div class="bg-white overflow-hidden shadow rounded-lg border">
                                    <div class="px-4 py-5 sm:px-6">
                                        <h3 class="text-lg leading-6 font-medium text-gray-900">
                                            User Profile
                                        </h3>
                                    </div>
                                    <div class="border-t border-gray-200 px-4 py-5 sm:p-0">
                                        <dl class="sm:divide-y sm:divide-gray-200">
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    Full name
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ $blog->user->name }}
                                                </dd>
                                            </div>
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    Email address
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ $blog->user->email }}
                                                </dd>
                                            </div>
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    Join Date
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ date('Y-m-d', strtotime($blog->user->created_at)) }}
                                                </dd>
                                            </div>
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    State
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ $blog->user->state }}
                                                </dd>
                                            </div>
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    City
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ $blog->user->city }}
                                                </dd>
                                            </div>
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    Pincode
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ $blog->user->pincode }}
                                                </dd>
                                            </div>
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    Address
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ $blog->user->address }}
                                                </dd>
                                            </div>
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    Follow us on Facebook
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ $blog->user->facebook }}
                                                </dd>
                                            </div>
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    Follow us on Twitter
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ $blog->user->twitter }}
                                                </dd>
                                            </div>
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    Website Name
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ $blog->user->website_name }}
                                                </dd>
                                            </div>
                                            <div class="py-3 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                                <dt class="text-sm font-medium text-gray-500">
                                                    Bio
                                                </dt>
                                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                                    {{ $blog->user->bio }}
                                                </dd>
                                            </div>
                                        </dl>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                @endif
                <section class="py-8 lg:py-16">
                    <div class="max-w-3xl">
                        <div class="flex justify-between items-center mb-6">
                            <h2 class="text-lg lg:text-2xl font-bold text-gray-900 ">Comments (<span
                                    id="comment_count">{{ $blog->comments()->where('status', 1)->count() }})</span>
                            </h2>
                        </div>
                        <form class="mb-6" id="comment_post">

                            @csrf
                            @honeypot
                            <div class="py-2 px-4 mb-4 bg-white rounded-lg rounded-t-lg border border-gray-200">
                                <label for="comment" class="sr-only">Your comment</label>
                                <input type="hidden" name="blog_id" value="{{ request()->id }}">
                                <input type="hidden" name="is_feature" value="{{ $type == 'featured' ? 1 : 0 }}">
                                <textarea id="comment" name="comment" rows="6"
                                    class="px-0 w-full text-sm text-gray-900 border-0 focus:ring-0 focus:outline-none  "
                                    placeholder="Write a comment..."></textarea>
                            </div>
                            <div id='alertMsg' class='space-y-4'></div>
                            @auth
                                <div class="text-left">
                                    <button id="post_comment" type="submit"
                                        class="secondary_color border text-white font-bold py-2 mt-4 w-24 rounded">Submit
                                    </button>
                                    <div class="w-24 hidden" id="loading">
                                        <svg aria-hidden="true"
                                            class="w-8 h-8 my-auto mx-auto text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                                            viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                                fill="currentColor" />
                                            <path
                                                d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                                fill="currentFill" />
                                        </svg>
                                    </div>
                                </div>
                            @endauth
                            @guest
                                <a href="{{ route('user.login') }}"
                                    class="inline-flex items-center secondary_color py-2.5 px-4 text-xs font-medium text-center text-white bg-primary-700 rounded-full focus:ring-4 focus:ring-primary-200 hover:bg-primary-800">
                                    Submit
                                </a>
                            @endguest
                        </form>
                        <div id="comment-lists"></div>

                    </div>
                </section>
                <div class="mt-4">
                    <x-ads-section :name="'screens'" :position="'bottom'" />
                </div>
            </div>
            @include('includes.sidebar')
        </div>

    </section>
@endsection

@section('script')
    <script>
        function getComments() {
            var blog_id = "{{ request()->id }}";

            var url = "{{ route('blog.comments') }}";
            $.ajax({
                url: url,
                type: 'GET',
                data: {
                    blog_id: blog_id,
                    is_feature: "{{ $type == 'featured' ? 1 : 0 }}"
                },
                success: function(data) {
                    $('#comment-lists').html(data);
                },
                error: function(data) {

                }
            });
        }
        getComments();
        $('#comment_post').on('submit', function(e) {
            e.preventDefault();
            $("#post_comment").addClass('hidden')
            $("#loading").removeClass('hidden').addClass('flex')
            const form_data = new FormData(this);
            $.ajax({
                type: 'POST',
                url: '{{ route('user.blog.comment') }}',
                data: form_data,
                contentType: false,
                dataType: 'json',
                processData: false,
                success: function(response) {
                    $("#loading").addClass('hidden')
                    $("#post_comment").removeClass('hidden')
                    if (response.success) {

                        response.message.forEach(message => {
                            appendAlert(message, "success");
                        });

                        let comment_count = $("#comment_count").text();
                        let new_comment_count = parseInt(comment_count) + 1;
                        $("#comment_count").text(new_comment_count);
                        getComments();
                        $("#comment_post").trigger('reset')
                    } else {
                        response.message.forEach(message => {
                            appendAlert(message, "success");
                        });
                    }
                }
            })
        });
    </script>
@endsection
