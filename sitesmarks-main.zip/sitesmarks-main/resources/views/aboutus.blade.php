@extends('layouts.app')

<x-seo-section :page="'about-us'" />

@section('content')
    <x-breadcrumb :name="'About us'" :page="'About us'" />
    <div class="container mx-auto px-5 my-5">
        <section class=" pt-20 pb-12 lg:pt-[120px] lg:pb-[90px] bg-white">
            <div class="container mx-auto">
                <div class="flex flex-wrap items-center justify-center -mx-4">
                    <div class="w-full px-4 lg:w-6/12">
                        <div class="flex items-center -mx-3 sm:-mx-4">
                            <div class="w-full px-3 sm:px-4 xl:w-1/3">
                                <div class="py-3 sm:py-4">
                                    <img loading="lazy"
                                        src="https://cdn.tailgrids.com/2.0/image/marketing/images/about/about-01/image-1.jpg"
                                        alt="" class="w-full rounded-2xl" />
                                </div>
                                <div class="py-3 sm:py-4">
                                    <img loading="lazy"
                                        src="https://cdn.tailgrids.com/2.0/image/marketing/images/about/about-01/image-2.jpg"
                                        alt="" class="w-full rounded-2xl" />
                                </div>
                            </div>
                            <div class="w-full  xl:w-1/2">
                                <div class="relative z-10 my-4">
                                    <img loading="lazy"
                                        src="https://cdn.tailgrids.com/2.0/image/marketing/images/about/about-01/image-3.jpg"
                                        alt="" class="w-full rounded-2xl" />
                                    <span class="absolute -right-7 -bottom-7 z-[-1]">
                                        <svg width="134" height="106" viewBox="0 0 134 106" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <circle cx="1.66667" cy="104" r="1.66667"
                                                transform="rotate(-90 1.66667 104)" fill="#3056D3" />
                                            <circle cx="16.3333" cy="104" r="1.66667"
                                                transform="rotate(-90 16.3333 104)" fill="#3056D3" />
                                            <circle cx="31" cy="104" r="1.66667" transform="rotate(-90 31 104)"
                                                fill="#3056D3" />
                                            <circle cx="45.6667" cy="104" r="1.66667"
                                                transform="rotate(-90 45.6667 104)" fill="#3056D3" />
                                            <circle cx="60.3334" cy="104" r="1.66667"
                                                transform="rotate(-90 60.3334 104)" fill="#3056D3" />
                                            <circle cx="88.6667" cy="104" r="1.66667"
                                                transform="rotate(-90 88.6667 104)" fill="#3056D3" />
                                            <circle cx="117.667" cy="104" r="1.66667"
                                                transform="rotate(-90 117.667 104)" fill="#3056D3" />
                                            <circle cx="74.6667" cy="104" r="1.66667"
                                                transform="rotate(-90 74.6667 104)" fill="#3056D3" />
                                            <circle cx="103" cy="104" r="1.66667"
                                                transform="rotate(-90 103 104)" fill="#3056D3" />
                                            <circle cx="132" cy="104" r="1.66667"
                                                transform="rotate(-90 132 104)" fill="#3056D3" />
                                            <circle cx="1.66667" cy="89.3333" r="1.66667"
                                                transform="rotate(-90 1.66667 89.3333)" fill="#3056D3" />
                                            <circle cx="16.3333" cy="89.3333" r="1.66667"
                                                transform="rotate(-90 16.3333 89.3333)" fill="#3056D3" />
                                            <circle cx="31" cy="89.3333" r="1.66667"
                                                transform="rotate(-90 31 89.3333)" fill="#3056D3" />
                                            <circle cx="45.6667" cy="89.3333" r="1.66667"
                                                transform="rotate(-90 45.6667 89.3333)" fill="#3056D3" />
                                            <circle cx="60.3333" cy="89.3338" r="1.66667"
                                                transform="rotate(-90 60.3333 89.3338)" fill="#3056D3" />
                                            <circle cx="88.6667" cy="89.3338" r="1.66667"
                                                transform="rotate(-90 88.6667 89.3338)" fill="#3056D3" />
                                            <circle cx="117.667" cy="89.3338" r="1.66667"
                                                transform="rotate(-90 117.667 89.3338)" fill="#3056D3" />
                                            <circle cx="74.6667" cy="89.3338" r="1.66667"
                                                transform="rotate(-90 74.6667 89.3338)" fill="#3056D3" />
                                            <circle cx="103" cy="89.3338" r="1.66667"
                                                transform="rotate(-90 103 89.3338)" fill="#3056D3" />
                                            <circle cx="132" cy="89.3338" r="1.66667"
                                                transform="rotate(-90 132 89.3338)" fill="#3056D3" />
                                            <circle cx="1.66667" cy="74.6673" r="1.66667"
                                                transform="rotate(-90 1.66667 74.6673)" fill="#3056D3" />
                                            <circle cx="1.66667" cy="31.0003" r="1.66667"
                                                transform="rotate(-90 1.66667 31.0003)" fill="#3056D3" />
                                            <circle cx="16.3333" cy="74.6668" r="1.66667"
                                                transform="rotate(-90 16.3333 74.6668)" fill="#3056D3" />
                                            <circle cx="16.3333" cy="31.0003" r="1.66667"
                                                transform="rotate(-90 16.3333 31.0003)" fill="#3056D3" />
                                            <circle cx="31" cy="74.6668" r="1.66667"
                                                transform="rotate(-90 31 74.6668)" fill="#3056D3" />
                                            <circle cx="31" cy="31.0003" r="1.66667"
                                                transform="rotate(-90 31 31.0003)" fill="#3056D3" />
                                            <circle cx="45.6667" cy="74.6668" r="1.66667"
                                                transform="rotate(-90 45.6667 74.6668)" fill="#3056D3" />
                                            <circle cx="45.6667" cy="31.0003" r="1.66667"
                                                transform="rotate(-90 45.6667 31.0003)" fill="#3056D3" />
                                            <circle cx="60.3333" cy="74.6668" r="1.66667"
                                                transform="rotate(-90 60.3333 74.6668)" fill="#3056D3" />
                                            <circle cx="60.3333" cy="30.9998" r="1.66667"
                                                transform="rotate(-90 60.3333 30.9998)" fill="#3056D3" />
                                            <circle cx="88.6667" cy="74.6668" r="1.66667"
                                                transform="rotate(-90 88.6667 74.6668)" fill="#3056D3" />
                                            <circle cx="88.6667" cy="30.9998" r="1.66667"
                                                transform="rotate(-90 88.6667 30.9998)" fill="#3056D3" />
                                            <circle cx="117.667" cy="74.6668" r="1.66667"
                                                transform="rotate(-90 117.667 74.6668)" fill="#3056D3" />
                                            <circle cx="117.667" cy="30.9998" r="1.66667"
                                                transform="rotate(-90 117.667 30.9998)" fill="#3056D3" />
                                            <circle cx="74.6667" cy="74.6668" r="1.66667"
                                                transform="rotate(-90 74.6667 74.6668)" fill="#3056D3" />
                                            <circle cx="74.6667" cy="30.9998" r="1.66667"
                                                transform="rotate(-90 74.6667 30.9998)" fill="#3056D3" />
                                            <circle cx="103" cy="74.6668" r="1.66667"
                                                transform="rotate(-90 103 74.6668)" fill="#3056D3" />
                                            <circle cx="103" cy="30.9998" r="1.66667"
                                                transform="rotate(-90 103 30.9998)" fill="#3056D3" />
                                            <circle cx="132" cy="74.6668" r="1.66667"
                                                transform="rotate(-90 132 74.6668)" fill="#3056D3" />
                                            <circle cx="132" cy="30.9998" r="1.66667"
                                                transform="rotate(-90 132 30.9998)" fill="#3056D3" />
                                            <circle cx="1.66667" cy="60.0003" r="1.66667"
                                                transform="rotate(-90 1.66667 60.0003)" fill="#3056D3" />
                                            <circle cx="1.66667" cy="16.3333" r="1.66667"
                                                transform="rotate(-90 1.66667 16.3333)" fill="#3056D3" />
                                            <circle cx="16.3333" cy="60.0003" r="1.66667"
                                                transform="rotate(-90 16.3333 60.0003)" fill="#3056D3" />
                                            <circle cx="16.3333" cy="16.3333" r="1.66667"
                                                transform="rotate(-90 16.3333 16.3333)" fill="#3056D3" />
                                            <circle cx="31" cy="60.0003" r="1.66667"
                                                transform="rotate(-90 31 60.0003)" fill="#3056D3" />
                                            <circle cx="31" cy="16.3333" r="1.66667"
                                                transform="rotate(-90 31 16.3333)" fill="#3056D3" />
                                            <circle cx="45.6667" cy="60.0003" r="1.66667"
                                                transform="rotate(-90 45.6667 60.0003)" fill="#3056D3" />
                                            <circle cx="45.6667" cy="16.3333" r="1.66667"
                                                transform="rotate(-90 45.6667 16.3333)" fill="#3056D3" />
                                            <circle cx="60.3333" cy="60.0003" r="1.66667"
                                                transform="rotate(-90 60.3333 60.0003)" fill="#3056D3" />
                                            <circle cx="60.3333" cy="16.3333" r="1.66667"
                                                transform="rotate(-90 60.3333 16.3333)" fill="#3056D3" />
                                            <circle cx="88.6667" cy="60.0003" r="1.66667"
                                                transform="rotate(-90 88.6667 60.0003)" fill="#3056D3" />
                                            <circle cx="88.6667" cy="16.3333" r="1.66667"
                                                transform="rotate(-90 88.6667 16.3333)" fill="#3056D3" />
                                            <circle cx="117.667" cy="60.0003" r="1.66667"
                                                transform="rotate(-90 117.667 60.0003)" fill="#3056D3" />
                                            <circle cx="117.667" cy="16.3333" r="1.66667"
                                                transform="rotate(-90 117.667 16.3333)" fill="#3056D3" />
                                            <circle cx="74.6667" cy="60.0003" r="1.66667"
                                                transform="rotate(-90 74.6667 60.0003)" fill="#3056D3" />
                                            <circle cx="74.6667" cy="16.3333" r="1.66667"
                                                transform="rotate(-90 74.6667 16.3333)" fill="#3056D3" />
                                            <circle cx="103" cy="60.0003" r="1.66667"
                                                transform="rotate(-90 103 60.0003)" fill="#3056D3" />
                                            <circle cx="103" cy="16.3333" r="1.66667"
                                                transform="rotate(-90 103 16.3333)" fill="#3056D3" />
                                            <circle cx="132" cy="60.0003" r="1.66667"
                                                transform="rotate(-90 132 60.0003)" fill="#3056D3" />
                                            <circle cx="132" cy="16.3333" r="1.66667"
                                                transform="rotate(-90 132 16.3333)" fill="#3056D3" />
                                            <circle cx="1.66667" cy="45.3333" r="1.66667"
                                                transform="rotate(-90 1.66667 45.3333)" fill="#3056D3" />
                                            <circle cx="1.66667" cy="1.66683" r="1.66667"
                                                transform="rotate(-90 1.66667 1.66683)" fill="#3056D3" />
                                            <circle cx="16.3333" cy="45.3333" r="1.66667"
                                                transform="rotate(-90 16.3333 45.3333)" fill="#3056D3" />
                                            <circle cx="16.3333" cy="1.66683" r="1.66667"
                                                transform="rotate(-90 16.3333 1.66683)" fill="#3056D3" />
                                            <circle cx="31" cy="45.3333" r="1.66667"
                                                transform="rotate(-90 31 45.3333)" fill="#3056D3" />
                                            <circle cx="31" cy="1.66683" r="1.66667"
                                                transform="rotate(-90 31 1.66683)" fill="#3056D3" />
                                            <circle cx="45.6667" cy="45.3333" r="1.66667"
                                                transform="rotate(-90 45.6667 45.3333)" fill="#3056D3" />
                                            <circle cx="45.6667" cy="1.66683" r="1.66667"
                                                transform="rotate(-90 45.6667 1.66683)" fill="#3056D3" />
                                            <circle cx="60.3333" cy="45.3338" r="1.66667"
                                                transform="rotate(-90 60.3333 45.3338)" fill="#3056D3" />
                                            <circle cx="60.3333" cy="1.66683" r="1.66667"
                                                transform="rotate(-90 60.3333 1.66683)" fill="#3056D3" />
                                            <circle cx="88.6667" cy="45.3338" r="1.66667"
                                                transform="rotate(-90 88.6667 45.3338)" fill="#3056D3" />
                                            <circle cx="88.6667" cy="1.66683" r="1.66667"
                                                transform="rotate(-90 88.6667 1.66683)" fill="#3056D3" />
                                            <circle cx="117.667" cy="45.3338" r="1.66667"
                                                transform="rotate(-90 117.667 45.3338)" fill="#3056D3" />
                                            <circle cx="117.667" cy="1.66683" r="1.66667"
                                                transform="rotate(-90 117.667 1.66683)" fill="#3056D3" />
                                            <circle cx="74.6667" cy="45.3338" r="1.66667"
                                                transform="rotate(-90 74.6667 45.3338)" fill="#3056D3" />
                                            <circle cx="74.6667" cy="1.66683" r="1.66667"
                                                transform="rotate(-90 74.6667 1.66683)" fill="#3056D3" />
                                            <circle cx="103" cy="45.3338" r="1.66667"
                                                transform="rotate(-90 103 45.3338)" fill="#3056D3" />
                                            <circle cx="103" cy="1.66683" r="1.66667"
                                                transform="rotate(-90 103 1.66683)" fill="#3056D3" />
                                            <circle cx="132" cy="45.3338" r="1.66667"
                                                transform="rotate(-90 132 45.3338)" fill="#3056D3" />
                                            <circle cx="132" cy="1.66683" r="1.66667"
                                                transform="rotate(-90 132 1.66683)" fill="#3056D3" />
                                        </svg>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-full lg:w-1/2 xl:w-5/12">
                        <div class="mt-10 lg:mt-0">
                            About Us
                            <span class="block mb-4 text-lg font-semibold text-primary">
                                Why Choose Us
                            </span>
                            <h2 class="mb-5 text-3xl font-bold sm:text-[40px]/[48px]">
                                Boost your online presence with {{ env('APP_NAME') }}
                            </h2>
                            <div class="mb-5 text-base text-body-color ">
                                <p>
                                    Welcome to {{ env('APP_NAME') }}, where you can easily bookmark and submit articles for
                                    free. Add a
                                    single bookmark or blog post, and we'll list it across all our domains and sub-domains.
                                    Our
                                    goal is to make it simple for you to list your content/backlinks and reach a wider
                                    audience
                                    effortlessly. Join us today and enjoy a great experience in boosting your online
                                    presence
                                    and get more leads and sales.
                                </p>
                                <p>
                                    For our guest users, we offer a variety of bookmarking and article listings to explore.
                                    Discover diverse topics, business listings, and find valuable content listed by our
                                    community. Whether you're looking for inspiration, information, or just browsing, our
                                    platform is a rich resource of shared knowledge and insights. Dive in and see what our
                                    community has to offer!
                                </p>



                            </div>
                            <p class="mb-8 text-base text-body-color ">
                                Please <a href="{{ route('user.contact') }}" class="text-blue-500 underline">Contact
                                    Us</a> for more information regarding us and services we offer. Meanwhile, you
                                can follow us using Facebook, Twitter and Instagram. Enjoy!
                            </p>
                            <a href="{{ route('user.register') }}"
                                class="inline-flex items-center justify-center py-3 text-base font-medium text-center text-white secondary_color border border-transparent rounded-md px-7 bg-primary hover:bg-opacity-90">
                                Get Started
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
