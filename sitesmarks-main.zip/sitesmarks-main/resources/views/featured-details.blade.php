@extends('layouts.app')
@section('seo')
    <title>{{ $bookmark->title }} - {{ env('APP_NAME') }}</title>
    <meta name="description" content="{{ Illuminate\Support\Str::limit(strip_tags($bookmark->description), 160, '.....') }}">
    <meta name="author" content="Admin">
@endsection
@section('content')
    <style>
        .bookmark-desc a {
            color: {{ $setting->primary_color }};
            text-decoration: none;
            font-weight: bold;

        }

        .bookmark-desc * {
            font-size: revert !important;
            font-weight: revert !important;
            line-height: revert !important;
        }

        .bookmark-desc ol,
        .bookmark-desc ul,
        .bookmark-desc menu {
            list-style: disc !important;
            padding: 0;
            margin-left: 40px !important;
        }

        .bookmark-desc p {
            font-size: 16px;
            line-height: 1.5;
            color: black;
            /* Default text color */
        }

        .bookmark-desc a:hover {
            text-decoration: underline;
        }
    </style>
    <x-breadcrumb :name="$bookmark->title" :page="'Featured Bookmark'" :category="'Bookmarks'" />
    <section>
        <div class="mt-4">
            <x-ads-section :name="'screens'" :position="'top'" />
        </div>
        <div class=" mt-10 max-w-xs mx-auto ">
            <h2 class="text-center text-3xl border rounded-full py-4 border-black">Feature Submission</h2>
        </div>
        <div class="container mx-auto px-3 md:px-10 my-4 mt-10">
            <div class=" block lg:flex items-start gap-5">
                <div class="lg:w-[70%] w-full ">

                    @if ($bookmark)
                        <div class=" px-4 py-6 border-b my-4 rounded-xl">

                            <div class="flex items-start ">
                                <img class="w-12 h-12 rounded-full object-cover mr-4 shadow border"
                                    src="{{ '/assets/images/admin_profile.jpeg' }}" alt="avatar">

                                <div class="w-full">
                                    <div class="flex items-center justify-between">
                                        <div class=" -mt-1 flex gap-2 underline-hover-effect">
                                            <div class="primary_color w-2 rounded my-1 "></div>
                                            <h3 class="text-[25px] font-bold ">
                                                {{ $bookmark->title }}
                                            </h3>
                                        </div>
                                        <button style="background-color: green"
                                            class="animate-bounce flex gap-2  px-4 py-2 text-white rounded-full">
                                            Featured
                                            <img src="{{ asset('assets/pin-svg.svg') }}" class="my-auto"
                                                alt="featured-pin.svg">
                                        </button>
                                    </div>
                                    <div class="flex items-center space-x-4 flex-wrap">
                                        <div>
                                            <span class="text-gray-700">Submited By</span>
                                            <a class="flip-animate">
                                                <span data-hover="{{ 'Admin' }}">
                                                    {{ 'Admin' }}
                                                </span>
                                            </a>
                                        </div>

                                    </div>
                                    <div class="flex items-center -ml-2 my-3 ">
                                        <div class="flex items-center space-x-2 ">

                                            <img src="{{ asset('assets/browser-svg.svg') }}" class="h-5 w-5"
                                                alt="bookmark-url.svg">

                                            <a href="{{ $bookmark->url }}" target="_blank" class="text-blue-500 underline">
                                                {{-- {{ Illuminate\Support\Str::limit($bookmark->url, 80, '.....') }} --}}
                                                {{ config('app.url') }}
                                            </a>
                                        </div>
                                    </div>
                                    <div class="flex items-center -ml-2 my-3 flex-wrap">

                                        <div class="flex items-center space-x-2 ">
                                            <img src="{{ asset('assets/mail-svg.svg') }}" class="h-5 w-5" alt="mail.svg">
                                            @php
                                                $appUrl = config('app.url');
                                                $domain = parse_url($appUrl, PHP_URL_HOST);
                                                $email = 'admin@' . $domain;
                                            @endphp
                                            <span class="text_color ">{{ $email }}</span>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="mt-4">
                                <x-ads-section :name="'screens'" :position="'inside'" />
                            </div>
                            <div class="bookmark-desc mt-3" style="margin-bottom: 20px;">
                                {!! $bookmark->description !!}
                            </div>
                            <div class="mt-4">
                                <x-ads-section :name="'screens'" :position="'inside'" />
                            </div>

                        </div>
                    @endif
                    <div class="mt-4">
                        <x-ads-section :name="'screens'" :position="'bottom'" />
                    </div>
                </div>
                @include('includes.sidebar')
            </div>

        </div>
    </section>
@endsection
@section('script')
@endsection
