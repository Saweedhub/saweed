@props(['bookmarks', 'feature_bookmark', 'feature_bookmark_url'])
<div class="mb-4">
    <x-ads-section :name="'bookmark-list'" :position="'top'" />
</div>
<style>
    .bookmark-desc a {
        color: {{ $setting->primary_color }};
        text-decoration: none;
        font-weight: bold;

    }

    .bookmark-desc p {
        font-size: 16px;
        line-height: 1.5;
        color: black;
        /* Default text color */
    }

    .bookmark-desc a:hover {
        text-decoration: underline;
    }
</style>
<div class="my-4 max-w-xs mx-auto ">
    <h2 class="text-center text-3xl border rounded-full py-4 border-black cursor-default">Latest Submission</h2>
</div>
<div class="container mx-auto px-3 md:px-10 my-4 mt-10 ">
    <div class=" block lg:flex items-start gap-5">
        <div class="lg:w-[70%] w-full ">
            @if ($feature_bookmark)
                <div class=" block px-4 pb-2 py-6 border shadow my-4 rounded-xl">
                    <div class="flex items-start ">
                        <img class="w-12 h-12 rounded-full object-cover mr-4 shadow border" loading="lazy"
                            src="{{ '/assets/images/admin_profile.jpeg' }}" alt="avatar">
                        <div class="w-full">
                            <div class="flex items-center justify-between">
                                <div class="flex gap-2">

                                    <div class="primary_color w-2 rounded my-1 "></div>
                                    <h3 class=" mr-4">
                                        <a href="{{ $feature_bookmark_url }}"
                                            class="text-lg lg:text-2xl font-bold  -mt-1 underline-hover-effect">
                                            {{ $feature_bookmark->title }}
                                        </a>
                                    </h3>
                                </div>


                                <button onclick="window.open('{{ $feature_bookmark_url }}','_self')"
                                    style="background-color: green"
                                    class="animate-bounce flex gap-2 justify-center px-4 py-2 text-white rounded-full">
                                    <span>
                                        Featured
                                    </span>

                                    <img src="{{ asset('assets/pin-svg.svg') }}" loading="lazy" class="my-auto"
                                        alt="featured-pin.svg">
                                </button>
                            </div>
                            <div class="flex items-center space-x-4 flex-wrap mt-2 md:mt-0">
                                <div>
                                    <span class="text-gray-700">Submited By</span>
                                    <a class="flip-animate" href="{{ $feature_bookmark_url }}">
                                        <span data-hover="{{ 'Admin' }}">
                                            {{ 'Admin' }}
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="flex items-center -ml-2 my-3 ">
                                <div class="flex items-center space-x-2 ">

                                    <img src="{{ asset('assets/browser-svg.svg') }}" class="h-5 w-5" loading="lazy"
                                        alt="bookmark-url.svg">

                                    <a rel="nofollow" href="{{ $feature_bookmark->url }}" target="_blank"
                                        class="text-blue-500 underline">
                                        {{-- {{ Illuminate\Support\Str::limit($feature_bookmark->url, 80, '.....') }} --}}
                                        {{ config('app.url') }}
                                    </a>
                                </div>
                            </div>
                            <div class="flex items-center -ml-2 my-3 flex-wrap">
                                <div class="flex items-center space-x-2 ">
                                    <img src="{{ asset('assets/mail-svg.svg') }}" class="h-5 w-5" loading="lazy"
                                        alt="mail.svg">
                                    @php
                                        $appUrl = config('app.url');
                                        $domain = parse_url($appUrl, PHP_URL_HOST);
                                        $email = 'admin@' . $domain;
                                    @endphp
                                    <span class="text_color ">{{ $email }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mb-4">
                        <x-ads-section :name="'bookmark-list'" :position="'inside'" />
                    </div>

                    <div class="bookmark-desc mt-3 text-gray-700 text-sm" style="margin-bottom: 20px;">
                        {{-- {!! Illuminate\Support\Str::limit($feature_bookmark->description, 250, '.....') !!} --}}
                    </div>
                    <div class="md:text-start text-end">
                        <button onclick="window.open('{{ $feature_bookmark_url }}','_self')"
                            class=" readmorebutton secondary_color rounded px-4 py-2 text-lg text-white tracking-wide font-semibold font-sans"><span>Read
                                More</span></button>
                    </div>

                </div>
                <div class="mb-4">
                    <x-ads-section :name="'bookmark-list'" :position="'between'" />
                </div>
            @endif

            @foreach ($bookmarks->sortByDesc('is_paid') as $bookmark)
                @php
                    $category = Illuminate\Support\Str::slug($bookmark->cat_id);
                    $bookmark_url = "/bookmarks/$category/$bookmark->slug";
                @endphp
                <div class=" px-4 py-2 my-4 rounded-xl border">
                    <header class="flex font-light text-sm my-4  justify-between">
                        <div class="flex">
                            <div class="h-6 w-1 mr-2 rounded bg-[#b91c1c]"></div>
                            <p>{{ $bookmark->cat_id }}</p>
                        </div>
                        @if ($bookmark->is_paid && $bookmark->by_admin)
                            <button class="secondary_color px-4 py-2 text-white rounded-full flex gap-2">
                                <svg class="w-4 h-4 m-auto" viewBox="0 0 84 84" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M41.6667 83.3333C64.6785 83.3333 83.3333 64.6785 83.3333 41.6667C83.3333 18.6548 64.6785 0 41.6667 0C18.6548 0 0 18.6548 0 41.6667C0 64.6785 18.6548 83.3333 41.6667 83.3333Z"
                                        fill="url(#paint0_linear_217_147)" />
                                    <path
                                        d="M41.6667 77.0833C61.2267 77.0833 77.0833 61.2267 77.0833 41.6667C77.0833 22.1066 61.2267 6.25 41.6667 6.25C22.1066 6.25 6.25 22.1066 6.25 41.6667C6.25 61.2267 22.1066 77.0833 41.6667 77.0833Z"
                                        fill="#F5BE00" />
                                    <path
                                        d="M52.604 48.6497C52.604 37.9393 36.7915 40.0309 36.7915 33.7038C36.7915 30.4018 40.5061 30.2268 41.6665 30.2268C44.4582 30.2268 47.1519 30.9747 49.2061 31.9393C49.854 32.2434 50.5978 31.7934 50.5978 31.0788V27.9622C50.5978 26.9163 50.204 26.2976 49.5769 26.0518C48.1686 25.5059 46.1478 25.1038 43.1561 25.0059V21.5768C43.1561 21.1663 42.8228 20.833 42.4123 20.833H40.9248C40.5144 20.833 40.1811 21.1663 40.1811 21.5768V25.0622C35.5394 25.5122 30.729 28.1309 30.729 34.2205C30.729 45.3226 46.5415 43.1205 46.5415 48.9684C46.5415 50.8059 45.3665 52.3893 41.6665 52.3893C37.9457 52.3893 34.5269 51.0893 32.6353 50.1226C31.9978 49.7976 31.2478 50.2684 31.2478 50.9851V54.533C31.2478 55.2143 31.6561 55.8184 32.2853 56.083C34.5269 57.0351 37.5353 57.7559 40.179 57.9663V61.758C40.179 62.1684 40.5123 62.5018 40.9228 62.5018H42.4103C42.8207 62.5018 43.154 62.1684 43.154 61.758V57.9768C50.0936 57.3976 52.604 52.7497 52.604 48.6497Z"
                                        fill="#FEE119" />
                                    <defs>
                                        <linearGradient id="paint0_linear_217_147" x1="13.0687" y1="13.0667"
                                            x2="71.0667" y2="71.0687" gradientUnits="userSpaceOnUse">
                                            <stop stop-color="#FEDE00" />
                                            <stop offset="1" stop-color="#FFD000" />
                                        </linearGradient>
                                    </defs>
                                </svg>
                                Sponsored
                            </button>
                        @endif
                    </header>
                    <div class="flex items-start ">
                        <img class="w-12 h-12 rounded-full object-cover mr-4 shadow"
                            src="{{ $bookmark->user->image ? (Str::startsWith($bookmark->user->image, ['http://', 'https://']) ? $bookmark->user->image : asset('storage/' . $bookmark->user->image)) : '/assets/images/user_profile_placeholder.webp' }}"
                            loading="lazy" alt="avatar">
                        <div class="w-full break-all">
                            <h3>
                                <a href="{{ $bookmark_url }}"
                                    class="break-all text-lg font-semibold text_color -mt-1 underline-hover-effect">{{ $bookmark->title }}
                                </a>
                            </h3>
                            <div class="flex break-all items-center space-x-4 flex-wrap mt-2 ">
                                <div>
                                    <span class="text-gray-700">Submited By</span>
                                    <a class="flip-animate" href="{{ $bookmark_url }}">
                                        <span data-hover="{{ $bookmark->user->name }}">
                                            {{ $bookmark->user->name }}
                                        </span>
                                    </a>
                                </div>

                                <div class="flex items-center space-x-2 ">
                                    <svg class="w-4 h-4" viewBox="0 0 84 92" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M34 0V6H38V8.19531C16.7006 10.2149 0 28.1776 0 50C0 73.1723 18.8277 92 42 92C65.1723 92 84 73.1723 84 50C84 28.1776 67.2994 10.2149 46 8.19531V6H50V0H34ZM72.4727 6.29297L68.4609 10.3047L77.6914 19.5352L81.7031 15.5234L72.4727 6.29297ZM42 12C63.0105 12 80 28.9895 80 50C80 71.0105 63.0105 88 42 88C20.9895 88 4 71.0105 4 50C4 28.9895 20.9895 12 42 12ZM21.9805 27.9805C21.5826 27.9806 21.1938 28.0993 20.8638 28.3216C20.5338 28.5438 20.2775 28.8594 20.1278 29.228C19.9781 29.5966 19.9417 30.0015 20.0233 30.3909C20.1049 30.7803 20.3008 31.1366 20.5859 31.4141L38.1406 48.9688C38.049 49.3049 38.0018 49.6516 38 50C38 51.0609 38.4214 52.0783 39.1716 52.8284C39.9217 53.5786 40.9391 54 42 54C42.3495 53.9999 42.6976 53.9539 43.0352 53.8633L46.5859 57.4141C46.7702 57.606 46.991 57.7593 47.2352 57.8648C47.4795 57.9704 47.7423 58.0262 48.0084 58.0289C48.2745 58.0316 48.5385 57.9812 48.7848 57.8806C49.0312 57.78 49.255 57.6313 49.4431 57.4431C49.6313 57.255 49.78 57.0312 49.8806 56.7848C49.9812 56.5385 50.0316 56.2745 50.0289 56.0084C50.0262 55.7423 49.9704 55.4795 49.8648 55.2352C49.7593 54.991 49.606 54.7702 49.4141 54.5859L45.8594 51.0312C45.951 50.6951 45.9982 50.3484 46 50C46 48.9391 45.5786 47.9217 44.8284 47.1716C44.0783 46.4214 43.0609 46 42 46C41.6505 46.0001 41.3024 46.0461 40.9648 46.1367L23.4141 28.5859C23.2277 28.3943 23.0048 28.2421 22.7586 28.1381C22.5123 28.0341 22.2478 27.9805 21.9805 27.9805Z"
                                            fill="black" />
                                    </svg>
                                    <span class="text_color">about {{ $bookmark->created_at->diffForHumans() }}
                                    </span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />
                                    </svg>
                                    <x-bookmark-share :bookmark="$bookmark" :bookmark_url="$bookmark_url" />
                                </div>
                                <a href="{{ $bookmark_url }}" class="break-all flex items-center space-x-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 0 1-2.555-.337A5.972 5.972 0 0 1 5.41 20.97a5.969 5.969 0 0 1-.474-.065 4.48 4.48 0 0 0 .978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25Z" />
                                    </svg>
                                    <span class="text_color">1 Comment</span>
                                </a>
                            </div>
                            <div class="flex break-all items-center -ml-2 my-2">
                                <div class="flex items-center space-x-2 ml">
                                    <img loading="lazy" src="{{ asset('assets/browser-svg.svg') }}" class="h-5 w-5"
                                        alt="bookmark-url.svg">
                                    </svg>
                                    <a href="{{ $bookmark->url }}" target="_blank"
                                        rel="{{ $bookmark->follow ? 'dofollow' : 'nofollow' }}"
                                        class="break-all text-blue-500 hover:underline">{{ Illuminate\Support\Str::limit($bookmark->url, 90, '.....') }}</a>
                                </div>
                            </div>
                            <div class="flex break-all items-center -ml-2 my-2 flex-wrap ">
                                @if ($bookmark->user->mobile)
                                    <div class="flex items-center space-x-2 mr-8">
                                        <img loading="lazy" src="{{ asset('assets/phone-svg.svg') }}"
                                            class="h-5 w-5" alt="phone.svg">
                                        </svg>
                                        <span class="text_color ">{{ $bookmark->user->mobile }}</span>
                                    </div>
                                @endif
                                <div class="flex items-center space-x-2 ">
                                    <img src="{{ asset('assets/mail-svg.svg') }}" class="h-5 w-5" alt="mail.svg"
                                        loading="lazy">
                                    <span class="text_color break-all">{{ $bookmark->user->email }}</span>
                                </div>
                            </div>
                            @if ($bookmark->user->address)
                                <div class="flex break-all items-center space-x-2 -ml-2">
                                    <img loading="lazy" src="{{ asset('assets/contact-svg.svg') }}" class="h-5 w-5"
                                        alt="address.svg">

                                    <span class="text_color break-all">{{ $bookmark->user->address }}</span>
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="mb-4">
                        <x-ads-section :name="'bookmark-list'" :position="'inside'" />
                    </div>

                    <p class="mt-3 text-gray-700 text-sm" style="margin-bottom: 20px;">
                        {{-- {{ Illuminate\Support\Str::limit($bookmark->description, 250, '.....') }} --}}
                        {{ Illuminate\Support\Str::limit(strip_tags($bookmark->description), 250, '.....') }}
                    </p>
                    <button onclick="window.open('{{ $bookmark_url }}','_self')"
                        class="readmorebutton secondary_color rounded px-4 py-2 text-lg text-white tracking-wide font-semibold font-sans">

                        <span>Read
                            More</span>

                    </button>

                </div>
                <div class="mb-4">
                    <x-ads-section :name="'bookmark-list'" :position="'between'" />
                </div>
            @endforeach
            {{ $bookmarks->appends(['bookmarks' => $bookmarks->currentPage()])->links() }}
        </div>
        @include('includes.sidebar')
    </div>
</div>
<div class="mb-4">
    <x-ads-section :name="'bookmark-list'" :position="'bottom'" />
</div>
