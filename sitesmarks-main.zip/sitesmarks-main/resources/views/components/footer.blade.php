<footer class="w-full text-white secondary_color">
    <x-ads-section :name="'footer'" :position="'top'" />

    <div class="mx-auto w-full max-w-screen-xl p-4 py-6 lg:py-8">
        <div class="grid grid-cols-1 gap-8 sm:gap-6 md:grid-cols-2 lg:grid-cols-4">
            <div>
                <a href="{{ route('home') }}" class="flex items-center">
                    @if ($setting->footer_logo)
                        <img src="{{  $setting->footer_logo }}" alt="" style="width:220px">
                    @else
                        <div class="flex gap-2">
                            <svg width="32" height="32" viewBox="0 0 32 32" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.29924 29.111C5.36578 32.1774 10.3376 32.1774 13.4041 29.111C14.8365 27.6787 17.7576 24.7576 19.1899 23.3253C22.2565 20.2589 22.2565 15.2872 19.1899 12.2207C16.1234 9.15428 11.1516 9.15428 8.08502 12.2207C6.65271 13.653 3.73155 16.5741 2.29924 18.0064C-0.766412 21.0719 -0.766412 26.0445 2.29924 29.111ZM5.22219 20.9275C6.06489 20.0848 10.378 15.7718 11.008 15.1418C12.46 13.6898 14.8158 13.6898 16.2688 15.1418C17.7217 16.5938 17.7208 18.9496 16.2688 20.4025C15.6379 21.0333 11.3257 25.3454 10.483 26.1881C9.03092 27.6401 6.67515 27.6401 5.22219 26.1881C3.77014 24.7361 3.77014 22.3804 5.22219 20.9275Z"
                                    fill="#fff" />
                                <path opacity="0.05"
                                    d="M15.3821 14.4733C15.3821 14.4733 14.8786 13.2259 16.0184 11.8852L17.15 10.7526C14.534 9.44419 11.3454 9.69008 8.94566 11.4867C8.2663 14.0524 9.25528 16.8945 9.25528 16.8945C10.115 16.0348 10.8025 15.3474 11.0089 15.141C12.1989 13.9528 13.9291 13.7329 15.3821 14.4733Z"
                                    fill="black" />
                                <path opacity="0.07"
                                    d="M14.7359 14.2121C14.6677 13.6629 14.5888 12.5393 15.5804 11.4472C15.6379 11.3897 16.3406 10.67 16.5254 10.486C14.342 9.56978 11.8229 9.74567 9.75426 10.9572C9.05246 13.0876 9.49221 15.5214 9.75426 16.3973C10.3681 15.7835 10.8482 15.3034 11.0098 15.1418C12.0257 14.1251 13.4356 13.8163 14.7359 14.2121Z"
                                    fill="black" />
                                <path
                                    d="M29.1111 2.29985C26.0446 -0.766616 21.0728 -0.766616 18.0062 2.29985C16.5739 3.73212 13.6528 6.6532 12.2204 8.08548C9.1539 11.1519 9.1539 16.1236 12.2204 19.1901C15.287 22.2565 20.2588 22.2565 23.3253 19.1901C24.7577 17.7578 27.6788 14.8367 29.1111 13.4044C32.1768 10.3398 32.1768 5.36631 29.1111 2.29985ZM26.1882 10.4834C25.3455 11.326 21.0324 15.639 20.4024 16.269C18.9503 17.721 16.5946 17.721 15.1416 16.269C13.6887 14.817 13.6895 12.4613 15.1416 11.0084C15.7725 10.3775 20.0847 6.0654 20.9274 5.22272C22.3794 3.77071 24.7352 3.77071 26.1882 5.22272C27.6402 6.67564 27.6402 9.03135 26.1882 10.4834Z"
                                    fill="#000" />
                                <path opacity="0.05"
                                    d="M16.0247 16.9257C16.0247 16.9257 16.5326 18.1857 15.392 19.5265L14.2603 20.659C16.8763 21.9674 20.0649 21.7215 22.4647 19.9249C23.1441 17.3592 22.1551 14.5171 22.1551 14.5171C21.2953 15.3768 20.6079 16.0642 20.4015 16.2706C19.2115 17.4588 17.4328 17.685 16.0247 16.9257Z"
                                    fill="black" />
                                <path opacity="0.07"
                                    d="M16.6869 17.198C16.7551 17.7472 16.8216 18.8717 15.8299 19.9638C15.7725 20.0212 15.0698 20.7239 14.8849 20.9088C17.0684 21.825 19.6117 21.65 21.6597 20.3901C22.3614 18.2596 21.919 15.8895 21.6561 15.0137C21.0422 15.6275 20.5621 16.1076 20.4005 16.2692C19.3855 17.2859 17.9146 17.583 16.6869 17.198Z"
                                    fill="black" />
                                <path
                                    d="M16.2688 15.1418C17.7208 16.5938 17.7208 18.9495 16.2688 20.4024C15.6379 21.0333 11.3257 25.3454 10.483 26.1881L13.4059 29.1109C14.8382 27.6787 17.7594 24.7576 19.1917 23.3253C22.2583 20.2588 22.2583 15.2872 19.1917 12.2207L16.2688 15.1418Z"
                                    fill="#fff" />
                            </svg>
                            <span style="font-size: 30px;font-weight: bold; margin-top:-10px !important"
                                class="text-white">
                                {{ env('APP_NAME') }}</span>
                        </div>
                    @endif
                </a>
                <p class="mt-2 text-sm text-gray-00">{{ $setting->footer_description }}
            </div>
            <div class="flex flex-row justify-start lg:justify-end">
                <ul class="text-gray-500 dark:text-gray-400 font-medium">
                    <li class="mb-4">
                        <h2 class="mb-6 text-lg font-semibold text-white uppercase  ">Quick
                            Links
                        </h2>
                    </li>
                    <li class="mb-4">
                        <a href="{{ route('home') }}" class="hover:underline text-white text-sm">Home</a>
                    </li>
                    <li class="mb-4">
                        <a href="{{ route('user.bookmarks') }}" class="hover:underline text-white text-sm">Bookmarks</a>
                    </li>
                    <li class="mb-4">
                        <a href="{{ route('user.blog') }}" class="hover:underline text-white text-sm">Blogs</a>
                    </li>
                    <li class="mb-4">
                        <a href="{{ route('user.about') }}" class="hover:underline text-white text-sm">About
                            us</a>
                    </li>
                    <li class="mb-4">
                        <a href="{{ route('featured.bookmark.details') }}"
                            class="hover:underline text-white text-sm">Other sites</a>
                    </li>

                </ul>
            </div>
            <div class="flex flex-row justify-start lg:justify-end">
                <ul class="text-gray-500 dark:text-gray-400 font-medium">
                    <li class="mb-4">
                        <h2 class="mb-6 text-lg font-semibold text-white uppercase">Privacy
                            Links
                        </h2>
                    </li>
                    <li class="mb-4">
                        <a href="{{ route('privacyPolicy') }}" class="hover:underline text-white text-sm">Privacy
                            Policy</a>
                    </li>
                    <li class="mb-4">
                        <a href="{{ route('termsCondition') }}" class="hover:underline text-white text-sm">Terms &
                            Conditions</a>
                    </li>
                    <li class="mb-4">
                        <a href="{{ route('user.content') }}" class="hover:underline text-white text-sm">Content
                            Policy</a>
                    </li>
                </ul>
            </div>
            <div class="flex flex-row justify-start lg:justify-end">
                <ul class="text-gray-500 dark:text-gray-400 font-medium">
                    <li class="mb-4">
                        <h2 class="mb-6 text-lg font-semibold text-white uppercase  ">Support
                        </h2>
                    </li>
                    <li class="mb-4">
                        <a href="{{ route('user.contact') }}" class="hover:underline text-white text-sm">Contact
                            Us</a>
                    </li>
                </ul>
            </div>

        </div>
        <x-ads-section :name="'footer'" :position="'inside'" />
        <hr class="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
        <div class="sm:flex sm:items-center sm:justify-between">
            <span class="text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2023 <a
                    href="https://devitcity.com/" rel="nofollow" target="_blank" class="hover:underline text-white text-sm">Dev
                    IT City</a>.
                All
                Rights
                Reserved.
                <a class="underline text-white" target="_blank" href="{{ route('sitemap') }}">Sitemap</a>
            </span>
            {{-- <div class="flex mt-4 sm:justify-center sm:mt-0">
                <a href="https://www.facebook.com/devitcity" rel="nofollow" target="_blank" class="text-white hover:text-black">
                    <svg class="w-4 h-4" aria-hidden="true" fill="currentColor" viewBox="0 0 18 18"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M18 2.75V15.25C18 16.765 16.765 18 15.25 18H12.5V11H14.31C14.565 11 14.78 10.81 14.81 10.56L14.995 9.06C15.015 8.92 14.97 8.775 14.875 8.67C14.78 8.56 14.645 8.5 14.5 8.5H12.5V6.75C12.5 6.2 12.95 5.75 13.5 5.75H14.5C14.775 5.75 15 5.525 15 5.25V3.56C15 3.305 14.8 3.09 14.545 3.065C14.515 3.06 13.81 3 12.915 3C10.715 3 9.5 4.31 9.5 6.685V8.5H7.5C7.225 8.5 7 8.725 7 9V10.5C7 10.775 7.225 11 7.5 11H9.5V18H2.75C1.235 18 0 16.765 0 15.25V2.75C0 1.235 1.235 0 2.75 0H15.25C16.765 0 18 1.235 18 2.75Z" />
                    </svg>
                    <span class="sr-only">Facebook page</span>
                </a>
                <a href="https://www.instagram.com/devitcity/" rel="nofollow" target="_blank" class="text-white hover:text-black ms-5">
                    <svg class="w-4 h-4" aria-hidden="true" viewBox="0 0 18 18" fill="currentColor"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M5 0C2.243 0 0 2.243 0 5V13C0 15.757 2.243 18 5 18H13C15.757 18 18 15.757 18 13V5C18 2.243 15.757 0 13 0H5ZM5 2H13C14.654 2 16 3.346 16 5V13C16 14.654 14.654 16 13 16H5C3.346 16 2 14.654 2 13V5C2 3.346 3.346 2 5 2ZM14 3C13.7348 3 13.4804 3.10536 13.2929 3.29289C13.1054 3.48043 13 3.73478 13 4C13 4.26522 13.1054 4.51957 13.2929 4.70711C13.4804 4.89464 13.7348 5 14 5C14.2652 5 14.5196 4.89464 14.7071 4.70711C14.8946 4.51957 15 4.26522 15 4C15 3.73478 14.8946 3.48043 14.7071 3.29289C14.5196 3.10536 14.2652 3 14 3ZM9 4C6.243 4 4 6.243 4 9C4 11.757 6.243 14 9 14C11.757 14 14 11.757 14 9C14 6.243 11.757 4 9 4ZM9 6C10.654 6 12 7.346 12 9C12 10.654 10.654 12 9 12C7.346 12 6 10.654 6 9C6 7.346 7.346 6 9 6Z" />
                    </svg>
                    <span class="sr-only">Instagram Page</span>
                </a>
                <a href="https://www.linkedin.com/company/dev-it-city/" target="_blank" rel="nofollow"
                    class="text-white hover:text-black ms-5">
                    <svg class="w-4 h-4" aria-hidden="true" viewBox="0 0 18 18" fill="currentColor"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M15.8571 0H2.14286C0.96 0 0 0.96 0 2.14286V15.8571C0 17.04 0.96 18 2.14286 18H15.8571C17.04 18 18 17.04 18 15.8571V2.14286C18 0.96 17.04 0 15.8571 0ZM5.57143 6.85714V15H3V6.85714H5.57143ZM3 4.48714C3 3.88714 3.51429 3.42857 4.28571 3.42857C5.05714 3.42857 5.54143 3.88714 5.57143 4.48714C5.57143 5.08714 5.09143 5.57143 4.28571 5.57143C3.51429 5.57143 3 5.08714 3 4.48714ZM15 15H12.4286C12.4286 15 12.4286 11.0314 12.4286 10.7143C12.4286 9.85714 12 9 10.9286 8.98286H10.8943C9.85714 8.98286 9.42857 9.86571 9.42857 10.7143C9.42857 11.1043 9.42857 15 9.42857 15H6.85714V6.85714H9.42857V7.95429C9.42857 7.95429 10.2557 6.85714 11.9186 6.85714C13.62 6.85714 15 8.02714 15 10.3971V15Z" />
                    </svg>
                    <span class="sr-only">Linked in</span>
                </a>
            </div> --}}
        </div>
    </div>
    <x-ads-section :name="'footer'" :position="'bottom'" />
</footer>
