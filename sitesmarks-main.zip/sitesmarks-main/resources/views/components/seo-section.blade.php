@props(['page'])
@php
$seos = \App\Models\Seo::whereName($page)->get();
@endphp
@if ($seos->isNotEmpty())
@section('seo')
@foreach ($seos as $seo)
{!! $seo->title !!}
{!! $seo->description !!}
{{-- {!! $seo->keywords !!} --}}
{!! $seo->robots !!}
{!! $seo->schema !!}
{!! $seo->facebook !!}
{!! $seo->twitter !!}
@endforeach
@endsection
@else
@section('title'){{ $page }}@endsection
@endif
