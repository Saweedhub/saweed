@foreach ($comments as $comment)
    <style>
        .comment-content a {
            color: red;
            text-decoration: none;
        }

        .comment-content a:hover {
            text-decoration: underline;
        }
    </style>
    <article class="p-6 grid grid-cols-12 gap-4 text-base border-b">
        <div class="">
            @if ($comment->user->image == null)
                <img class="w-12 h-12 rounded-full" src="/assets/images/user_profile_placeholder.webp" alt="Michael Gough">
            @else
                <img class="w-12 h-12 rounded-full" src="{{ asset('storage/' . $comment->user->image) }}"
                    alt="Michael Gough">
            @endif
            {{ $comment->user->username }}
        </div>

        <div class="flex-col col-span-11">

            <p class="block text-md font-bold">
                {{ $comment->user->name }}

            </p>
            <p class="text-[10px]">
                about {{ $comment->created_at->diffForHumans() }}
            </p>
            <p class="text-gray-500 py-1 comment-content">
                {!! $comment->comment !!}
            </p>
        </div>

    </article>
@endforeach
