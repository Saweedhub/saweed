<header class="container mx-auto px-4 bg-white" id="heady_sticky">
    <nav class="relative py-4 flex justify-between items-center ">
        {{-- Mobile Menu Nav  --}}
        <div class=" mobile_menu_header">
            <button class="navbar-burger flex items-center text-blue-600 p-3">
                <svg class="block h-4 w-4 fill-current" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z"></path>
                </svg>
            </button>
        </div>
        <a href="/" class="text-3xl font-bold leading-none">
            @if ($setting->header_logo)
                <img src="{{ $setting->header_logo }}" style="width: 180px" alt="logo">
            @else
                <div class="flex gap-2">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M2.29924 29.111C5.36578 32.1774 10.3376 32.1774 13.4041 29.111C14.8365 27.6787 17.7576 24.7576 19.1899 23.3253C22.2565 20.2589 22.2565 15.2872 19.1899 12.2207C16.1234 9.15428 11.1516 9.15428 8.08502 12.2207C6.65271 13.653 3.73155 16.5741 2.29924 18.0064C-0.766412 21.0719 -0.766412 26.0445 2.29924 29.111ZM5.22219 20.9275C6.06489 20.0848 10.378 15.7718 11.008 15.1418C12.46 13.6898 14.8158 13.6898 16.2688 15.1418C17.7217 16.5938 17.7208 18.9496 16.2688 20.4025C15.6379 21.0333 11.3257 25.3454 10.483 26.1881C9.03092 27.6401 6.67515 27.6401 5.22219 26.1881C3.77014 24.7361 3.77014 22.3804 5.22219 20.9275Z"
                            fill="#0078D4" />
                        <path opacity="0.05"
                            d="M15.3821 14.4733C15.3821 14.4733 14.8786 13.2259 16.0184 11.8852L17.15 10.7526C14.534 9.44419 11.3454 9.69008 8.94566 11.4867C8.2663 14.0524 9.25528 16.8945 9.25528 16.8945C10.115 16.0348 10.8025 15.3474 11.0089 15.141C12.1989 13.9528 13.9291 13.7329 15.3821 14.4733Z"
                            fill="black" />
                        <path opacity="0.07"
                            d="M14.7359 14.2121C14.6677 13.6629 14.5888 12.5393 15.5804 11.4472C15.6379 11.3897 16.3406 10.67 16.5254 10.486C14.342 9.56978 11.8229 9.74567 9.75426 10.9572C9.05246 13.0876 9.49221 15.5214 9.75426 16.3973C10.3681 15.7835 10.8482 15.3034 11.0098 15.1418C12.0257 14.1251 13.4356 13.8163 14.7359 14.2121Z"
                            fill="black" />
                        <path
                            d="M29.1111 2.29985C26.0446 -0.766616 21.0728 -0.766616 18.0062 2.29985C16.5739 3.73212 13.6528 6.6532 12.2204 8.08548C9.1539 11.1519 9.1539 16.1236 12.2204 19.1901C15.287 22.2565 20.2588 22.2565 23.3253 19.1901C24.7577 17.7578 27.6788 14.8367 29.1111 13.4044C32.1768 10.3398 32.1768 5.36631 29.1111 2.29985ZM26.1882 10.4834C25.3455 11.326 21.0324 15.639 20.4024 16.269C18.9503 17.721 16.5946 17.721 15.1416 16.269C13.6887 14.817 13.6895 12.4613 15.1416 11.0084C15.7725 10.3775 20.0847 6.0654 20.9274 5.22272C22.3794 3.77071 24.7352 3.77071 26.1882 5.22272C27.6402 6.67564 27.6402 9.03135 26.1882 10.4834Z"
                            fill="#1B9DE2" />
                        <path opacity="0.05"
                            d="M16.0247 16.9257C16.0247 16.9257 16.5326 18.1857 15.392 19.5265L14.2603 20.659C16.8763 21.9674 20.0649 21.7215 22.4647 19.9249C23.1441 17.3592 22.1551 14.5171 22.1551 14.5171C21.2953 15.3768 20.6079 16.0642 20.4015 16.2706C19.2115 17.4588 17.4328 17.685 16.0247 16.9257Z"
                            fill="black" />
                        <path opacity="0.07"
                            d="M16.6869 17.198C16.7551 17.7472 16.8216 18.8717 15.8299 19.9638C15.7725 20.0212 15.0698 20.7239 14.8849 20.9088C17.0684 21.825 19.6117 21.65 21.6597 20.3901C22.3614 18.2596 21.919 15.8895 21.6561 15.0137C21.0422 15.6275 20.5621 16.1076 20.4005 16.2692C19.3855 17.2859 17.9146 17.583 16.6869 17.198Z"
                            fill="black" />
                        <path
                            d="M16.2688 15.1418C17.7208 16.5938 17.7208 18.9495 16.2688 20.4024C15.6379 21.0333 11.3257 25.3454 10.483 26.1881L13.4059 29.1109C14.8382 27.6787 17.7594 24.7576 19.1917 23.3253C22.2583 20.2588 22.2583 15.2872 19.1917 12.2207L16.2688 15.1418Z"
                            fill="#0078D4" />
                    </svg>
                    <span style="font-size: 30px;font-weight: bold">
                        {{ env('APP_NAME') }}</span>
                </div>
            @endif
        </a>
        <ul
            class="desktop_menu_header absolute top-1/2 left-1/2 transform -translate-y-1/2 -translate-x-1/2 lg:mx-auto  lg:items-center lg:w-auto lg:space-x-6">
            <li class="group flex items-center space-x-2">
                <div
                    class=" {{ Request::routeIs('home') ? 'secondary_color' : 'bg-zinc-200' }} h-[15px] w-[15px] rounded-full ">
                </div><a
                    class=" {{ Request::routeIs('home') ? 'text_color ' : '' }} text-base font-semibold text-gray-900 hover:text-gray-500"
                    href="{{ route('home') }}">Home</a>
            </li>
            <li class="group flex items-center space-x-2">
                <div
                    class=" {{ Request::routeIs('user.bookmarks') ? 'secondary_color' : 'bg-zinc-200' }} h-[15px] w-[15px] rounded-full ">
                </div><a
                    class=" {{ Request::routeIs('user.bookmarks') ? 'text_color' : '' }} text-base font-semibold text-gray-900 hover:text-gray-500"
                    href="{{ route('user.bookmarks') }}">Bookmarks</a>
            </li>
            <li class="group flex items-center space-x-2">
                <div
                    class=" {{ Request::routeIs('user.blog') ? 'secondary_color' : 'bg-zinc-200' }} h-[15px] w-[15px] rounded-full ">
                </div><a
                    class=" {{ Request::routeIs('user.blog') ? 'text_color' : '' }} text-base font-semibold text-gray-900 hover:text-gray-500"
                    href="{{ route('user.blog') }}">Blogs</a>
            </li>
            @php
                $price = \App\Models\Price::where('status', '1')->first();
            @endphp
            @if ($price)
                <li class="group flex items-center space-x-2">
                    <div
                        class=" {{ Request::routeIs('user.price') ? 'secondary_color' : 'bg-zinc-200' }} h-[15px] w-[15px] rounded-full ">
                    </div><a
                        class=" {{ Request::routeIs('user.price') ? 'text_color' : '' }} text-base font-semibold text-gray-900 hover:text-gray-500"
                        href="{{ route('user.price') }}">Pricing</a>
                </li>
            @endif

            <li class="group flex items-center space-x-2">
                <div
                    class=" {{ Request::routeIs('user.contact') ? 'secondary_color' : 'bg-zinc-200' }} h-[15px] w-[15px] rounded-full ">
                </div><a
                    class=" {{ Request::routeIs('user.contact') ? 'text_color' : '' }} text-base font-semibold text-gray-900 hover:text-gray-500"
                    href="{{ route('user.contact') }}">Contact Us</a>
            </li>
            <li>

                <a href="{{ auth()->check() ? route('bookmark.create') : route('user.login') }}"
                    style="border-radius: 26px;"
                    class="hover:scale-110 hidden items-center space-x-2 lg:flex lg:ml-auto lg:mr-3  py-3 px-6 secondary_color text-sm  font-bold  rounded-full transition duration-200 bg-gradient-to-r from-blue-500 to-red-500 text-white focus:ring ring-black ring-opacity-10 gradient element-to-rotate">
                    <span>
                        Submit
                    </span>
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M9 0C4.01593 0 0 4.01593 0 9C0 13.9841 4.01593 18 9 18C13.9841 18 18 13.9841 18 9C18 8.03185 17.8702 7.06641 17.524 6.16587L16.399 7.26923C16.537 7.82362 16.6154 8.37801 16.6154 9C16.6154 13.2242 13.2242 16.6154 9 16.6154C4.77584 16.6154 1.38462 13.2242 1.38462 9C1.38462 4.77584 4.77584 1.38462 9 1.38462C11.0769 1.38462 12.9429 2.21214 14.2572 3.52644L15.2308 2.55288C13.6379 0.960036 11.4231 0 9 0ZM16.8101 2.96394L9 10.774L6.03606 7.8101L5.04087 8.80529L8.5024 12.2668L9 12.7428L9.4976 12.2668L17.8053 3.95913L16.8101 2.96394Z"
                            fill="white" />
                    </svg>
                </a>

            </li>
        </ul>
        @if (Auth::user())
            <div class="relative group">
                <button id="dropdown-button"
                    class="inline-flex justify-center w-full px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm ">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor" class="w-5 h-5 mr-2">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
                    </svg>

                    <span class="mr-2 hidden sm:flex">My Account</span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 ml-2 -mr-1" viewBox="0 0 20 20"
                        fill="currentColor" aria-hidden="true">
                        <path fill-rule="evenodd"
                            d="M6.293 9.293a1 1 0 011.414 0L10 11.586l2.293-2.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"
                            clip-rule="evenodd" />
                    </svg>
                </button>
                <div
                    class="invisible absolute w-[170px] sm:w-full right-0  z-10 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 p-1 space-y-1 group-hover:visible">
                    <a href="{{ route('user.profile') }}"
                        class="block px-4 py-2 text-gray-700 hover:bg-gray-100 active:bg-blue-100 cursor-pointer rounded-md">Edit
                        Profile</a>
                    <a href="{{ route('bookmark.create') }}"
                        class="block px-4 py-2 text-gray-700 hover:bg-gray-100 active:bg-blue-100 cursor-pointer rounded-md">Submit
                        Bookmark</a>
                    <a href="{{ route('bookmark.list') }}"
                        class="block px-4 py-2 text-gray-700 hover:bg-gray-100 active:bg-blue-100 cursor-pointer rounded-md">My
                        Bookmarks</a>
                    <a href="{{ route('blog.create') }}"
                        class="block px-4 py-2 text-gray-700 hover:bg-gray-100 active:bg-blue-100 cursor-pointer rounded-md">Submit
                        blog</a>
                    <a href="{{ route('blog.list') }}"
                        class="block px-4 py-2 text-gray-700 hover:bg-gray-100 active:bg-blue-100 cursor-pointer rounded-md">My
                        blogs</a>
                    <a href="{{ route('user.logout') }}"
                        class="block px-4 py-2 text-gray-700 hover:bg-gray-100 active:bg-blue-100 cursor-pointer rounded-md">Logout</a>
                </div>
            </div>
        @else
            <div></div>
            <a class="relative before:ease  overflow-hidden before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:before:-translate-x-40 w-[140px]  desktop_menu_header lg:ml-auto items-center space-x-2 py-3 lg:mr-3 px-6 secondary_color text-sm text-white font-bold rounded-full transition duration-200"
                href="{{ route('user.login') }}"><span class="m-auto">Login</span>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3" />
                </svg>
            </a>
            <a class="relative before:ease  overflow-hidden before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:before:-translate-x-40 w-[140px] desktop_menu_header items-center space-x-2 py-3 px-6 secondary_color text-sm text-white font-bold rounded-full transition duration-200"
                href="{{ route('user.register') }}"><span class="m-auto">Register</span>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3" />
                </svg>
            </a>
        @endif
    </nav>
    {{-- Mobile nav Side bar --}}
    <nav class="navbar-menu relative z-50 hidden">
        <div class="navbar-backdrop fixed inset-0 bg-gray-800 opacity-25"></div>
        <nav
            class="fixed top-0 left-0 bottom-0 flex flex-col w-5/6 max-w-sm py-6 px-6 bg-white border-r overflow-y-auto">
            <div class="flex items-center mb-8">
                <a href="/" class="mr-auto text-3xl font-bold leading-none">
                    @if ($setting->header_logo)
                        <img src="{{ $setting->header_logo }}" style="width: 180px" alt="logo">
                    @else
                        <div class="flex gap-2">
                            <svg width="32" height="32" viewBox="0 0 32 32" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M2.29924 29.111C5.36578 32.1774 10.3376 32.1774 13.4041 29.111C14.8365 27.6787 17.7576 24.7576 19.1899 23.3253C22.2565 20.2589 22.2565 15.2872 19.1899 12.2207C16.1234 9.15428 11.1516 9.15428 8.08502 12.2207C6.65271 13.653 3.73155 16.5741 2.29924 18.0064C-0.766412 21.0719 -0.766412 26.0445 2.29924 29.111ZM5.22219 20.9275C6.06489 20.0848 10.378 15.7718 11.008 15.1418C12.46 13.6898 14.8158 13.6898 16.2688 15.1418C17.7217 16.5938 17.7208 18.9496 16.2688 20.4025C15.6379 21.0333 11.3257 25.3454 10.483 26.1881C9.03092 27.6401 6.67515 27.6401 5.22219 26.1881C3.77014 24.7361 3.77014 22.3804 5.22219 20.9275Z"
                                    fill="#0078D4" />
                                <path opacity="0.05"
                                    d="M15.3821 14.4733C15.3821 14.4733 14.8786 13.2259 16.0184 11.8852L17.15 10.7526C14.534 9.44419 11.3454 9.69008 8.94566 11.4867C8.2663 14.0524 9.25528 16.8945 9.25528 16.8945C10.115 16.0348 10.8025 15.3474 11.0089 15.141C12.1989 13.9528 13.9291 13.7329 15.3821 14.4733Z"
                                    fill="black" />
                                <path opacity="0.07"
                                    d="M14.7359 14.2121C14.6677 13.6629 14.5888 12.5393 15.5804 11.4472C15.6379 11.3897 16.3406 10.67 16.5254 10.486C14.342 9.56978 11.8229 9.74567 9.75426 10.9572C9.05246 13.0876 9.49221 15.5214 9.75426 16.3973C10.3681 15.7835 10.8482 15.3034 11.0098 15.1418C12.0257 14.1251 13.4356 13.8163 14.7359 14.2121Z"
                                    fill="black" />
                                <path
                                    d="M29.1111 2.29985C26.0446 -0.766616 21.0728 -0.766616 18.0062 2.29985C16.5739 3.73212 13.6528 6.6532 12.2204 8.08548C9.1539 11.1519 9.1539 16.1236 12.2204 19.1901C15.287 22.2565 20.2588 22.2565 23.3253 19.1901C24.7577 17.7578 27.6788 14.8367 29.1111 13.4044C32.1768 10.3398 32.1768 5.36631 29.1111 2.29985ZM26.1882 10.4834C25.3455 11.326 21.0324 15.639 20.4024 16.269C18.9503 17.721 16.5946 17.721 15.1416 16.269C13.6887 14.817 13.6895 12.4613 15.1416 11.0084C15.7725 10.3775 20.0847 6.0654 20.9274 5.22272C22.3794 3.77071 24.7352 3.77071 26.1882 5.22272C27.6402 6.67564 27.6402 9.03135 26.1882 10.4834Z"
                                    fill="#1B9DE2" />
                                <path opacity="0.05"
                                    d="M16.0247 16.9257C16.0247 16.9257 16.5326 18.1857 15.392 19.5265L14.2603 20.659C16.8763 21.9674 20.0649 21.7215 22.4647 19.9249C23.1441 17.3592 22.1551 14.5171 22.1551 14.5171C21.2953 15.3768 20.6079 16.0642 20.4015 16.2706C19.2115 17.4588 17.4328 17.685 16.0247 16.9257Z"
                                    fill="black" />
                                <path opacity="0.07"
                                    d="M16.6869 17.198C16.7551 17.7472 16.8216 18.8717 15.8299 19.9638C15.7725 20.0212 15.0698 20.7239 14.8849 20.9088C17.0684 21.825 19.6117 21.65 21.6597 20.3901C22.3614 18.2596 21.919 15.8895 21.6561 15.0137C21.0422 15.6275 20.5621 16.1076 20.4005 16.2692C19.3855 17.2859 17.9146 17.583 16.6869 17.198Z"
                                    fill="black" />
                                <path
                                    d="M16.2688 15.1418C17.7208 16.5938 17.7208 18.9495 16.2688 20.4024C15.6379 21.0333 11.3257 25.3454 10.483 26.1881L13.4059 29.1109C14.8382 27.6787 17.7594 24.7576 19.1917 23.3253C22.2583 20.2588 22.2583 15.2872 19.1917 12.2207L16.2688 15.1418Z"
                                    fill="#0078D4" />
                            </svg>
                            <span style="font-size: 30px;font-weight: bold">
                                {{ env('APP_NAME') }}</span>
                        </div>
                    @endif
                </a>
                <button class="navbar-close">
                    <svg class="h-6 w-6 text-gray-400 cursor-pointer hover:text-gray-500"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M6 18L18 6M6 6l12 12">
                        </path>
                    </svg>
                </button>
            </div>
            <div>
                <ul>
                    <li class="mb-1">
                        <a class="block p-4 text-sm font-semibold text-gray-400 hover:bg-blue-50 hover:text_color rounded"
                            href="{{ route('home') }}">Home</a>
                    </li>
                    <li class="mb-1">
                        <a <a
                            class="block p-4 text-sm font-semibold text-gray-400 hover:bg-blue-50 hover:text_color rounded"
                            href="{{ route('user.bookmarks') }}">Bookmarks</a>
                    </li>
                    <li class="mb-1">
                        <a class="block p-4 text-sm font-semibold text-gray-400 hover:bg-blue-50 hover:text_color rounded"
                            href="{{ route('user.blog') }}">Blogs</a>
                    </li>
                    @php
                        $price = \App\Models\Price::where('status', '1')->first();
                    @endphp
                    @if ($price)
                        <li class="mb-1">
                            <a class="block p-4 text-sm font-semibold text-gray-400 hover:bg-blue-50 hover:text_color rounded"
                                href="{{ route('user.price') }}">Pricing</a>
                        </li>
                    @endif
                    <li class="mb-1">
                        <a class="block p-4 text-sm font-semibold text-gray-400 hover:bg-blue-50 hover:text_color rounded"
                            href="{{ route('user.contact') }}">Contact</a>
                    </li>
                    <li class="mb-1">
                        <a class="block p-4 text-sm font-semibold text-gray-400 hover:bg-blue-50 hover:text_color rounded"
                            href="{{ route('featured.bookmark.details') }}">Other Sites</a>
                    </li>
                    <li class="mb-1">
                        <a class="block p-4 text-sm font-semibold text-gray-400 hover:bg-blue-50 hover:text_color rounded"
                            href="{{ route('user.login') }}">Login</a>
                    </li>
                    <li class="mb-1">
                        <a class="block p-4 text-sm font-semibold text-gray-400 hover:bg-blue-50 hover:text_color rounded"
                            href="{{ route('user.register') }}">Register</a>
                    </li>
                    <li>
                        <a class="block mt-6 p-4 secondary_color text-center text-sm font-semibold text-white hover:bg-black hover:text_color rounded-full"
                            href="{{ route('bookmark.create') }}">Submit</a>
                    </li>
                </ul>
            </div>
        </nav>
    </nav>
</header>
