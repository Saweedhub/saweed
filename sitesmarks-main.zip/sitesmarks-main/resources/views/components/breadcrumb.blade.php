@props(['name', 'page', 'seo' => null, 'category' => null])
@php
    $seos = \App\Models\Seo::whereName($seo)->get();
    $title = $name;
    if ($seos->isNotEmpty()) {
        $seo = $seos->first();
        $title = !empty($seo->keywords) ? $seo->keywords : $name;
    }
@endphp
<div class="py-6 secondary_color">
    <div class="container px-4 mx-auto flex items-center  w-full h-full  md:px-4">
        <div class=" font-bold text-white">
            <h1 class="text-3xl md:text-3xl lg:text-3xl">
                {{ $title }}
            </h1>
            <span><a class="hover:underline" href="{{ route('home') }}" alt="home">Home</a>
                @if ($category != null)
                    {{ ' \ ' }}<a class="hover:underline" href="{{ url('/' . strtolower($category)) }}"
                        alt="{{ $category }}">{{ $category }}</a>
                @endif
                {{ ' \ ' . $page }}
            </span>
        </div>
    </div>
</div>
