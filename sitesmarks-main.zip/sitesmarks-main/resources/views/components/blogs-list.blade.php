@props(['blogs', 'feature_blog', 'feature_blog_url', 'grid'])
<div class="mb-4">
    <x-ads-section :name="'blog-list'" :position="'top'" />
</div>


@if ($grid == 3)
    <div class="my-4 max-w-xs mx-auto pt-10 pb-10">
        <h2 class="text-center text-3xl border rounded-full py-4 border-black">Latest Blog</h2>
    </div>
@endif

<div class="container mx-auto lg:flex block  items-start pb-10">
    <div class=" w-full ">
        <div class="grid grid-cols-1 md:grid-cols-2 {{ $grid == 3 ? 'lg:grid-cols-3' : 'lg:grid-cols-2' }} gap-5">
            @if ($feature_blog)
                <div class="flex-col justify-between flex border  rounded-xl">
                    <div class="">
                        <button onclick="window.open('{{ $feature_blog_url }}','_self')" style="background-color: green"
                            class="absolute z-10 flex gap-2  px-4 py-2 text-white rounded-r-full">
                            Featured
                            <img loading="lazy" src="{{ asset('assets/pin-svg.svg') }}" class="my-auto"
                                alt="featured-pin.svg">
                        </button>
                        <a href="{{ $feature_blog_url }}">
                            <div class="relative h-[300px] w-full  overflow-hidden">
                                <img loading="lazy"
                                    src="{{ $feature_blog->thumbnail
                                        ? (Str::startsWith($feature_blog->thumbnail, ['http://', 'https://'])
                                            ? $feature_blog->thumbnail
                                            : asset('storage/' . $feature_blog->thumbnail))
                                        : '/assets/images/blog_placeholder.jpeg' }}"
                                    alt="{{ $feature_blog->title }}"
                                    class="img-fluid rounded-t-xl h-[300px] object-cover w-full transition-transform transform hover:scale-110">
                            </div>
                        </a>


                        <div class="mx-4 my-5">
                            <a class="underline-hover-effect text-black font-bold" href="{{ $feature_blog_url }}">
                                {!! \Illuminate\Support\Str::limit($feature_blog->title, 80, '...') !!}
                            </a>
                        </div>
                        <div class="mb-4">
                            <x-ads-section :name="'blog-list'" :position="'inside'" />
                        </div>

                        <div class="flex items-center m-4 justify-between ">
                            <div class="flex ">
                                <img loading="lazy" class="w-12 h-12 rounded-full object-cover mr-4 shadow"
                                    src="{{ '/assets/images/admin_profile.jpeg' }}" alt="avatar">

                                <div class="flex-col">
                                    <a class="flip-animate" href="{{ $feature_blog_url }}">
                                        <span data-hover="{{ $feature_blog->email }}">
                                            {{ $feature_blog->email }}
                                        </span>
                                    </a>
                                    @php
                                        $wordCount = str_word_count(strip_tags($feature_blog->description));
                                        $readingTime = ceil($wordCount / 200);
                                    @endphp
                                    <p class="text-[14px] text_color" href="#">
                                        {{ date('F d,Y', strtotime($feature_blog->created_at)) }}
                                        <span class="text-[10px]">
                                            • {{ $readingTime }} min read

                                        </span>
                                    </p>

                                </div>

                            </div>

                        </div>
                    </div>
                    <div class="flex justify-end mx-2 mb-2">

                        <a href="{{ $feature_blog_url }}" class="flex items-center space-x-2">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 0 1-2.555-.337A5.972 5.972 0 0 1 5.41 20.97a5.969 5.969 0 0 1-.474-.065 4.48 4.48 0 0 0 .978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25Z" />
                            </svg>
                            <span
                                class="text_color hover:underline">{{ $feature_blog->comments()->where('status', 1)->count() }}
                                Comment</span>
                        </a>
                    </div>
                </div>
                <x-ads-section :name="'blog-list'" :position="'between'" />
            @endif
            @foreach ($blogs->sortByDesc('by_admin')->sortByDesc('is_paid') as $index => $blog)
                @php
                    $blog_url_click = route('blog.details', [
                        'category' => Illuminate\Support\Str::slug($blog->cat_id),
                        'slug' => $blog->slug,
                    ]);
                @endphp
                <div class="flex-col justify-between flex border  rounded-xl">
                    <div class="">
                        @if ($blog->is_paid && $blog->by_admin)
                            <button
                                class="absolute z-10 secondary_color px-4 py-2 text-white rounded-r-full flex gap-2">
                                <svg class="w-4 h-4 m-auto" viewBox="0 0 84 84" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M41.6667 83.3333C64.6785 83.3333 83.3333 64.6785 83.3333 41.6667C83.3333 18.6548 64.6785 0 41.6667 0C18.6548 0 0 18.6548 0 41.6667C0 64.6785 18.6548 83.3333 41.6667 83.3333Z"
                                        fill="url(#paint0_linear_217_147)" />
                                    <path
                                        d="M41.6667 77.0833C61.2267 77.0833 77.0833 61.2267 77.0833 41.6667C77.0833 22.1066 61.2267 6.25 41.6667 6.25C22.1066 6.25 6.25 22.1066 6.25 41.6667C6.25 61.2267 22.1066 77.0833 41.6667 77.0833Z"
                                        fill="#F5BE00" />
                                    <path
                                        d="M52.604 48.6497C52.604 37.9393 36.7915 40.0309 36.7915 33.7038C36.7915 30.4018 40.5061 30.2268 41.6665 30.2268C44.4582 30.2268 47.1519 30.9747 49.2061 31.9393C49.854 32.2434 50.5978 31.7934 50.5978 31.0788V27.9622C50.5978 26.9163 50.204 26.2976 49.5769 26.0518C48.1686 25.5059 46.1478 25.1038 43.1561 25.0059V21.5768C43.1561 21.1663 42.8228 20.833 42.4123 20.833H40.9248C40.5144 20.833 40.1811 21.1663 40.1811 21.5768V25.0622C35.5394 25.5122 30.729 28.1309 30.729 34.2205C30.729 45.3226 46.5415 43.1205 46.5415 48.9684C46.5415 50.8059 45.3665 52.3893 41.6665 52.3893C37.9457 52.3893 34.5269 51.0893 32.6353 50.1226C31.9978 49.7976 31.2478 50.2684 31.2478 50.9851V54.533C31.2478 55.2143 31.6561 55.8184 32.2853 56.083C34.5269 57.0351 37.5353 57.7559 40.179 57.9663V61.758C40.179 62.1684 40.5123 62.5018 40.9228 62.5018H42.4103C42.8207 62.5018 43.154 62.1684 43.154 61.758V57.9768C50.0936 57.3976 52.604 52.7497 52.604 48.6497Z"
                                        fill="#FEE119" />
                                    <defs>
                                        <linearGradient id="paint0_linear_217_147" x1="13.0687" y1="13.0667"
                                            x2="71.0667" y2="71.0687" gradientUnits="userSpaceOnUse">
                                            <stop stop-color="#FEDE00" />
                                            <stop offset="1" stop-color="#FFD000" />
                                        </linearGradient>
                                    </defs>
                                </svg>
                                Sponsored
                            </button>
                        @endif
                        <a href="{{ $blog_url_click }}">
                            <div class="relative h-[300px] w-full  overflow-hidden">

                                <img loading="lazy"
                                    src="{{ $blog->thumbnail
                                        ? (Str::startsWith($blog->thumbnail, ['http://', 'https://'])
                                            ? $blog->thumbnail
                                            : asset('storage/' . $blog->thumbnail))
                                        : '/assets/images/blog_placeholder.jpeg' }}"
                                    alt="{{ $blog->title }}"
                                    class="img-fluid rounded-t-xl h-[300px] object-cover w-full transition-transform transform hover:scale-110">
                            </div>

                        </a>
                        <div class="mx-4 my-5">
                            <a class="underline-hover-effect text-black font-bold" href="{{ $blog_url_click }}">
                                {!! \Illuminate\Support\Str::limit($blog->title, 80, '...') !!}
                            </a>
                        </div>
                        <div class="mb-4">
                            <x-ads-section :name="'blog-list'" :position="'inside'" />
                        </div>

                        <div class="flex items-center m-4 justify-between ">
                            <div class="flex ">
                                <img loading="lazy" class="w-12 h-12 rounded-full object-cover mr-4 shadow"
                                    src="{{ $blog->user->image ? (Str::startsWith($blog->user->image, ['http://', 'https://']) ? $blog->user->image : asset('storage/' . $blog->user->image)) : 'https://static.vecteezy.com/system/resources/previews/019/896/008/original/male-user-avatar-icon-in-flat-design-style-person-signs-illustration-png.png' }}"
                                    alt="avatar">

                                <div class="flex-col">
                                    <a class="flip-animate" href="{{ $blog_url_click }}">
                                        <span data-hover="{{ $blog->user->name }}">
                                            {{ $blog->user->name }}
                                        </span>
                                    </a>
                                    @php
                                        $wordCount = str_word_count(strip_tags($blog->description));
                                        $readingTime = ceil($wordCount / 200);
                                    @endphp
                                    <p class="text-[14px] text_color" href="#">
                                        {{ date('F d,Y', strtotime($blog->created_at)) }}
                                        <span class="text-[10px]">
                                            • {{ $readingTime }} min read

                                        </span>
                                    </p>

                                </div>

                            </div>
                            <div class="flex gap-2">

                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M13.19 8.688a4.5 4.5 0 0 1 1.242 7.244l-4.5 4.5a4.5 4.5 0 0 1-6.364-6.364l1.757-1.757m13.35-.622 1.757-1.757a4.5 4.5 0 0 0-6.364-6.364l-4.5 4.5a4.5 4.5 0 0 0 1.242 7.244" />
                                </svg>
                                <p>{{ $blog->cat_id }}</p>
                            </div>
                        </div>


                    </div>
                    <div class="flex justify-end mx-2 mb-2 h-max">

                        <a href="{{ $blog_url_click }}" class="flex items-center space-x-2">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 0 1-2.555-.337A5.972 5.972 0 0 1 5.41 20.97a5.969 5.969 0 0 1-.474-.065 4.48 4.48 0 0 0 .978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25Z" />
                            </svg>
                            <span
                                class="text_color hover:underline">{{ $blog->comments()->where('status', 1)->count() }}
                                Comment</span>
                        </a>
                    </div>
                </div>
                @if ($index == 0)
                    <x-ads-section :name="'blog-list'" :position="'between'" />
                @endif
            @endforeach
        </div>
        <div class="my-6">
            {{ $blogs->appends(['blogs' => $blogs->currentPage()])->links() }}

        </div>
    </div>
</div>
<div class="mb-4">
    <x-ads-section :name="'blog-list'" :position="'bottom'" />
</div>
