@props(['name'])

<div class="relative h-[100px] secondary_color" style="z-index:-1">
    <div class="flex flex-col gap-4 justify-center items-center w-full h-full px-3 md:px-0">
        <h1 class="text-2xl md:text-2xl lg:text-2xl font-bold text-white">
            {{ $name }}
        </h1>
    </div>
</div>
