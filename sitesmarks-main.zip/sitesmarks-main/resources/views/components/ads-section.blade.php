@props(['name', 'position'])
@php
    $authAd = $ads_inserter->where('name', $name)->first();
    $adHtml = '';
    if ($authAd) {
        switch ($position) {
            case 'left':
                $adHtml = $authAd->left;
                break;
            case 'right':
                $adHtml = $authAd->right;
                break;
            case 'top':
                $adHtml = $authAd->top;
                break;
            case 'bottom':
                $adHtml = $authAd->bottom;
                break;
            case 'between':
                $adHtml = $authAd->between;
                break;
            case 'inside':
                $adHtml = $authAd->inside;
                break;
            default:
                $adHtml = '';
                break;
        }
    }

@endphp
{!! $adHtml !!}


{{-- switch ($position) {
    case 'left':
        if ($name == 'auth') {
            $adHtml = '<div class="h-full ads_container">' . $name . $authAd->left . '</div>';
        }
        break;
    case 'right':
        if ($name == 'auth') {
            $adHtml = '<div class="h-full ads_container">' . $name . $authAd->right . '</div>';
        }
        break;
    case 'top':
        if (
            $name == 'sidebar' ||
            $name == 'footer' ||
            $name == 'blog-list' ||
            $name == 'bookmark-list' ||
            $name == 'screens'
        ) {
            $adHtml = '<div class="h-80  ads_container">' . $name . $authAd->top . '</div>';
        }
        break;
    case 'bottom':
        if ($name == 'footer' || $name == 'blog-list' || $name == 'bookmark-list' || $name == 'screens') {
            $adHtml = '<div class="h-80 ads_container">' . $name . $authAd->bottom . '</div>';
        } elseif ($name == 'sidebar') {
            $adHtml = '<div class="h-[800px] ads_container">' . $name . $authAd->bottom . '</div>';
        }
        break;
    case 'between':
        if ($name == 'blog-list') {
            $adHtml = '<div class="h-full ads_container">' . $name . $authAd->between . '</div>';
        } elseif ($name == 'bookmark-list') {
            $adHtml = '<div class="h-40 ads_container">' . $name . $authAd->between . '</div>';
        }
        break;
    case 'inside':
        if (
            $name == 'auth' ||
            $name == 'sidebar' ||
            $name == 'footer' ||
            $name == 'blog-list' ||
            $name == 'bookmark-list' ||
            $name == 'screens'
        ) {
            $adHtml = '<div class="h-20 w-full  ads_container">' . $name . $authAd->inside . '</div>';
        }
        break;
    default:
        $adHtml = '';
        break;
} --}}
