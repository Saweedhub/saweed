@extends('layouts.app')
<x-seo-section :page="'blogs'" />

@section('content')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css" />
    @php
        [$r, $g, $b] = sscanf($setting->primary_color, '#%02x%02x%02x');
        $alpha = 0.2;
        $myrgbaColor = "rgba($r, $g, $b,$alpha)";
    @endphp
    <style>
        .blog-slider {
            width: 95%;
            position: relative;
            max-width: 800px;
            margin: auto;
            background: #fff;
            box-shadow: 0px 14px 80px rgba(34, 35, 58, 0.2);
            padding: 25px;
            border-radius: 25px;
            height: 400px;
            transition: all 0.3s;
        }

        @media screen and (max-width: 992px) {
            .blog-slider {
                max-width: 680px;
                height: 400px;
            }
        }

        @media screen and (max-width: 768px) {
            .blog-slider {
                min-height: 500px;
                height: auto;
                margin: 180px auto;
            }
        }

        @media screen and (max-height: 500px) and (min-width: 992px) {
            .blog-slider {
                height: 350px;
            }
        }

        .blog-slider__item {
            display: flex;
            align-items: center;
        }

        @media screen and (max-width: 768px) {
            .blog-slider__item {
                flex-direction: column;
            }
        }

        .blog-slider__item.swiper-slide-active .blog-slider__img img {
            opacity: 1;
            transition-delay: 0.3s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>* {
            opacity: 1;
            transform: none;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(1) {
            transition-delay: 0.3s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(2) {
            transition-delay: 0.4s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(3) {
            transition-delay: 0.5s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(4) {
            transition-delay: 0.6s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(5) {
            transition-delay: 0.7s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(6) {
            transition-delay: 0.8s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(7) {
            transition-delay: 0.9s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(8) {
            transition-delay: 1s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(9) {
            transition-delay: 1.1s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(10) {
            transition-delay: 1.2s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(11) {
            transition-delay: 1.3s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(12) {
            transition-delay: 1.4s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(13) {
            transition-delay: 1.5s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(14) {
            transition-delay: 1.6s;
        }

        .blog-slider__item.swiper-slide-active .blog-slider__content>*:nth-child(15) {
            transition-delay: 1.7s;
        }


        .blog-slider__img {
            width: 400px;
            flex-shrink: 0;
            height: 300px;
            background-image: linear-gradient(147deg, {{ $myrgbaColor }} 0%, {{ $myrgbaColor }} 74%);
            box-shadow: 4px 13px 30px 1px {{ $myrgbaColor }};
            border-radius: 20px;
            transform: translateX(-80px);
            overflow: hidden;
        }

        .blog-slider__img:after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: linear-gradient(147deg, {{ $myrgbaColor }} 0%, {{ $myrgbaColor }} 74%);
            border-radius: 20px;
            opacity: 0.8;
        }

        .blog-slider__img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            opacity: 0;
            border-radius: 20px;
            transition: all 0.3s;
        }

        @media screen and (max-width: 768px) {
            .blog-slider__img {
                transform: translateY(-50%);
                width: 90%;
            }
        }

        @media screen and (max-width: 576px) {
            .blog-slider__img {
                width: 95%;
            }
        }

        @media screen and (max-height: 500px) and (min-width: 992px) {
            .blog-slider__img {
                height: 270px;
            }
        }

        .blog-slider__content {
            padding-right: 25px;
        }

        @media screen and (max-width: 768px) {
            .blog-slider__content {
                margin-top: -80px;
                text-align: center;
                padding: 0 30px;
            }
        }

        @media screen and (max-width: 576px) {
            .blog-slider__content {
                padding: 0;
            }
        }

        .blog-slider__content>* {
            opacity: 0;
            transform: translateY(25px);
            transition: all 0.4s;
        }

        .blog-slider__code {
            color: #7b7992;
            margin-bottom: 15px;
            display: block;
            font-weight: 500;
        }

        .blog-slider__title {
            font-size: 24px;
            font-weight: 700;
            color: #0d0925;
            margin-bottom: 20px;
        }

        .blog-slider__text {
            color: #4e4a67;
            margin-bottom: 30px;
            line-height: 1.5em;
        }

        .blog-slider__button {
            display: inline-flex;
            background-image: linear-gradient(147deg, {{ $setting->primary_color }} 0%, #fd3838 74%);
            padding: 15px 35px;
            border-radius: 50px;
            color: #fff;
            box-shadow: 0px 14px 80px rgba(252, 56, 56, 0.4);
            text-decoration: none;
            font-weight: 500;
            justify-content: center;
            text-align: center;
            letter-spacing: 1px;
        }

        @media screen and (max-width: 576px) {
            .blog-slider__button {
                width: 100%;
            }
        }

        .blog-slider .swiper-container-horizontal>.swiper-pagination-bullets,
        .blog-slider .swiper-pagination-custom,
        .blog-slider .swiper-pagination-fraction {
            bottom: 10px;
            left: 0;
            width: 100%;
        }

        .blog-slider__pagination {
            position: absolute;
            z-index: 21;
            right: 20px;
            width: 11px !important;
            text-align: center;
            left: auto !important;
            top: 50%;
            bottom: auto !important;
            transform: translateY(-50%);
        }

        @media screen and (max-width: 768px) {
            .blog-slider__pagination {
                transform: translateX(-50%);
                left: 50% !important;
                top: 205px;
                width: 100% !important;
                display: flex;
                justify-content: center;
                align-items: center;
            }
        }

        .blog-slider__pagination.swiper-pagination-bullets .swiper-pagination-bullet {
            margin: 8px 0;
        }

        @media screen and (max-width: 768px) {
            .blog-slider__pagination.swiper-pagination-bullets .swiper-pagination-bullet {
                margin: 0 5px;
            }
        }

        .blog-slider__pagination .swiper-pagination-bullet {
            width: 11px;
            height: 11px;
            display: block;
            border-radius: 10px;
            opacity: 0.2;
            transition: all 0.3s;
        }

        .blog-slider__pagination .swiper-pagination-bullet-active {
            opacity: 1;
            height: 30px;
            box-shadow: 0px 0px 20px rgba(252, 56, 56, 0.3);
        }

        @media screen and (max-width: 768px) {
            .blog-slider__pagination .swiper-pagination-bullet-active {
                height: 11px;
                width: 30px;
            }
        }
    </style>

    <div>
        <x-breadcrumb :name="date('Y') . ' Free Submit Blogs For Everyone'" :page="'Blogs'" :seo="'blogs'" />
        <div class="mt-4">
            <x-ads-section :name="'screens'" :position="'top'" />
        </div>
        <div class="my-4 max-w-xs mx-auto pt-10">
            <h2 class="text-center text-3xl border rounded-full py-4 border-black">Latest Blog</h2>
        </div>
        <section class="container mx-auto px-3 md:px-10 my-4">
            <div class=" block lg:flex items-start gap-5 py-20">
                <div class="lg:w-[70%] w-full">
                    <div>
                        @php
                            $feature_blogs = \App\Models\FeatureBlog::where('status', '1')->latest('id')->get();
                        @endphp
                        @if ($feature_blogs->count() > 0)
                            <div class="blog-slider swiper-container-fade swiper-container-horizontal">
                                <div class="blog-slider__wrp swiper-wrapper" style="transition-duration: 0ms;">
                                    @foreach ($feature_blogs as $feature_blog)
                                        @php
                                            $feature_blog_url_slug = \Illuminate\Support\Str::slug(
                                                $feature_blog->title,
                                            );
                                            $feature_blog_url = "/blogs/$feature_blog_url_slug";
                                        @endphp
                                        <div class="blog-slider__item swiper-slide swiper-slide"
                                            style="width: 750px; opacity: 1; transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;">
                                            <div class="blog-slider__img">
                                                <img loading="lazy" src="{{ $feature_blog->thumbnail }}" alt="">
                                            </div>
                                            <div class="blog-slider__content">
                                                <span class="blog-slider__code"># Featured</span>

                                                <div class="blog-slider__title max-h-[5em] overflow-hidden">
                                                    <a href="{{ $feature_blog_url }}"
                                                        class="text-black text-[24px] font-bold underline-hover-effect ">{{ $feature_blog->title }}</a>
                                                    <br>
                                                </div>
                                                <div class="blog-slider__text ">
                                                    <div class="flex items-center my-4 justify-between ">
                                                        <div class="flex ">
                                                            <img loading="lazy"
                                                                class="w-12 h-12 rounded-full object-cover mr-4 shadow border"
                                                                src="{{ '/assets/images/admin_profile.jpeg' }}"
                                                                alt="avatar">

                                                            <div class="flex-col">

                                                                <a class="flip-animate" href="{{ $feature_blog_url }}">
                                                                    @php
                                                                        $appUrl = config('app.url');
                                                                        $domain = parse_url($appUrl, PHP_URL_HOST);
                                                                        $email = 'admin@' . $domain;
                                                                    @endphp
                                                                    <span data-hover="{{ $email }}">
                                                                        {{ $email }}
                                                                    </span>
                                                                </a>
                                                                @php
                                                                    $wordCount = str_word_count(
                                                                        strip_tags($feature_blog->description),
                                                                    );
                                                                    $readingTime = ceil($wordCount / 200);
                                                                @endphp
                                                                <p class="text-[14px] text_color">
                                                                    {{ date('F d,Y', strtotime($feature_blog->created_at)) }}
                                                                    <span class="text-[10px]">
                                                                        • {{ $readingTime }} min read

                                                                    </span>
                                                                </p>

                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="xl:flex block justify-between mx-2 mb-2">
                                                    <a href="{{ $feature_blog_url }}"
                                                        class="blog-slider__button animate-bounce">READ
                                                        BLOG</a>
                                                    <a href="{{ $feature_blog_url }}"
                                                        class="xl:mt-0 mt-2 xl:justify-normal justify-end flex items-center space-x-2">
                                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                            viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                                            class="w-4 h-4">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 0 1-2.555-.337A5.972 5.972 0 0 1 5.41 20.97a5.969 5.969 0 0 1-.474-.065 4.48 4.48 0 0 0 .978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25Z" />
                                                        </svg>
                                                        <span
                                                            class="ext_color hover:underline">{{ $feature_blog->comments()->where('status', 1)->count() }}
                                                            Comment</span>
                                                    </a>
                                                </div>

                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="blog-slider__pagination swiper-pagination-clickable swiper-pagination-bullets">
                                    <span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0"
                                        role="button" aria-label="Go to slide 1"></span>
                                </div>
                                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                            </div>
                            <div class="md:block h-10 hidden"></div>
                        @endif
                        <x-blogs-list :blogs="$blogs" :feature_blog="null" :feature_blog_url="null" :grid="2" />
                    </div>
                </div>
                @include('includes.sidebar')
            </div>
        </section>
    </div>

@endsection
@section('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js"></script>
    <script>
        var swiper = new Swiper('.blog-slider', {
            spaceBetween: 30,
            effect: 'fade',
            loop: true,
            autoplay: {
                delay: 2000,
            },
            pagination: {
                el: '.blog-slider__pagination',
                clickable: true,
            }
        });
    </script>
@endsection
