(toastr.options = {
    closeButton: !0,
    debug: !1,
    newestOnTop: !0,
    progressBar: !0,
    positionClass: "toast-top-right",
    preventDuplicates: !1,
    onclick: null,
    showDuration: "300",
    hideDuration: "1000",
    timeOut: "5000",
    extendedTimeOut: "1000",
    showEasing: "swing",
    hideEasing: "linear",
    showMethod: "fadeIn",
    hideMethod: "fadeOut",
}),
    $("#category_slider").owlCarousel({
        margin: 10,
        nav: !0,
        loop: !0,
        autoplay: !0,
        autoplayTimeout: 1500,
        autoplayHoverPause: !0,
        responsive: { 0: { items: 1 }, 600: { items: 3 }, 1e3: { items: 5 } },
    }),
    $("#ad_slider").owlCarousel({
        margin: 10,
        nav: !0,
        loop: !0,
        autoplay: !0,
        autoplayTimeout: 1500,
        autoplayHoverPause: !0,
        responsive: { 0: { items: 1 }, 600: { items: 1 }, 1e3: { items: 1 } },
    }),
    document.addEventListener("DOMContentLoaded", function () {
        try {
            var e = $("#ad_slider_container"),
                o = 100,
                t = $("#heady_sticky"),
                n = t.outerHeight(),
                s = t.offset().top + n;
        } catch (e) {}
        $(window).on("scroll", function () {
            $(this).scrollTop() > 120
                ? $("#scrollToTopBtn")
                      .removeClass("hidden")
                      .addClass("flex")
                      .css("opacity", "1")
                : $("#scrollToTopBtn")
                      .removeClass("block")
                      .addClass("hidden")
                      .css("opacity", "0");
            var n = $(window).scrollTop();
            e && n > o
                ? e.addClass("sticky").css("top", o + "px")
                : e.removeClass("sticky").css("top", "0"),
                t && n > s
                    ? t.addClass("sticky")
                    : $("#heady_sticky").removeClass("sticky");
        }),
            $("#scrollToTopBtn").click(function () {
                return $("html, body").animate({ scrollTop: 0 }, 800), !1;
            });
        const l = document.querySelectorAll(".navbar-burger"),
            a = document.querySelectorAll(".navbar-menu");
        if (l.length && a.length)
            for (var i = 0; i < l.length; i++)
                l[i].addEventListener("click", function () {
                    for (var e = 0; e < a.length; e++)
                        a[e].classList.toggle("hidden");
                });
        const d = document.querySelectorAll(".navbar-close"),
            r = document.querySelectorAll(".navbar-backdrop");
        if (d.length)
            for (i = 0; i < d.length; i++)
                d[i].addEventListener("click", function () {
                    for (var e = 0; e < a.length; e++)
                        a[e].classList.toggle("hidden");
                });
        if (r.length)
            for (i = 0; i < r.length; i++)
                r[i].addEventListener("click", function () {
                    for (var e = 0; e < a.length; e++)
                        a[e].classList.toggle("hidden");
                });
    });
const dropdownButton = document.getElementById("dropdown-button"),
    dropdownMenu = document.getElementById("dropdown-menu");
let isOpen = !1;
function toggleDropdown() {
    (isOpen = !isOpen), dropdownMenu.classList.toggle("hidden", !isOpen);
}
dropdownButton &&
    dropdownButton.addEventListener("click", () => {
        toggleDropdown();
    });

/* Social Share */
if ($(".social-networks").length) {
    $(".social-networks").on("click", "a", function (e) {
        var data_action = $(this).attr("data-action");
        var data_title = $(this).attr("data-title");
        var data_url = $(this).attr("data-url");
        var data_img = $(this).attr("data-img");

        if (data_action == "facebook") {
            window.open(
                "http://www.facebook.com/share.php?u=" +
                    encodeURIComponent(data_url) +
                    "&title=" +
                    encodeURIComponent(data_title),
                "sharer",
                "toolbar=0,status=0,width=580,height=325"
            );
        } else if (data_action == "twitter") {
            window.open(
                "http://twitter.com/intent/tweet?status=" +
                    encodeURIComponent(data_url) +
                    "+" +
                    encodeURIComponent(data_title),
                "sharer",
                "toolbar=0,status=0,width=580,height=325"
            );
        } else if (data_action == "linkedin") {
            window.open(
                "http://www.linkedin.com/shareArticle?mini=true&url=" +
                    encodeURIComponent(data_url) +
                    "&title=" +
                    encodeURIComponent(data_title) +
                    "&source=" +
                    encodeURIComponent(data_url),
                "sharer",
                "toolbar=0,status=0,width=580,height=325"
            );
        } else if (data_action == "pinterest") {
            window.open(
                "http://pinterest.com/pin/create/button/?url=" +
                    encodeURIComponent(data_url) +
                    "&media=" +
                    encodeURIComponent(data_img) +
                    "&description=" +
                    encodeURIComponent(data_title),
                "sharer",
                "toolbar=0,status=0,width=580,height=325"
            );
        } else if (data_action == "digg") {
            window.open(
                "http://digg.com/submit?url=" +
                    encodeURIComponent(data_url) +
                    "&amp;title=" +
                    encodeURIComponent(data_title),
                "sharer",
                "toolbar=0,status=0,width=580,height=325"
            );
        } else if (data_action == "reddit") {
            window.open(
                "http://www.reddit.com/submit?url=" +
                    encodeURIComponent(data_url) +
                    "&amp;title=" +
                    encodeURIComponent(data_title),
                "sharer",
                "toolbar=0,status=0,width=580,height=325"
            );
        }
    });
}
